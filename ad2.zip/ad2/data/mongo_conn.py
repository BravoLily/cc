import pymongo


def conn_mongo(dbname, sheet):
    client = pymongo.MongoClient(port=27017, host='192.168.1.225')
    db_auth = client.admin
    connected = db_auth.authenticate('ycfadmin', '123')
    db = client[dbname]
    col = db[sheet]
    return col
