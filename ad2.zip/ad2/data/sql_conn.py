import pymssql


class ConnectMySQL:
    def __init__(self,
                 host='192.168.1.225',
                 user='sa',
                 password='123'):
        self.host = host
        self.user = user
        self.password = password
        self.db = "cazuresnsdb"

    def __GetConnect(self):
        if not self.db:
            raise (NameError, "没有设置数据库信息")
        self.conn = pymssql.connect(
            host=self.host,
            user=self.user,
            password=self.password,
            database=self.db)
        cur = self.conn.cursor()
        if not cur:
            raise (NameError, "连接数据库失败")
        else:
            return cur

    def ExecQuery(self, sql):
        cur = self.__GetConnect()
        cur.execute(sql)
        reslist = cur.fetchall()

        self.conn.close()
        return reslist

    def ExecNonQuery(self, sql):
        cur = self.__GetConnect()
        cur.execute(sql)
        self.conn.commit()
        self.conn.close()


# UNITTEST
if __name__ == '__main__':

    sql = "SELECT [ViewId],[Title],[Remark],[CreateDate] FROM [cazuresnsdb].[dbo].[T_View]"
    ms = ConnectMySQL()
    res = ms.ExecQuery(sql)

    for row in res:
        print(row[0])
        # print(row)