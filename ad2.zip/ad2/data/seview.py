# coding=utf-8
import os

from jieba.analyse import ChineseAnalyzer
from whoosh.fields import Schema, NUMERIC, TEXT, DATETIME
from whoosh.index import create_in

from data.sql_conn import ConnectMySQL

"""
脚本功能： 对sqlserver数据库中的观点建立索引

索引结构：
    idx=NUMERIC,
    viewid=NUMERIC(stored=True),
    title=TEXT(stored=True),
    content=TEXT(stored=True),
    createdate=DATETIME(stored=True)

"""

ModelPath = '../model'


def create_search(indexpath, indexname, sql_dbname):
    analyser = ChineseAnalyzer()

    schema = Schema(idx=NUMERIC,
                    viewid=NUMERIC(stored=True),
                    title=TEXT(stored=True),
                    content=TEXT(stored=True, analyzer=analyser),
                    createdate=DATETIME(stored=True))  # 创建索引结构

    indexpath = os.path.join(ModelPath, indexpath)
    if not os.path.exists(indexpath):
        os.mkdir(indexpath)

    # path 为索引创建的地址，indexname为索引名称
    ix = create_in(indexpath, schema=schema, indexname=indexname)

    writer = ix.writer()

    sql = "SELECT [ViewId],[Title],[Remark],[CreateDate] FROM [" + sql_dbname + "].[dbo].[T_View]"
    ms = ConnectMySQL()
    res = ms.ExecQuery(sql)

    for row in res:
        writer.add_document(idx=1, viewid=row[0], title=row[1], content=row[2], createdate=row[3])

    writer.commit()
    print("建立完成一个索引")


if __name__ == '__main__':
    create_search('indexpath', 'indexname', "cazuresnsdb")