import happybase

connection = happybase.Connection(host='192.168.1.39', port=9090)
connection.open()
print(connection.tables())
table = connection.table('test')
row = table.rows(['row1', 'row2'])
for key, data in row:
    print(key, data)




