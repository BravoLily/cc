import random
import string
import uuid
from time import mktime

from data.mongo_conn import conn_mongo


def create_uid():
    return str(uuid.uuid1())


invest = [0.1, 0.3, 0.5, 1, 3, 5, 10, 50, 100, 200, 300, 500, 1000, 3000]  # 万
time = [3, 6, 12, 24, 36]  # 月
sex = ['M', 'W']  # M: Man   W: Woman
job = ['Student', 'IT', 'Worker', 'Businessman', 'Farmer', 'other']
education = ['college', 'bachelor', 'master', 'doctor', 'other']
income = [5, 10, 30, 50, 100, 300, 500, 1000, 100000]  # 万
province = ['BJ', 'HA', 'GD', 'HK', 'TW', 'QH', 'SD', 'other']
platform = ['ios', 'android', 'other']


def create_userInfo():
    dic = dict()
    # 用户id
    random_uid = create_uid()
    dic['uid'] = random_uid
    # 姓名
    uname_list = [random.choice(string.ascii_letters) for _ in range(5)]
    random_uname = ''.join(uname_list)
    dic['name'] = random_uname
    # 年龄
    random_age = random.randint(10, 80)
    dic['age'] = random_age
    # 性别
    dic['sex'] = random.choice(sex)
    # 职业
    dic['job'] = random.choice(job)
    # 学历
    dic['education'] = random.choice(education)
    # 年收入 W
    dic['income'] = random.choice(income)

    # 省
    dic['province'] = random.choice(province)
    # 市
    dic['city'] = 'somewhere'
    # 区
    dic['region'] = 'somewhere'
    # 位置
    dic['location'] = 'somewhere'

    # 经度
    dic['longitude'] = 'somewhere'

    # 维度
    dic['latitude'] = 'somewhere'

    #session
    dic['clientid'] = 'someclientid'
    # platform
    dic['platform'] = random.choice(platform)
    # sysver
    dic['sysver'] = 'somesysver'

    random_risk = random.randint(1, 7)
    dic['risk'] = random_risk
    random_investment = random.choice(invest)
    dic['investment'] = random_investment
    random_time = random.choice(time)
    dic['time'] = random_time

    col = conn_mongo('log', 'test.userinfo')
    col.insert(dic)


buy = []
for i in range(1, 19):
    buy.append(str(i))

ofp = []
# for i in range(1, 9):
#     ofp.append(str(i))

colo = conn_mongo('log', 'test.ofp')
s = colo.find()
for i in s:
    ofp.append(i['_id'])

a1 = (2016, 1, 1, 0, 0, 0, 0, 0, 0)
a2 = (2018, 8, 31, 23, 59, 59, 0, 0, 0)
start = mktime(a1)
end = mktime(a2)

live = ['基金', '信托', '银行理财', '银行理财', '银行理财', '银行理财', '银行理财', '银行理财', '银行理财', '资产配置', '理财规划', '债券']
# live = ['基金', '信托', '银行理财', '资产配置', '理财规划', '债券']


def create_userlog(uid):
    log = dict()
    random_uid = uid
    cnt = random.choice([2, 2, 2, 2, 2, 3])
    log['uid'] = random_uid
    buyflag = True
    if cnt % 3:

        colu = conn_mongo('log', 'test.userinfo')
        user = colu.find_one({'uid': uid})
        planmoney = user['investment']

        # 购买的产品起投额小于用户预算
        colp1 = conn_mongo('log', 'test.product')
        product = colp1.find({'price': {'$lte': planmoney}})
        productlist = []
        for p in product:
            productlist.append([p['_id'], p['price']])

        if productlist:
            random_buy = random.choice(productlist)
            log['buy'] = random_buy[0]

            # 投资额random_invest不低于产品起投额random_buy[1] 不高于用户可支配金额 planmoney
            # 投资最小值为产品起投额

            random_invest = random.uniform(random_buy[1], planmoney)
            # proprice <= invest <= planmoney
            if random_invest < 1:
                log['invest'] = round(random_invest, 1)
            else:
                log['invest'] = round(random_invest, 0)

            random_time = random.uniform(start, end)
            log['time'] = random_time
        else:
            buyflag = False
    else:
        random_ofp = random.choice(ofp)
        log['ofp'] = random_ofp
        random_live = random.choice(live)
        log['live'] = random_live

    if buyflag:
        col1 = conn_mongo('log', 'test.userlog')
        col1.insert(log)


if __name__ == '__main__':

    for _ in range(1300):
        create_userInfo()

    col = conn_mongo('log', 'test.userinfo')
    s = col.find()
    for i in s:
        for _ in range(random.randint(2, 7)):
            create_userlog(i['_id'])

