from whoosh.index import open_dir
from whoosh.qparser import QueryParser

ModelPath = '../model'


class Search:
    def __init__(self, indexpath=ModelPath + "/indexpath", indexname='indexname'):
        """

        :param indexpath: 索引路径
        :param indexname: 文件名字

        """
        self.indexpath = indexpath
        self.indexname = indexname

    def search(self, keyword, proj='viewid'):
        """

        :param keyword: 检索关键字
        :param proj:  [viewid, title, content,createdate, idx];idx='1'，全量检索
        :return:
        """
        index = open_dir(self.indexpath, indexname=self.indexname)

        with index.searcher() as searcher:
            parser = QueryParser(proj, index.schema)
            myquery = parser.parse(keyword)
            results = searcher.search(myquery, limit=None)

            try:
                for res in results:
                    yield dict(res)
            except TypeError:
                return None


def get_view():
    s = Search()
    alldata = s.search('1', proj='idx')
    return alldata


# UNITTEST
if __name__ == '__main__':
    s = Search()
    m = s.search('1359', proj='viewid')
    for i in m:
        print(i)

    alldata = s.search('1', proj='idx')
    for i in alldata:
        # print(i)
        print(i['viewid'])





