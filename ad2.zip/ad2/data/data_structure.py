class UserInfo:
    def __init__(self):
        self.uid = None  # 用户id
        self.name = None  # 用户名
        self.age = None  # 用户年龄
        self.sex = None  # 性别
        self.job = None  # 职业
        self.education = None  # 学历
        self.income = None  # 收入

        self.province = None  # 省
        self.city = None   # 市
        self.region = None  # 区
        self.location = None  # 用户位置
        self.longitude = None  # 经度
        self.latitude = None  # 维度

        self.session = None  # 会话id
        self.platform = None  # 系统
        self.sysver = None  # 版本

        # self.risk_tolerance = None  # * 用户风险承受能力
        # self.investment = None  # * 用户计划投资额/可支配资金
        # self.time = None  # * 计划投资时长

        self.nicheng = None
        self.email = None
        self.sj = None  # 手机
        self.sname = None  # 真实姓名
        self.sfzh = None  # 身份证号码
        self.xb = None  # 性别
        self.csrq = None  # 出生日期
        self.zgxl = None  # 最高学历
        self.rxnf = None  # 入学年份
        self.byxx = None  # 毕业学校
        self.hyxk = None  # 婚姻状况
        self.xyks = None  # 信用卡数
        self.gfqk = None  # 购房情况
        self.fwjz = None  # 房屋价值
        self.gcqk = None  # 购车情况
        self.cljz = None  # 车辆价值
        self.jrzc = None  # 金融资产
        self.xybg = None  # 信用报告
        self.liveprovince = None  # 居住省份
        self.livecity = None  # 居住城市
        self.idprovince = None  # 户口所在省份
        self.idcity = None  # 户口所在城市
        self.adress = None  # 住址
        self.tel = None  # 家庭电话
        self.touxinag = None  # 头像
        self.creditscore = None  # 信用分数


class UserLog:
    def __init__(self, uid, buy, investment, date, ofp, live):
        self.uid = uid
        self.buy = buy  # 购买产品id
        self.investment = investment  # 投资额
        self.date = date  # 购买日期
        self.ofp = ofp  # 咨询的理财师id
        self.live = live  # 看的直播的label


class ProductInfo:
    def __init__(self, pid, name, label, type, returns, time, price, shares):
        self.pid = pid  # 产品id
        self.name = name  # 产品名称 不使用
        self.type = type  # 产品类型：理财，资管，信托 ……
        self.label = label  # 产品label
        self.returns = returns  # 收益率
        self.time = time  # 投资期限
        self.price = price  # 起投额
        self.shares = shares  # 推荐数


class OFPInfo:
    def __init__(self, oid, name, skill, fanscount, livecount, plancount, returns):
        self.oid = oid  # 理财师id
        self.name = name  # 理财师名字
        self.skill = skill  # 理财师擅长领域
        self.fanscount = fanscount  # 粉丝数
        self.livecount = livecount  # 直播数
        self.plancount = plancount  # 理财计划
        self.returns = returns  # 综合年收益