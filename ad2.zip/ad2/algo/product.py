import random

from bson import ObjectId
from sklearn.ensemble import RandomForestClassifier
from sklearn.externals import joblib
from sklearn.model_selection import cross_val_score, train_test_split

from data.mongo_conn import conn_mongo


def datatrain(product, flag):
    """

    :param product: buy/ofp 参与推荐的产品list，ex:['理财1号'， '理财2号']
    :param flag: 'buy' or 'ofp'
    :return: 训练数据， ex: x[[x1, x2], [x1, x2]  y[0, 1]
    """
    col = conn_mongo('log', 'test.userinfo')
    userinfo = col.find()

    x = []
    y = []

    for i in range(len(product)):
        y.append([])

    job = ['Student', 'IT', 'Worker', 'Businessman', 'Farmer', 'other']
    education = ['college', 'bachelor', 'master', 'doctor', 'other']
    province = ['BJ', 'HA', 'GD', 'HK', 'TW', 'QH', 'SD', 'other']
    platform = ['ios', 'android', 'other']

    for i in userinfo:
        uid = i['uid']
        try:
            x1 = i['name']
        except KeyError:
            x1 = None
        try:
            x2 = i['age']
        except KeyError:
            x2 = 30
        try:
            x3 = 0 if (i['sex'] == 'M') else 1
        except KeyError:
            x3 = 0
        try:
            x4 = job.index(i['job'])
        except KeyError:
            x4 = job.index(i['other'])

        try:
            x5 = education.index(i['education'])
        except KeyError:
            x5 = education.index(i['other'])
        try:
            x6 = i['income']
        except KeyError:
            x6 = 10
        try:
            x7 = province.index(i['province'])
        except KeyError:
            x7 = province.index(i['other'])
        try:
            x8 = platform.index(i['platform'])
        except KeyError:
            x8 = platform.index(i['other'])

        try:
            x9 = i['risk']
        except KeyError:
            x9 = 4
        try:
            x10 = i['investment']
        except KeyError:
            x10 = 10
        try:
            x11 = i['time']
        except KeyError:
            x11 = 24
        # x2, x3, x4, x5, x6, x7,
        x.append([x9, x10, x11])

        # print('x', x)
        col2 = conn_mongo('log', 'test.userlog')
        for b, res in zip(product, y):
            if flag is 'ofp':
                find = col2.find_one({'uid': uid, 'ofp': b})
            else:
                find = col2.find_one({'uid': uid, 'buy': b})
            if find:
                res.append(1)
            else:
                res.append(0)
    print('x: ', x)
    print('y: ', y)
    return x, y


def split_data(x, y, size):
    x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=size, random_state=0)
    return x_train, x_test, y_train, y_test


def rf_classifier(x_train, y_train, modelname):
    rf = RandomForestClassifier(
        n_estimators=10,)
    rf.fit(x_train, y_train)
    joblib.dump(rf, modelname)


def rf_predict(modelname, x_test):
    rf = joblib.load(modelname)
    # res = rf.predict(x_test)
    res = rf.predict_proba(x_test)
    return res


def rf_evaluate(modelname, x_train, y_train):
        # p = np.where(ress == 1)
        # print(p)
        rf = joblib.load(modelname)
        scores = cross_val_score(rf, x_train, y_train, cv=10, scoring='accuracy')  # 交叉验证
        return scores

# -------------------------------------------


def train_product(product, flag):
    x, y = datatrain(product, flag=flag)
    for i in range(len(y)):
        modelname = '../model/%s_%s.model' % (flag, product[i])
        rf_classifier(x, y[i], modelname)


def evaluate(product, flag):
    x, y = datatrain(product, flag=flag)
    for i in range(len(y)):
        modelname = '../model/%s_%s.model' % (flag, product[i])
        scores = rf_evaluate(modelname, x, y[i])
        print('产品名称：', product[i], 'scores: ', scores.mean())


def predict_one(x_predict, product, flag, vpt):
    """

    :param x_predict: 输入用户特征list
    :param product: 要推荐的产品（id）list
    :param flag: 要推荐的产品类别 ('buy', 'ofp')
    :param vpt: 输出阈值
    :return: 推荐产品的idlist
    """
    ress = []
    for i in range(len(product)):
        modelname = '../model/%s_%s.model' % (flag, product[i])
        res = rf_predict(modelname, x_predict)
        ress.append(res[0][1])
    tmp = ress.copy()
    tmp.sort(reverse=True)
    productid = []
    for i in tmp:
        if i > vpt:
            pos = ress.index(i)
            productid.append(product[pos])
    return productid


def predict_some(x_predict, product, flag, vpt):
    num_x = len(x_predict)
    ress = [[] for _ in range(num_x)]
    # ress2 = [[]]*num_x 每一个[]都指向array的引用，所以一旦array改变，matrix中3个list也会随之改变。
    for i in range(len(product)):
        modelname = '../model/%s_%s.model' % (flag, product[i])
        res = rf_predict(modelname, x_predict)
        for j in range(num_x):
            ress[j].append(res[j][1])
    all = []
    for res in ress:
        tmp = res.copy()
        tmp.sort(reverse=True)
        productid = []
        for i in tmp:
            if i > vpt:
                pos = res.index(i)
                productid.append(product[pos])
        all.append(productid)
    return all


if __name__ == '__main__':

    # 参与推荐的产品标识 pid
    # buy = ['1', '2', '3', '4', '5', '6', '7', '8', '9']
    buy = [ObjectId("5b73bf9cb13b593554e22de6"), ObjectId("5b73bf9cb13b593554e22dea"), ObjectId("5b73bf9db13b593554e22dfc")]
    # 参与推荐的理财师标识 oid
    ofp = ['1', '2', '3', '4', '5']

    # col = conn_mongo('log', 'test.userinfo')
    # s = col.find()
    # for i in s:
    #     uid = i['uid']
    #     datatrain(buy, 'buy')

    datatrain(buy, 'buy')
    # train_product(buy, 'buy')
    # evaluate(buy, 'buy')
    # result = predict_one([[3, 100, 12]], 18)
    # result = predict_some([[3, 100, 12], [5, 200, 36], [7, 1000, 6]], 18)
    # result = predict_some([[3, 100, 6]], 18)
    # result = predict_some([[30, 0, 1, 2, 100, 0, 5, 100, 12]], buy, 'buy')
    # print(result)

    # train(buy, 'buy')
    # evaluate(buy, 'buy')
    # result = predict_some([[3, 100, 12], [5, 200, 36], [7, 1000, 6]], buy, 'buy')
    # print(result)

    # aa = []
    # for i in range(10):
    #     a = random.randint(1, 7)
    #     b = random.choice([0.1, 1, 100, 1000])
    #     c = random.choice([6, 12, 24, 36])
    #     l = [a, b, c]
    #     # print(l)
    #     aa.append(l)
    #     print('buy: ', predict_one([l], buy, 'buy', 0.3))
        # print('ofp: ', predict_one([l], ofp, 'ofp', 0.2))
    # print('buy: ', predict_some(aa, buy, 'buy', 0.3))


# 冷推荐
# 经常所有都不点击  _ 用概率解决
#
