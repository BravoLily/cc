from data.mongo_conn import conn_mongo
import numpy as np

"""

1. 按规则排序，比如收益率最高的排在前面，分享最多的排第二  (产品属性)
2. 按历史(点击率/购买/曝光)排序，ctr=点击量/展示量。这个更为合理，但需要历史数据支撑  （用户属性）

"""


#  按历史点击率排序
def ctr_buy(buy):
    col = conn_mongo('log', 'test.userlog')
    res = []
    for i in buy:
        s = col.find().count()
        s1 = col.find({'buy': i}).count()
        res.append([i, s1/s])
    res.sort(key=lambda x: x[1], reverse=True)
    return [r[0] for r in res]


def ctr_ofp(ofp):
    col = conn_mongo('log', 'test.userlog')
    res = []
    for i in ofp:
        s = col.find().count()
        s1 = col.find({'ofp': i}).count()
        res.append([i, s1/s])
    res.sort(key=lambda x: x[1], reverse=True)
    return [r[0] for r in res]


#  按规则排序
def cold_buy():
    col = conn_mongo('log', 'test.product')
    product = col.find({})
    p = []
    for i in product:
        x0 = i['_id']
        try:
            x1 = i['returns']
        except KeyError:
            x1 = 0.8
        try:
            x2 = i['time']
        except KeyError:
            x2 = 6
        try:
            x3 = i['price']
        except KeyError:
            x3 = 0.01
        try:
            x4 = i['shares']
        except KeyError:
            x4 = 1000
        p.append([x0, x1, x2, x3, x4])
    p.sort(key=lambda x: (x[1], x[2], x[3], x[4]), reverse=True)

    coldbuy = np.array(p)
    coldbuy = list(coldbuy[:, 0])
    return coldbuy


def cold_ofp():
    col = conn_mongo('log', 'test.ofp')
    product = col.find({})
    p = []
    for i in product:
        x0 = i['_id']
        try:
            x1 = i['fanscount']
        except KeyError:
            x1 = 1000
        try:
            x2 = i['livecount']
        except KeyError:
            x2 = 10
        try:
            x3 = i['plancount']
        except KeyError:
            x3 = 2
        try:
            x4 = i['returns']
        except KeyError:
            x4 = 8
        p.append([x0, x1, x2, x3, x4])

    p.sort(key=lambda x: (x[1], x[2], x[4], x[3]), reverse=True)

    coldofp = np.array(p)
    coldofp = list(coldofp[:, 0])
    return coldofp


def add_buy_ondb(buy=None, method='ctr'):
    if method is 'ctr':
        buy = ctr_buy(buy)
    else:
        buy = cold_buy()
    col = conn_mongo('log', 'test.cold')
    col.insert({'buy': buy})


def add_ofp_ondb(ofp=None, method='ctr'):
    if method is 'ctr':
        ofp = ctr_ofp(ofp)
    else:
        ofp = cold_ofp()
    col = conn_mongo('log', 'test.cold')
    col.insert({'ofp': ofp})


def add_coldbuy(res):
    col = conn_mongo('log', 'test.cold')
    buy = col.find_one({'buy': {'$exists': True}})
    cold_buy = buy['buy']
    if res:
        ret_list = [item for item in cold_buy if item not in res]
        res.extend(ret_list)
    else:
        res = cold_buy
    return res


def add_coldofp(res):
    col = conn_mongo('log', 'test.cold')
    ofp = col.find_one({'ofp': {'$exists': True}})
    cold_ofp = ofp['ofp']

    if res:
        ret_list = [item for item in cold_ofp if item not in res]

        res.extend(ret_list)
    else:
        res = cold_ofp

    return res


if __name__ == '__main__':
    col = conn_mongo('log', 'test.product')
    s = col.find()
    buy = []
    for i in s:
        buy.append(i['_id'])
    add_buy_ondb(buy)


