"""
主要因为view量很大啊没办法一一计算是否点击  吧？
广告推荐和 文章推荐还是不太一样的  区别在于：推荐排序是推荐很多个，再给个排序
                                        广告的话推荐少量就可以了
                                        虽然好像也没太大区别
                                        但可以用更简单的算法了
之前是什么方法？ 额，协同过滤。用之前的算法就可以了啊  模型的输入是用户的浏览记录
或者~
新写一个算法

根据新数据？
"""
from data.getview import Search


def train():
    s = Search()
    res = s.search(keyword='1', proj='idx')
    for i in res:
        print(i['viewid'])


if __name__ == '__main__':
    train()
