
"""
输出：buy  &&   ofp  &&  view

1. 获取要进行推荐的数据  buy & ofp & view   默认全部？
2. 判断模型是否存在，不存在则重新训练（完全匹配）
3. 判断冷启动表是否存在，不存在则重新训练
4. 获取用户数据   单个 or 多个？
5. 分别预测  添加冷启动？
"""
import os
from sys import argv

from algo.cold import add_ofp_ondb, add_buy_ondb, add_coldofp, add_coldbuy
from algo.product import train_product, predict_one
from data.mongo_conn import conn_mongo


#  获取推荐数据 buy, ofp
buy = []
ofp = []
view = []

col1 = conn_mongo('log', 'test.product')
col2 = conn_mongo('log', 'test.ofp')
buyf = col1.find()
for i in buyf:
    buy.append(i['_id'])
ofpf = col2.find()
for i in ofpf:
    ofp.append(i['_id'])

#  判断模型是否存在,不存在或者不完整则重新训练
for i in buy:
    if not os.path.exists('../model/%s_%s.model' % ('buy', i)):
        train_product(buy, 'buy')
        break
for i in ofp:
    if not os.path.exists('../model/%s_%s.model' % ('ofp', i)):
        train_product(ofp, 'ofp')
        break

# 判断冷启动表是否存在,不存在则重新训练
col = conn_mongo('log', 'test.cold')
if not col.find({'ofp': {'$exists': True}}).count():
    add_ofp_ondb(ofp)
if not col.find({'buy': {'$exists': True}}).count():
    add_buy_ondb(buy)

# 用户数据
x = [3, 100, 12]


def start():
    b = predict_one([x], buy, 'buy', 0.3)
    b = add_coldbuy(b)
    o = predict_one([x], ofp, 'ofp', 0.2)
    o = add_coldofp(o)
    # view = predict_one([x], view, 'view', 0.3)
    return [{'Type': 'product', 'Vaule': b}, {'Type': 'OFP', 'Vaule': o}]


#  或者能不能比较一下三个产品的score,看看是推荐哪一个品种

print('neiy', 'bijib', 'maoliang')

if __name__ == '__main__':
    start()

