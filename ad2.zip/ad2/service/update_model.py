from algo.cold import add_ofp_ondb
from algo.product import train_product
from data.mongo_conn import conn_mongo

#  获取推荐数据 buy, ofp; 默认获取数据库中所有产品
buy = []
ofp = []

col1 = conn_mongo('log', 'test.product')
col2 = conn_mongo('log', 'test.ofp')
buyf = col1.find()
for i in buyf:
    buy.append(i['_id'])
ofpf = col2.find()
for i in ofpf:
    ofp.append(i['_id'])

# update cold buy
col = conn_mongo('log', 'test.cold')
col.remove({'buy': {'$exists': True}})
add_ofp_ondb(buy, method='ctr')

# update cold ofp
col = conn_mongo('log', 'test.cold')
col.remove({'ofp': {'$exists': True}})
add_ofp_ondb(ofp, method='ctr')

# update buy model
train_product(buy, 'buy')
# update ofp model
train_product(ofp, 'ofp')
