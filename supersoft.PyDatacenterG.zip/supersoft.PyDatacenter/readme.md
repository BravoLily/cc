
## 打包命令
    cd $path (代码所在主路径)
    python3 $path/supersoft.PyDatacenter/src/setup/setup.py bdist_egg

## 提交命令：
    
    spark-submit --py-files eggfile bootfile arvg1 arvg2 arvg3 arvg4 arvg5 arvg6 ……
 
    arvg1: es配置
        host:kafka-port:index_name:doctype_name:alias
        eg: 192.168.1.235:9200:PersonasTag:docs:personasTag
    
    arvg2: cm_mongo_url_member
    arvg3: cm_mongo_url_invest
    arvg4: cm_mongo_url_product
    arvg5: cm_mongo_url_applog
    arvg6: cm_mongo_url_weblog
    
    arvg7: ycf_mongo_url_member
    arvg8: ycf_mongo_url_invest
    arvg9: ycf_mongo_url_product
    arvg10: ycf_mongo_url_applog
    arvg11: ycf_mongo_url_weblog
    
    arvg12: mongo_url_tag  标签库
    
    
    eg: 
    spark-submit --py-files /home/lili/Datacenter/dist/personas-0.1.0-py3.6.egg \
    /home/lili/Datacenter/supersoft.PyDatacenter/src/service/pre_boot.py \
    192.168.1.235:9200:personastag:docs \
    mongodb://ycfadmin:123@192.168.1.225:27017/statictis.cm_member_baseinfo_copy \
    mongodb://ycfadmin:123@192.168.1.225:27017/statictis.cm_invest_baseinfo \
    mongodb://ycfadmin:123@192.168.1.225:27017/statictis.cm_product_baseinfo \
    mongodb://ycfadmin:123@192.168.1.225:27017/statictis.cm_applog \
    mongodb://ycfadmin:123@192.168.1.225:27017/statictis.cm_weblog \
    mongodb://ycfadmin:123@192.168.1.225:27017/statictis.ycf_member_baseinfo \ 
    mongodb://ycfadmin:123@192.168.1.225:27017/statictis.ycf_invest_baseinfo \
    mongodb://ycfadmin:123@192.168.1.225:27017/statictis.ycf_product_baseinfo \
    mongodb://ycfadmin:123@192.168.1.225:27017/statictis.ycf_applog \
    mongodb://ycfadmin:123@192.168.1.225:27017/statictis.ycf_weblog \
    mongodb://ycfadmin:123@192.168.1.225:27017/tag.tag

