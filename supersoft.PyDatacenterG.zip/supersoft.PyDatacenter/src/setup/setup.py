#-*- coding:utf-8 -*-

from setuptools import setup, find_packages

setup(
    name="personas",
    version="0.1.0",
    packages=find_packages("supersoft.PyDatacenter", exclude=["*.scala", "*.scala.*"]),
    package_dir={"": "supersoft.PyDatacenter"},
    package_data={
            "": ["*.txt", "*.csv"],
        },
    zip_safe=False,

    description="egg personas demo.",
    # long_description="egg test demo, haha.",

    license="GPL",
    keywords=("personas", "egg"),
    platforms="Independant",
    url="",
)
