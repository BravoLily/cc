# -*-coding:utf-8 -*-

import pandas as pd
import sys

from elasticsearch import Elasticsearch
from pyspark import SparkConf, SparkContext

from src.datacenter.databases.write_to_es import write_to_es, write_one_to_es
from src.datacenter.labels.product import product
from src.datacenter.labels.risk import get_risk

try:
    ess = sys.argv[1].split(':')
    esconn = ess[0] + ':' + ess[1]
    index_name = ess[2]
    doctype_name = ess[3]
    alias = ess[4]
except IndexError:
    print("PARAMETER 1 ERROR")
    sys.exit(1)

es = Elasticsearch([esconn])

cm_mongo_url_member = sys.argv[2]
cm_mongo_url_invest = sys.argv[3]
cm_mongo_url_product = sys.argv[4]
cm_mongo_url_applog = sys.argv[5]
cm_mongo_url_weblog = sys.argv[6]

ycf_mongo_url_member = sys.argv[7]
ycf_mongo_url_invest = sys.argv[8]
ycf_mongo_url_product = sys.argv[9]
ycf_mongo_url_applog = sys.argv[10]
ycf_mongo_url_weblog = sys.argv[11]

mongo_url_tag = sys.argv[12]
# mongo_url_data = sys.argv[13]


def start():
    conf = SparkConf()
    conf.setAppName("personas_base")
    sc = SparkContext(conf=conf)

    print("start calculating")

    dfhy_risk = get_risk(cm_mongo_url_member, ycf_mongo_url_member)
    dfhy_product = product(cm_mongo_url_member, ycf_mongo_url_member,
                           cm_mongo_url_applog, cm_mongo_url_weblog,
                           ycf_mongo_url_applog, ycf_mongo_url_weblog,
                           cm_mongo_url_product, ycf_mongo_url_product,
                           mongo_url_tag)

    dfhy = pd.merge(dfhy_risk, dfhy_product, on='UserID', how='outer')

    write_to_es(dfhy, es, doctype_name, index_name, alias)

    sc.stop()


if __name__ == '__main__':
    start()
