# -*-coding:utf-8 -*-
import time
import pandas as pd
import sys

from elasticsearch import Elasticsearch
from pyspark import SparkConf, SparkContext

from src.datacenter.databases.write_to_es import write_to_es
from src.datacenter.databases.write_to_mongo import write_to_mongo
from src.datacenter.labels.invest import start_invest
from src.datacenter.labels.log import start_log
from src.datacenter.labels.member import start_member

try:
    ess = sys.argv[1].split(':')
    esconn = ess[0] + ':' + ess[1]
    index_name = ess[2]
    doctype_name = ess[3]
except IndexError:
    print("PARAMETER 1 ERROR")
    sys.exit(1)

es = Elasticsearch([esconn])

cm_mongo_url_member = sys.argv[2]
cm_mongo_url_invest = sys.argv[3]
cm_mongo_url_product = sys.argv[4]
cm_mongo_url_applog = sys.argv[5]
cm_mongo_url_weblog = sys.argv[6]

ycf_mongo_url_member = sys.argv[7]
ycf_mongo_url_invest = sys.argv[8]
ycf_mongo_url_product = sys.argv[9]
ycf_mongo_url_applog = sys.argv[10]
ycf_mongo_url_weblog = sys.argv[11]

mongo_url_tag = sys.argv[12]
mongo_url_data = sys.argv[13]

# if sys.argv[14] == "total":
#     days = None
# elif sys.argv[14] == "increment":
#     days = 1
# elif sys.argv[9].isdigit():
#     days = int(sys.argv[9])
# else:
#     print("update condition wrong")
#     sys.exit(1)


def start():
    conf = SparkConf()
    conf.setAppName("personas_base")
    sc = SparkContext(conf=conf)

    print("start calculating")

    starttime = time.clock()

    df1 = start_member(cm_mongo_url_member, ycf_mongo_url_member, mongo_url_tag)
    df2 = start_invest(cm_mongo_url_invest, ycf_mongo_url_invest,
                       cm_mongo_url_product, ycf_mongo_url_product, mongo_url_tag)
    df3 = start_log(cm_mongo_url_applog, ycf_mongo_url_applog,
                    cm_mongo_url_weblog, ycf_mongo_url_weblog,
                    cm_mongo_url_product, ycf_mongo_url_product, mongo_url_tag)
    dff = pd.merge(df1, df2, how='outer')
    df = pd.merge(dff, df3, how='outer')

    df['UserType'].fillna(2, inplace=True)

    print('data end')

    write_to_es(df, es, doctype_name, index_name)

    write_to_mongo(es, doctype_name, index_name, mongo_url_data)

    endtime5 = time.clock()
    print("all cost = " + str(endtime5 - starttime))

    sc.stop()


if __name__ == '__main__':

    start()
