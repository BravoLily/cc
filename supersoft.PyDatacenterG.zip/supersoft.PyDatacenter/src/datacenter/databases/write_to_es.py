# -*-coding:utf-8 -*-
import numpy as np
from elasticsearch import helpers


def gendata(data_series, indexname, typename):
    for d in data_series:
        yield {
            "_id": d['UserID'],
            "_index": indexname,
            "_type": typename,
            "_source": d,
        }


def remove_null(x):
    for key in list(x.keys()):
        if x[key] == '':
            del x[key]
    return x


def write_to_es(df, es, typename, indexname, alias):
    df = df.replace(np.NaN, '')
    data_series = df.to_dict(orient='records')
    new_data_series = list(map(lambda x: remove_null(x), data_series))

    if es.indices.exists(index=indexname) is True:
        es.indices.delete(index=indexname, ignore=[400, 404])
    helpers.bulk(es, gendata(new_data_series, indexname, typename), chunk_size=10000, request_timeout=100)
    es.indices.put_alias(index=indexname, name=alias)
    es.indices.put_settings(body={'index': {'max_result_window': 2000000000}})


def write_one_to_es(df, es, index_name, doctype_name):
    df = df.replace(np.NaN, '')
    data_series = df.to_dict(orient='records')
    new_data_series = list(map(lambda x: remove_null(x), data_series))
    for i in new_data_series:
        try:
            print('update', i['UserID'])
            es.update(index=index_name, doc_type=doctype_name, id=str(i['UserID']), body={"doc": i})
        except Exception:
            es.index(index=index_name, doc_type=doctype_name, body=i, id=str(i['UserID']))

