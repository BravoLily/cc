# -*-coding:utf-8 -*-
from pyspark import SparkConf, SparkContext, SQLContext

conf = SparkConf().setAppName("ESTest")
sc = SparkContext(conf=conf)
sqlContext = SQLContext(sc)

es_read_conf = {
        "es.nodes": "http://192.168.1.235",
        "es.port": "9200",
        "es.resource": "pe/pe",
        "es.input.json": "yes",
        # "es.query": query,
        "es.nodes.wan.only": "true"
    }

es_rdd = sc.newAPIHadoopRDD(
        inputFormatClass='org.elasticsearch.hadoop.mr.EsInputFormat',
        keyClass='org.apache.hadoop.io.NullWritable',
        valueClass='org.elasticsearch.hadoop.mr.LinkedMapWritable',
        conf=es_read_conf,
    )

print(es_rdd.first())
