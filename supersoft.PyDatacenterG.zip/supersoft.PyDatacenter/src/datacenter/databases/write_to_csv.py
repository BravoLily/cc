# -*-coding:utf-8 -*-
import csv

import os

from src.datacenter.datatemp.dirpath import path


def write_to_csv(data, filename, fieldList):
    with open(os.path.join(path, filename), 'a+', encoding='utf-8', newline='') as csvfilewriter:
        writer = csv.writer(csvfilewriter)
        writer.writerow(fieldList)
        for d in data:
            for i in d:
                ivalueLst = []
                for fild in fieldList:
                    if fild not in i:
                        ivalueLst.append(None)
                    else:
                        ivalueLst.append(i[fild])
                try:
                    writer.writerow(ivalueLst)
                except Exception as e:
                    print('write wrong')
