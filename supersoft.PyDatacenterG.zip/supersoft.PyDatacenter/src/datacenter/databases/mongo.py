# -*-coding:utf-8 -*-
import pymongo


def conn_mongourl(mongo_url):

    #  mongodb://ycfadmin:123@192.168.1.225:27017/statictis.cm_member_baseinfo

    s = mongo_url.split("/")
    s1 = s[-1].split(".")

    dbname = s1[0]
    colname = s1[1]

    mongo_url = mongo_url + '?authMechanism=SCRAM-SHA-1&authSource=admin'

    client = pymongo.MongoClient(mongo_url)
    db = client[dbname]

    col = db[colname]

    return col

