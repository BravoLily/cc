# -*-coding:utf-8 -*-

from src.datacenter.databases.mongo import conn_mongourl


def write_to_mongo(es, doctype_name, index_name, url_data):

    indices = [index_name]

    # Initialize the scroll
    page = es.search(
        index=','.join(indices),
        doc_type=doctype_name,
        scroll='2m',
        search_type='query_then_fetch',
        size=10000,
    )
    sid = page['_scroll_id']
    scroll_size = page['hits']['total']
    print('total scroll_size: ', scroll_size)

    l = []
    while scroll_size > 0:
        page = es.scroll(scroll_id=sid, scroll='2m')
        sid = page['_scroll_id']
        scroll_size = len(page['hits']['hits'])
        docs = page['hits']['hits']
        l += [x['_source'] for x in docs]

    print('total docs: ', len(l))

    col = conn_mongourl(url_data)
    col.drop()
    col.insert_many(l)
