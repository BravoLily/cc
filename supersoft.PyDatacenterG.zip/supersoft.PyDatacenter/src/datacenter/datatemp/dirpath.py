# -*-coding:utf-8 -*-
import os

# curPath = os.path.abspath(os.path.dirname(__file__))
# rootPath = os.path.split(curPath)[0]
# path = os.path.join(rootPath, 'datatemp')

path = '/tmp'
