# -*-coding:utf-8 -*-
import datetime
import numpy as np


def c_time_last(x):
    if x:
        x = x.split('.')[0]
        x = datetime.datetime.strptime(x, "%Y-%m-%d %H:%M:%S")
        now = datetime.datetime.now()
        # now = np.datetime64(now)
        last = int((now - x).days)
        return last
    else:
        return None


def c_time_log(x):
    if x and x is not np.nan:
        x = datetime.datetime.strptime(x, "%Y-%m-%d %H:%M:%S")
        now = datetime.datetime.now()
        last = int((now - x).days)
        return last
    else:
        return None


def c_time_hour(x):
    if x:
        x = x.split('.')[0]
        x = datetime.datetime.strptime(x, "%Y-%m-%d %H:%M:%S")
        return x.hour


def c_time_day(x):
    if x:
        x = x.split('.')[0]
        x = datetime.datetime.strptime(x, "%Y-%m-%d %H:%M:%S")
        return x.day
