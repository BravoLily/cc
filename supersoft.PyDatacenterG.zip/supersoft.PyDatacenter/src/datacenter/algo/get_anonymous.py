# -*-coding:utf-8 -*-
import pandas as pd
import numpy as np
import os



def get_anonymous(df, deviceid):

    df[deviceid] = df[deviceid].replace(np.nan, '')

    # 乱码的userid修正为undefined
    # df.ix[df['userid'].map(len) != 36, 'userid'] = 'undefined'
    df['hyid'] = df['hyid'].apply(str)

    # 获取userid 和 hyid 对照表,
    a = df.groupby(df[deviceid]).apply(lambda x: getid(x))
    a = pd.DataFrame({'glhyid': a})
    a.reset_index(inplace=True)

    b = a[(a['glhyid'] != '0') & (a[deviceid] != '')]
    #
    d = df[df[deviceid] != '']

    df2 = pd.merge(d, b, how='left')
    df2.loc[df2['glhyid'].notna(), 'hyid'] = df2['glhyid']
    del df2['glhyid']

    # 处理hyid是0 的真实匿名用户 ,用他们的userid/clientid作为标识
    df2.loc[df2['hyid'] == '0', 'hyid'] = df2[deviceid]

    # print(df2[df2['hyid'] == '0'])
    # df2.loc[df2['hyid'] == '0', 'UserType'] = 2
    # df2.loc[df2['hyid'] != '0', 'UserType'] = 1

    return df2


def getid(x):
    Lst = list(set(x['hyid'].tolist()))
    if '0' in Lst:
        Lst.remove('0')
    if Lst:
        return Lst[0]
    else:
        return '0'



