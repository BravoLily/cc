# -*-coding:utf-8 -*-
import numpy as np
from collections import Counter

from src.datacenter.algo.data_change import c_time_hour


def get_frequent(Lst, stdval, rangeval):
    if Lst is not np.nan:
        cntPre = Counter(Lst).most_common(8)
        cntnum = [i[1] for i in cntPre]
        if cntnum:
            if len(cntnum) == 1:
                return cntPre[0][0]
            elif 1 < np.std(cntnum, ddof=1) < stdval or (cntnum[0] - cntnum[1]) < rangeval:
                return np.nan
            else:
                return cntPre[0][0]


def get_online_period(x):
    timelist = [c_time_hour(i) for i in x]
    return get_frequent(timelist, 4, 3)