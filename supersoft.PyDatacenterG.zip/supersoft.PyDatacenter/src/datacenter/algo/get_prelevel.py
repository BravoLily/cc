# -*-coding:utf-8 -*-
def tjrisk(x):
    if x < 5:
        return 0
    elif x < 10:
        return 1
    elif x < 15:
        return 2
    else:
        return 3


def iprisk(x):
    if x < 3:
        return 0
    elif x < 5:
        return 1
    else:
        return 3

# def risk(df):


def add_cm(x):
    for i in range(len(x)):
        x[i] = 'cm_' + str(x[i])
    return x


def add_ycf(x):
    for i in range(len(x)):
        if x[i].startswith('ycf'):
            pass
        else:
            x[i] = 'ycf_' + str(x[i])
    return x


def add_ycf_x(x):
    if x.startswith('ycf'):
        pass
    else:
        x = 'ycf_' + str(x)
    return x