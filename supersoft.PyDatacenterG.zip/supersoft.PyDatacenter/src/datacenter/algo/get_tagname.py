# -*-coding:utf-8 -*-
def get_tag(col_tag, Tag):
    tag_content = col_tag.find_one({'Tag': Tag}, no_cursor_timeout=True)
    value = tag_content['Value']
    valueLst = []
    for i in value:
        valueLst.append(i['value'])
        # nameLst.append(i['name'])
    return valueLst


def name_to_value(col_tag, Tag, x):
    tag_content = col_tag.find_one({'Tag': Tag}, no_cursor_timeout=True)
    value = tag_content['Value']
    for val in value:
        if x == val['name']:
            return val['value']


def namelst_to_value(col_tag, Tag, x):
    tag_content = col_tag.find_one({'Tag': Tag}, no_cursor_timeout=True)
    value = tag_content['Value']
    newlst = []
    for data in x:
        for val in value:
            if data == val['name']:
                newlst.append(val['value'])
    return newlst


def range_to_value(value, x):
    if x:
        for val in value:
            Range = val['range']
            if Range[0] < x and (x < Range[1] or Range[1] == 0):
                return int(val['value'])


# if __name__ == '__main__':
#     tag_url = 'mongodb://ycfadmin:123@192.168.1.225:27017/tag.tag'
#     col_tag = conn_mongourl(tag_url)
#     get_tag(col_tag, 'web_browse_product')
