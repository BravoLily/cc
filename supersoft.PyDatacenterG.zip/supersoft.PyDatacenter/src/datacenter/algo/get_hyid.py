import datetime

from bson import ObjectId

from src.main.python.com.supersoft.datacenter.databases.mongo import conn_mongourl


def get_sc_hyid(sc, col, days=None):
    if days:
        gen_time = datetime.datetime.now() - datetime.timedelta(days=days)
        dummy_id = ObjectId.from_datetime(gen_time)
        hyid = col.find({"_id": {"$gte": dummy_id}}, no_cursor_timeout=True).distinct('hyid')
    else:
        hyid = col.find(no_cursor_timeout=True).distinct('hyid')
    if 0 in hyid:
        hyid.remove(0)
    rdd = sc.parallelize(hyid)
    return rdd


def get_hyid(col, days=None):
    # condition = {"regtime": {"$gte": "2018-01-01"}}
    if days:
        gen_time = datetime.datetime.now() - datetime.timedelta(days=days)
        dummy_id = ObjectId.from_datetime(gen_time)
        hyid = col.find({"_id": {"$gte": dummy_id}}, no_cursor_timeout=True).distinct('hyid')
    else:
        hyid = col.find(no_cursor_timeout=True).distinct('hyid')
    if 0 in hyid:
        hyid.remove(0)
    return hyid


if __name__ == '__main__':
    mongo_url_a = 'mongodb://ycfadmin:123@192.168.1.225:27017/statictis.cm_applog'
    col = conn_mongourl(mongo_url_a)
    activetag = col.find(no_cursor_timeout=True).distinct('activetag')
    print(activetag)