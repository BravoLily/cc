# -*-coding:utf-8 -*-
import pandas as pd
import numpy as np

from src.datacenter.algo.get_prelevel import iprisk
from src.datacenter.databases.mongo import conn_mongourl


def get_member_df(cm_mongo_url_member, ycf_mongo_url_member):

    col_cm = conn_mongourl(cm_mongo_url_member)
    col_ycf = conn_mongourl(ycf_mongo_url_member)

    s_cm = col_cm.find({}, {'_id': 0})
    s_ycf = col_ycf.find({}, {'_id': 0})

    a = list(s_cm)
    b = list(s_ycf)

    df = pd.DataFrame(a+b)

    return df


def get_risk(cm_mongo_url_member, ycf_mongo_url_member):

    """
    name: risk
    0: 无风险  1：低风险  2：中等风险  3.高风险
    动态变化
    :return:


    """
    df = get_member_df(cm_mongo_url_member, ycf_mongo_url_member)

    hyid = df['hyid'].tolist()
    dfhy = pd.DataFrame({'hyid': list(set(hyid))})

    # risk1 : 一个ip注册多个账号，认为风险程度高
    tmp = df[df['loginip'].notnull()]
    loginip = tmp['loginip'].tolist()
    # loginip = df[df['loginip'].notnull(), 'loginip'].tolist()
    dfip = pd.DataFrame({'loginip': list(set(loginip))})
    dfip.set_index(['loginip'], inplace=True, drop=False)
    dfip['hylist'] = df.groupby('loginip').apply(lambda x: x['hyid'].tolist())
    dfip = dfip.dropna()
    dfip['risk1'] = dfip['hylist'].apply(lambda x: iprisk(len(x)))
    del dfip['loginip']
    df2 = df.join(dfip, on='loginip')
    # dfhy['risk1'] = df2['risk1']
    dfhy = pd.merge(dfhy, df2, on='hyid')
    dfhy['risk1'].fillna(0, inplace=True)
    del df2

    # risk2 : 有余额 未绑卡, 没有佣金，认为风险程度高   bankcard:np.nan   mount/Blance: not np.nan(ycf)
    df.loc[df['bankcard'].isnull() &
           ((df['Blance'] > 0.0) | (df['amount'] > 0.0)) &
           ((df['commission'].isnull()) | (df['commission'] == 0)),
           'risk2'] = 3
    df['risk2'].fillna(0, inplace=True)

    # risk3 : 推荐用户过多,认为有风险  (并且推荐的用户超过80% 都没有登录过)

    # 先给hyid设置索引
    dfhy.set_index(['hyid'], inplace=True, drop=True)

    # 1. 没有登录过的人
    # 2. 按推荐用户分组
    # 3. 该推荐用户实际推荐数目
    # 4. 相除超过80%为风险用户

    df['latesttime'] = pd.to_datetime(df['latesttime'])
    df['regtime'] = pd.to_datetime(df['regtime'])
    df['diff_time'] = (df['latesttime'] - df['regtime']).dt.seconds / 60
    df['diff_time'] = round(df['diff_time'])
    # df['diff_time'] = df['diff_time'].apply(lambda x: dead(x))

    dfhy['tmp_cm_dead'] = df[df['diff_time'] < 120].groupby(df['tjhyid']).size()  # 推荐的用户没有登录 推荐数目
    dfhy['tmp_ycf_dead'] = df[df['diff_time'] < 120].groupby(df['tjHyid']).size()
    dfhy['tmp_cm_dead'].fillna(0, inplace=True)
    dfhy['tmp_ycf_dead'].fillna(0, inplace=True)
    dfhy.eval('risktj_dead= tmp_cm_dead+tmp_ycf_dead', inplace=True)
    del dfhy['tmp_cm_dead']
    del dfhy['tmp_ycf_dead']

    dfhy['tmp_cm'] = df.groupby(df['tjhyid']).size()  # 实际推荐数目
    dfhy['tmp_ycf'] = df.groupby(df['tjHyid']).size()
    dfhy['tmp_cm'].fillna(0, inplace=True)
    dfhy['tmp_ycf'].fillna(0, inplace=True)
    dfhy.eval('risktj= tmp_cm+tmp_ycf', inplace=True)
    del dfhy['tmp_cm']
    del dfhy['tmp_ycf']
    # print(dfhy[dfhy['risktj'] > 0])

    dfhy['risktj'].fillna(0, inplace=True)
    dfhy['risktj_dead'].fillna(0, inplace=True)

    dfhy.loc[dfhy['risktj_dead'] / dfhy['risktj'] >= 0.8, 'risk3'] = 3
    dfhy.loc[dfhy['risktj'] < 4, 'risk3'] = 0
    dfhy['risk3'].fillna(0, inplace=True)
    del dfhy['risktj_dead']
    del dfhy['risktj']
    dfhy.reset_index(inplace=True)

    # risk4 : 充值数额少
    df.loc[(df['recharge_amount'] > 1000), 'risk4'] = 0
    df.loc[((df['recharge_amount'] > 0) & (df['recharge_amount'] < 1000) &
            ((df['recharge_amount']/df['recharge_count']) < 100)), 'risk4'] = 2
    df['risk4'].fillna(1, inplace=True)

    # risk5 : 投资总额：少
    df.loc[(df['invest_amount'] > 5000) |
           (df['last_3m_invest_amount']/df['last_3m_invest_count'] > 1000) |
           (df['last_6m_invest_amount']/df['last_6m_invest_count'] > 1000), 'risk5'] = 0
    df.loc[(df['invest_amount']/df['invest_count'] < 200) |
           (df['last_3m_invest_amount']/df['last_3m_invest_count'] < 101) |
           (df['last_6m_invest_amount']/df['last_6m_invest_count'] < 101), 'risk5'] = 2
    df['risk5'].fillna(1, inplace=True)

    # risk6: 收益接近投资额
    df.loc[df['income']/df['invest_amount'] >= 0.5, 'risk6'] = 3
    df.loc[(df['income'] / df['invest_amount'] > 0.3) & (df['income'] / df['invest_amount'] < 0.5), 'risk6'] = 2
    df['risk6'].fillna(0, inplace=True)
    dfhy = pd.merge(dfhy, df, on='hyid', how='outer')
    a = dfhy.columns.values.tolist()
    b = ['risk1', 'risk2', 'risk3', 'risk4', 'risk5', 'risk6', 'hyid']
    for i in b:
        a.remove(i)
    dfhy.drop(a, axis=1, inplace=True)

    dfhy.set_index(['hyid'], inplace=True, drop=True)

    dfhy.fillna(0, inplace=True)
    dfhy['risk'] = dfhy.apply(lambda x: x.max(), axis=1)

    dfhy.drop(['risk1', 'risk2', 'risk3', 'risk4', 'risk5', 'risk6'], axis=1, inplace=True)
    # dfhy.drop(['risk4', 'risk5', 'risk6'], axis=1, inplace=True)

    dfhy.reset_index(inplace=True)
    dfhy.rename(columns={'hyid': 'UserID'}, inplace=True)
    dfhy['UserID'] = dfhy['UserID'].astype('str')

    # print(dfhy[dfhy['risk'] == 3])

    return dfhy
