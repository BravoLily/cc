# -*-coding:utf-8 -*-
import os
import pandas as pd
import numpy as np

from src.datacenter.algo.data_change import c_time_log
from src.datacenter.algo.get_anonymous import get_anonymous
from src.datacenter.algo.get_frequent import get_online_period
from src.datacenter.algo.get_tagname import get_tag, namelst_to_value, range_to_value
from src.datacenter.databases.mongo import conn_mongourl
from src.datacenter.databases.write_to_csv import write_to_csv
from src.datacenter.datatemp.dirpath import path


def start_log(cm_mongo_url_applog, ycf_mongo_url_applog,
              cm_mongo_url_weblog, ycf_mongo_url_weblog,
              cm_mongo_url_product, ycf_mongo_url_product,
              tag_url):

    col_applog_cm = conn_mongourl(cm_mongo_url_applog)
    col_weblog_cm = conn_mongourl(cm_mongo_url_weblog)
    col_tag = conn_mongourl(tag_url)
    colp_cm = conn_mongourl(cm_mongo_url_product)

    col_applog_ycf = conn_mongourl(ycf_mongo_url_applog)
    col_weblog_ycf = conn_mongourl(ycf_mongo_url_weblog)
    col_tag = conn_mongourl(tag_url)
    colp_ycf = conn_mongourl(ycf_mongo_url_product)

    webcsvname = 'weblog.csv'
    appcsvname = 'applog.csv'

    # 写weblog
    sw_cm = col_weblog_cm.find()
    sw_ycf = col_weblog_ycf.find()
    webfieldList = ['hyid', 'eventresult', 'pid', 'standtime', 'time', 'uid', 'userid']
    write_to_csv([sw_cm, sw_ycf], webcsvname, webfieldList)

    # 写applog
    sa_cm = col_applog_cm.find()
    sa_ycf = col_applog_ycf.find()
    appfieldList = ['hyid', 'device', 'system', 'activetag', 'pid', 'time', 'ip', 'clientid']
    write_to_csv([sa_cm, sa_ycf], appcsvname, appfieldList)

    # 读weblog
    dfw = pd.read_csv(os.path.join(path, webcsvname), keep_default_na=False, low_memory=False)
    os.remove(os.path.join(path, webcsvname))
    dfw['hyid'] = dfw['hyid'].apply(str)
    # 识别匿名id
    dfw = get_anonymous(dfw, 'userid')

    # 读applog
    dfa = pd.read_csv(os.path.join(path, appcsvname), keep_default_na=False, low_memory=False)
    os.remove(os.path.join(path, appcsvname))
    dfa['hyid'] = dfa['hyid'].apply(str)
    # 识别匿名id
    dfa = get_anonymous(dfa, 'clientid')

    # 提取dfa和dfw的id和作为hyid
    appid = dfa['hyid'].tolist()
    webid = dfw['hyid'].tolist()
    allid = list(set(appid + webid))
    dfhy = pd.DataFrame({'hyid': allid})
    dfhy.set_index(['hyid'], inplace=True, drop=False)

    # web上次在线时间  -----------------------------------------------------
    dfhy['web_last_online_period'] = dfw.groupby('hyid')\
        .apply(lambda dfwg: c_time_log(max(dfwg['time'].tolist())))

    # 累计登陆次数  ----------------------------------------------
    dfhy['web_total_online_times'] = dfw.groupby('hyid')\
        .apply(lambda dfwg: len(dfwg['uid'].drop_duplicates().tolist()))

    # web经常在线时段
    dfhy['web_online_period'] = dfw.groupby(dfw['hyid']).apply(lambda x: get_online_period(x['time'].tolist()))

    dfadd = pd.merge(dfw, dfhy, on='hyid', how='outer')

    # web经常浏览产品
    productlist = get_tag(col_tag, 'web_browse_product')
    dfhy['web_browse_product'] = dfadd[dfadd['eventresult'].isin(productlist)].groupby('hyid') \
        .apply(
        lambda dfad: namelst_to_value(col_tag, 'web_browse_product', dfad['eventresult'].drop_duplicates().tolist()))


    # a = dfhy[dfhy['web_browse_product'].notnull()]
    # dfhy['web_browse_product'] = a['web_browse_product'].apply(lambda x: list(set(x)))

    del dfadd
    del dfw

    """
    # web累计登陆次数
    a = dfw.groupby('hyid').apply(lambda x: x.drop_duplicates(['uid']))
    del a['hyid']
    dfhy['web_total_online_times'] = a.groupby('hyid')['uid'].count()
    # dfhy['web_total_online_times'].astype(int)
    """

    dfhy['device'] = dfa.groupby(dfa['hyid']).apply(lambda dfag: dfag['device'].tolist())
    a = dfhy[dfhy['device'].notnull()]
    dfhy['device'] = a['device'].apply(lambda x: list(set(x)))

    # dfhy['device'] = dfa['device'].groupby(dfa['hyid']).first()
    # dfhy['system'] = dfa['system'].groupby(dfa['hyid']).first()

    dfhy['system'] = dfa.groupby(dfa['hyid']).apply(lambda dfag: dfag['system'].tolist())
    a = dfhy[dfhy['system'].notnull()]
    dfhy['system'] = a['system'].apply(lambda x: list(set(x)))

    # app上次在线时间  last
    dfhy['app_last_online_period'] = dfa.groupby(dfa['hyid']) \
        .apply(lambda dfag: c_time_log(max(dfag['time'].tolist())))


    # app 经常在线时段
    dfhy['app_online_period'] = dfa.groupby(dfa['hyid']).apply(lambda x: get_online_period(x['time'].tolist()))


    # app累计登陆次数
    dfhy['app_total_online_times'] = dfa[dfa['activetag'] == '启动'].groupby('hyid').size()

    # app经常浏览产品
    a = dfa[dfa['pid'] > 0]
    product_cm = colp_cm.find()
    product_ycf = colp_ycf.find()
    pdf = pd.DataFrame(list(product_cm)+list(product_ycf))
    del pdf['_id']
    pdf.set_index(['pid'], inplace=True, drop=False)
    apdf = pd.merge(a, pdf, on='pid', how='left')
    apdf = apdf.dropna(subset=['protype'])
    dfhy['app_browse_product'] = apdf.groupby('hyid').apply(lambda ipdfg: ipdfg['protype'].tolist())

    del apdf
    del dfa

    # app经常在线时段

    # 双端
    dfhy['app_total_online_times'].fillna(0, inplace=True)
    dfhy['web_total_online_times'].fillna(0, inplace=True)

    dfhy['all_total_online_times'] = dfhy['web_total_online_times'] + dfhy['app_total_online_times']

    rangeLst = ['web_total_online_times', 'app_total_online_times',
                'all_total_online_times', 'app_last_online_period', 'web_last_online_period']

    dfhy['browsed_product'] = dfhy['web_browse_product'] + dfhy['app_browse_product']

    dfhy['web_browse_product'] = dfhy['web_browse_product'].apply(lambda x: list(set(x)) if x is not np.nan else np.nan)
    dfhy['app_browse_product'] = dfhy['app_browse_product'].apply(lambda x: list(set(x)) if x is not np.nan else np.nan)

    # print(dfhy[dfhy['browsed_product'].notna()].head())

    for i in rangeLst:
        tag_content = col_tag.find_one({'Tag': i}, no_cursor_timeout=True)
        value = tag_content['Value']
        dfhy[i] = dfhy[i].apply(lambda x: range_to_value(value, x))

    dfhy.rename(columns={'hyid': 'UserID'}, inplace=True)
    # print(dfhy)
    # 删除空USERID

    return dfhy


