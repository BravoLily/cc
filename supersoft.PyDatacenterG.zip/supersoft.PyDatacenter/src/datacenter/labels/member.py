# -*-coding:utf-8 -*-
import pandas as pd

from src.datacenter.algo.data_change import c_time_last
from src.datacenter.algo.get_tagname import range_to_value
from src.datacenter.databases.mongo import conn_mongourl


def start_member(cm_mongo_url_member, ycf_mongo_url_member, tag_url):
    col_cm = conn_mongourl(cm_mongo_url_member)
    col_ycf = conn_mongourl(ycf_mongo_url_member)
    col_tag = conn_mongourl(tag_url)

    s_cm = col_cm.find({}, {'_id': 0})
    s_ycf = col_ycf.find({}, {'_id': 0})

    df = pd.DataFrame(list(s_cm) + list(s_ycf))
    print(df['regtime'])

    # if days:
    #     gen_time = datetime.datetime.now() - datetime.timedelta(days=days)
    #     dummy_id = ObjectId.from_datetime(gen_time)
    #     s = col_cm.find({"_id": {"$gte": dummy_id}}, {'_id': 0})
    # else:
    #     s = col_cm.find({}, {'_id': 0})

    # deldata = ['name', 'sfzh', 'usersour', 'bankcard', 'card_address', 'bankname', 'birthday', ]
    # for i in deldata:
    #     del df[i]

    # df.set_index(['hyid'], inplace=True, drop=False)
    # print(df[df.index.duplicated()])

    # df['vip_level'] = df['vip_level'].apply(str)
    # df['tjhyid'] = df['tjhyid'].apply(str)

    df.loc[df['sex'] == 1, 'sex2'] = 1
    df.loc[df['sex'] == 2, 'sex2'] = 2
    del df['sex']

    df.rename(columns={'latesttime': 'last_login_time'}, inplace=True)
    del df['last_login_time']

    # rangeLst = ['age', 'tjnum', 'last_login_time', 'regtime']
    rangeLst = ['age', 'tjnum', 'regtime']

    # changetimelist = ['last_login_time', 'regtime']
    changetimelist = ['regtime']

    for i in changetimelist:
        df[i] = df[i].apply(lambda dfg: c_time_last(dfg))

    a = df[df['bankno'].notnull()]
    df['bankno'] = a['bankno'].apply(lambda x: list(set(x)))

    df['tjnum'] = df.groupby(df['tjhyid']).size()

    for i in rangeLst:
        tag_content = col_tag.find_one({'Tag': i}, no_cursor_timeout=True)
        value = tag_content['Value']
        df[i] = df[i].apply(lambda x: range_to_value(value, x))

    df['hyid'] = df['hyid'].apply(str)
    df['tjhyid'] = df['tjhyid'].apply(str)
    df['platform'] = df['platform'].apply(int)

    df['UserType'] = 1

    df.rename(columns={'phone': 'Mobile'}, inplace=True)
    df.rename(columns={'sex2': 'sex'}, inplace=True)
    df.rename(columns={'email': 'Email'}, inplace=True)
    df.rename(columns={'jgid': 'JPushID'}, inplace=True)
    df.rename(columns={'openid': 'WeChatOpendID'}, inplace=True)
    df.rename(columns={'bankcard': 'bankno'}, inplace=True)
    df.rename(columns={'hyid': 'UserID'}, inplace=True)

    return df
