# -*-coding:utf-8 -*-
from collections import Counter

import pandas as pd
import numpy as np

from src.datacenter.algo.get_anonymous import get_anonymous
from src.datacenter.algo.get_prelevel import add_cm, add_ycf, add_ycf_x
from src.datacenter.algo.get_tagname import get_tag, namelst_to_value
from src.datacenter.databases.mongo import conn_mongourl

def get_product_without_log(buyLst, productlist):
    """

    :param buyLst: 购买过的产品 []
    :param browsLst: 浏览过的产品 []
    :return:
    """
    if buyLst is not np.nan:
        buyPre = Counter(buyLst).most_common(8)
        buynum = [i[0] for i in buyPre]
        if buynum:
            if buynum[0] in productlist:
                return buynum[0]
        else:
            return ''


def buy_product_withoutlog(cm_mongo_url_member, ycf_mongo_url_member, mongo_url_tag, dfhy):
    col_cm = conn_mongourl(cm_mongo_url_member)
    col_ycf = conn_mongourl(ycf_mongo_url_member)
    col_tag = conn_mongourl(mongo_url_tag)
    productlist = get_tag(col_tag, 'invest_product')
    s_cm = col_cm.find({}, {'_id': 0, 'hyid': 1, 'invest_product': 1})
    s_ycf = col_ycf.find({}, {'_id': 0, 'hyid': 1, 'invest_product': 1})
    df_cm = pd.DataFrame(list(s_cm))
    df_ycf = pd.DataFrame(list(s_ycf))
    df_cm.dropna(axis=0, how='any', inplace=True)
    df_ycf.dropna(axis=0, how='any', inplace=True)
    df_cm['invest_product'] = df_cm['invest_product'].apply(lambda x: add_cm(x))
    df_ycf['invest_product'] = df_ycf['invest_product'].apply(lambda x: add_ycf(x))
    frames = [df_cm, df_ycf]
    dfhy_member = pd.concat(frames, ignore_index=True)
    dfhy_member['invest_product_predict'] = dfhy_member.apply(lambda x: get_product_without_log(x['invest_product'], productlist), axis=1)
    dfhy['hyid'] = dfhy.index
    result = pd.merge(dfhy, dfhy_member, on='hyid', how='left')
    del result['invest_product']

    return result


def get_product(buyLst, browsLst, productlist):
    """
    :param buyLst: 购买过的产品 []
    :param browsLst: 浏览过的产品 []
    :return:
    """
    if buyLst is not np.nan:
        buyPre = Counter(buyLst).most_common(8)
        buynum = [i[0] for i in buyPre]
        if buynum:
            if buynum[0] in productlist:
                return buynum[0]
        else:
            return ''

    elif browsLst is not np.nan:
        buyPre = Counter(browsLst).most_common(8)
        buynum = [i[0] for i in buyPre]
        buypre = [i[1] for i in buyPre]
        if buypre:
            if len(buypre) == 1:
                if buynum[0] in productlist:
                    return buynum[0]
                else:
                    return ''
            elif 1 < np.std(buypre, ddof=1) < 4 or (buypre[0] - buypre[1]) < 3:
                return ''
            else:
                if buynum[0] in productlist:
                    return buynum[0]
                else:
                    return ''
        else:
            return ''
    else:
        return ''


def product(cm_mongo_url_member, ycf_mongo_url_member,
            cm_mongo_url_applog, cm_mongo_url_weblog,
            ycf_mongo_url_applog, ycf_mongo_url_weblog,
            cm_mongo_url_product, ycf_mongo_url_product,
            mongo_url_tag):
    col_member_cm = conn_mongourl(cm_mongo_url_member)
    col_member_ycf = conn_mongourl(ycf_mongo_url_member)
    col_applog_cm = conn_mongourl(cm_mongo_url_applog)
    col_weblog_cm = conn_mongourl(cm_mongo_url_weblog)
    col_applog_ycf = conn_mongourl(ycf_mongo_url_applog)
    col_weblog_ycf = conn_mongourl(ycf_mongo_url_weblog)
    colp_cm = conn_mongourl(cm_mongo_url_product)
    colp_ycf = conn_mongourl(ycf_mongo_url_product)
    col_tag = conn_mongourl(mongo_url_tag)

    # 获取产品名称列表
    productlist = get_tag(col_tag, 'invest_product')

    # 获取invest product
    s_cm = col_member_cm.find({}, {'_id': 0, 'hyid': 1, 'invest_product': 1})
    s_ycf = col_member_ycf.find({}, {'_id': 0, 'hyid': 1, 'invest_product': 1})
    df_cm = pd.DataFrame(list(s_cm))
    df_ycf = pd.DataFrame(list(s_ycf))
    df_cm.dropna(axis=0, how='any', inplace=True)
    df_ycf.dropna(axis=0, how='any', inplace=True)
    # 为产品添加前缀
    df_cm['invest_product'] = df_cm['invest_product'].apply(lambda x: add_cm(x))
    df_ycf['invest_product'] = df_ycf['invest_product'].apply(lambda x: add_ycf(x))
    # 合并cm和ycf 投资列表
    frames = [df_cm, df_ycf]
    dfhy_member = pd.concat(frames, ignore_index=True)

    # 获取产品和pid
    product_cm = colp_cm.find({}, {'_id': 0, 'pid': 1, 'protype': 1})
    product_ycf = colp_ycf.find({}, {'_id': 0, 'pid': 1, 'protype': 1})

    df_product_cm = pd.DataFrame(list(product_cm))
    df_product_ycf = pd.DataFrame(list(product_ycf))
    df_product_ycf.dropna(axis=0, how='any', inplace=True)
    df_product_cm.dropna(axis=0, how='any', inplace=True)

    # dfhy = dfhy[~dfhy['invest_product_predict'].isin([''])]
    df_product_ycf = df_product_ycf[~df_product_ycf['protype'].isin([''])]

    df_product_cm['protype'] = df_product_cm['protype'].apply(lambda x: 'cm_' + str(x))
    df_product_ycf['protype'] = df_product_ycf['protype'].apply(lambda x: add_ycf_x(x))

    # 合并cm和ycf 产品列表
    frames = [df_product_cm, df_product_ycf]
    dfp = pd.concat(frames, ignore_index=True)

    dfp.set_index(['pid'], inplace=True, drop=False)

    #  获取浏览产品
    dfw_cm = col_weblog_cm.find({}, {'_id': 0, 'hyid': 1, 'userid': 1, 'eventresult': 1, 'pid': 1})
    dfw_ycf = col_weblog_ycf.find({}, {'_id': 0, 'hyid': 1, 'userid': 1, 'eventresult': 1, 'pid': 1})
    dfa_cm = col_applog_cm.find({}, {'_id': 0, 'hyid': 1, 'clientid': 1, 'activetag': 1, 'pid': 1})
    dfa_ycf = col_applog_ycf.find({}, {'_id': 0, 'hyid': 1, 'clientid': 1, 'activetag': 1, 'pid': 1})

    dfa = pd.DataFrame(list(dfa_cm) + list(dfa_ycf))
    dfw = pd.DataFrame(list(dfw_cm) + list(dfw_ycf))

    dfw = get_anonymous(dfw, 'userid')
    dfa = get_anonymous(dfa, 'clientid')

    # 提取dfa和dfw的id和作为hyid
    appid = dfa['hyid'].tolist()
    webid = dfw['hyid'].tolist()
    allid = list(set(appid + webid))
    dfhy_log = pd.DataFrame({'hyid': allid})
    # frames = [dfw, dfa]
    # dfhy_log = pd.concat(frames, ignore_index=True)
    # dfhy_log = dfhy_log[['hyid', 'UserType']]
    # print(dfhy_log)

    dfhy_log.set_index(['hyid'], inplace=True, drop=False)

    # app经常浏览产品
    a = dfa[dfa['pid'] > 0]
    apdf = pd.merge(a, dfp, on='pid', how='left')
    apdf = apdf.dropna(subset=['protype'])
    dfhy_log['app_browse_product'] = apdf.groupby('hyid').apply(lambda ipdfg: ipdfg['protype'].tolist())

    # web经常浏览产品
    w = dfw[dfw['pid'] > 0]
    wpdf = pd.merge(w, dfp, on='pid', how='left')
    wpdf = wpdf.dropna(subset=['protype'])
    dfhy_log['web_browse_product'] = wpdf.groupby('hyid').apply(lambda ipdfg: ipdfg['protype'].tolist())

    # 浏览过的产品
    dfhy_log['browsed_product'] = dfhy_log['web_browse_product'] + dfhy_log['app_browse_product']

    # 预测
    dfhy = pd.merge(dfhy_log, dfhy_member, on='hyid', how='outer')

    dfhy['invest_product_predict'] = dfhy.apply(
        lambda x: get_product(x['invest_product'], x['browsed_product'], productlist), axis=1)

    dfhy.drop(['app_browse_product', 'web_browse_product', 'browsed_product', 'invest_product'], axis=1, inplace=True)
    dfhy = dfhy[~dfhy['invest_product_predict'].isin([''])]
    dfhy.rename(columns={'invest_product_predict': 'invest_product'}, inplace=True)
    dfhy.rename(columns={'hyid': 'UserID'}, inplace=True)
    dfhy['UserID'] = dfhy['UserID'].astype('str')

    # print(dfhy[dfhy['invest_product_predict'].notnull()])

    return dfhy

# if __name__ == '__main__':
#     cm_mongo_url_member = 'mongodb://ycfadmin:123@192.168.1.225:27017/statictis.cm_member_baseinfo'
#     ycf_mongo_url_member = 'mongodb://ycfadmin:123@192.168.1.225:27017/statictis.ycf_member_baseinfo'
#     cm_mongo_url_member = 'mongodb://ycfadmin:123@192.168.1.225:27017/statictis.cm_member_baseinfo'
#     ycf_mongo_url_member = 'mongodb://ycfadmin:123@192.168.1.225:27017/statictis.ycf_member_baseinfo'
#     mongo_url_tag = 'mongodb://ycfadmin:123@192.168.1.225:27017/tag.tag'
#     cm_mongo_url_applog = 'mongodb://ycfadmin:123@192.168.1.225:27017/statictis.cm_applog'
#     ycf_mongo_url_applog = 'mongodb://ycfadmin:123@192.168.1.225:27017/statictis.ycf_applog'
#     cm_mongo_url_weblog = 'mongodb://ycfadmin:123@192.168.1.225:27017/statictis.cm_weblog'
#     ycf_mongo_url_weblog = 'mongodb://ycfadmin:123@192.168.1.225:27017/statictis.ycf_weblog'
#     cm_mongo_url_product = 'mongodb://ycfadmin:123@192.168.1.225:27017/statictis.cm_product_baseinfo'
#     ycf_mongo_url_product = 'mongodb://ycfadmin:123@192.168.1.225:27017/statictis.ycf_product_baseinfo'
#
#     dfhy = product(cm_mongo_url_member, ycf_mongo_url_member,
#             cm_mongo_url_applog, cm_mongo_url_weblog,
#             ycf_mongo_url_applog, ycf_mongo_url_weblog,
#             cm_mongo_url_product, ycf_mongo_url_product,
#             mongo_url_tag)
#     print(dfhy)

