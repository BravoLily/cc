# -*-coding:utf-8 -*-
import pandas as pd

from src.datacenter.algo.get_tagname import range_to_value
from src.datacenter.databases.mongo import conn_mongourl


def start_invest(cm_mongo_url_invest, ycf_mongo_url_invest, mongo_url_p, mongo_url_p_ycf, tag_url):
    # invest
    col_cm = conn_mongourl(cm_mongo_url_invest)
    col_ycf = conn_mongourl(ycf_mongo_url_invest)

    # if days:
    #     gen_time = datetime.datetime.now() - datetime.timedelta(days=days)
    #     dummy_id = ObjectId.from_datetime(gen_time)
    #     s = col_cm.find({"_id": {"$gte": dummy_id}}, {'_id': 0})
    # else:
    #     s = col_cm.find({}, {'_id': 0})

    s = col_cm.find({}, {'_id': 0})
    m = col_ycf.find({}, {'_id': 0})

    idf = pd.DataFrame(list(s)+list(m))
    del idf['ProductName']

    # product
    colp_cm = conn_mongourl(mongo_url_p)
    colp_ycf = conn_mongourl(mongo_url_p_ycf)
    product_cm = colp_cm.find()
    product_ycf = colp_ycf.find()
    pdf = pd.DataFrame(list(product_cm) + list(product_ycf))
    del pdf['_id']
    pdf.set_index(['pid'], inplace=True, drop=False)


    """
    1. 投资次数 invest_cnt
    2. 投资总额 invest_total
    3. 最高投资额 invest_highest
    4. 预测投资额 investment
    5. 投资产品偏好 invest_product   #产品购买偏好
    6. 投资过的产品
    """

    col_tag = conn_mongourl(tag_url)
    rangeLst = ["invest_cnt", "invest_total", "invest_highest"]

    colums = ['hyid']
    dfhy = pd.DataFrame(columns=colums)
    dfhy['hyid'] = idf['hyid'].drop_duplicates()
    dfhy.set_index(['hyid'], inplace=True, drop=False)

    dfhy['invest_cnt'] = idf.hyid.value_counts()
    dfhy['invest_total'] = idf['amount'].groupby(idf['hyid']).sum().astype(int)
    dfhy['invest_highest'] = idf['amount'].groupby(idf['hyid']).max().astype(int)

    ipdf = pd.merge(idf, pdf, on='pid', how='left')
    ipdf = ipdf.dropna(subset=['protype'])
    # ipdf['protype'] = ipdf['protype'].apply(int).apply(str)
    dfhy['invested_product'] = ipdf.groupby('hyid').apply(lambda ipdfg: ipdfg['protype'].tolist())

    for i in rangeLst:
        tag_content = col_tag.find_one({'Tag': i}, no_cursor_timeout=True)
        value = tag_content['Value']
        dfhy[i] = dfhy[i].apply(lambda x: range_to_value(value, x))

    dfhy['hyid'] = dfhy['hyid'].apply(str)
    dfhy.rename(columns={'hyid': 'UserID'}, inplace=True)

    return dfhy

