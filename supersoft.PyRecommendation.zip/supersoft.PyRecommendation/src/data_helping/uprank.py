# coding=utf-8
from functools import reduce

from src.data_helping.mongo_helping import rank_find
from src.data_helping.read_write import read_json


def uprank(uid, newview, martix, k, nitem=50):

    rank = dict()
    for i in newview:
        try:
            for j, wj in sorted(martix[i].items(), key=lambda x: x[1], reverse=True)[0:k]:
                if j in newview:
                    continue
                rank.setdefault(j, 0)
                rank[j] += wj

        except KeyError:
            continue
    rank1 = dict(sorted(rank.items(), key=lambda x: x[0], reverse=True)[0:nitem])

    rank2 = rank_find(uid)

    if rank1 is None:
        return None

    intersection = reduce(lambda x, y: x & y, map(dict.keys, [rank1, rank2]))
    subtract = reduce(lambda x, y: x - y, map(dict.keys, [rank1, rank2]))

    for key in rank2:
        rank2[key] *= 0.9

    for key in intersection:
        rank2[key] += 0.1*rank1[key]

    for key in subtract:
        rank2[key] = rank1[key]

    rank2 = dict(sorted(rank2.items(), key=lambda x: x[1], reverse=True)[0:nitem])

    return rank2


# UNITTEST
if __name__ == '__main__':

    itemsim = read_json(name='ldasim.json')
    rank = uprank("91b8521b-9ff3-4604-ba7a-97470b568c56", ['1168'], itemsim, 10, nitem=50)
    print(rank)

