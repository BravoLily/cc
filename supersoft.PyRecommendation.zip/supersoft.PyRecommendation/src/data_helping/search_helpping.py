# coding=utf-8
from src.sourcedata.search import Search


def allview():
    se = Search()
    docs = se.search(keyword="1", proj='idx')
    allview = []
    for line in docs:
        try:
            allview.append(str(line['viewid']))
        except KeyError:
            continue
    return allview


def get_createDate(vid):
    se = Search()
    results = se.search(keyword=vid, proj='viewid')
    try:
        for res in results:
            return res['createdate']
    except TypeError:
        return None