# coding=utf-8
import json
import os

import jieba
import numpy as np
from gensim import models
from gensim.corpora import Dictionary

from src.setting.settings import ModelPath
from src.sourcedata.search import Search


def cacul_sim(list_doc1, list_doc2):
    try:
        sim = np.dot(list_doc1, list_doc2) / (np.linalg.norm(list_doc1) * np.linalg.norm(list_doc2))
    except ValueError:
        sim = 0.01

    sim = float(sim)
    return sim


def get_listdoc(num, doc_lda):
    """

    :param num: 主题数量（聚类数量）
    :param doc_lda: 主题分布
    :return:
    """
    list_doc = [0.0]*num
    for i in doc_lda:
        list_doc[i[0]] = i[1]

    # print("get_listdoc: ", list_doc)

    return list_doc


class LDA_Result:
    def __init__(self, modelpath=os.path.join(ModelPath, 'lda.model'), dictpath=os.path.join(ModelPath, 'lda.dict')):

        self.model = models.ldamodel.LdaModel.load(modelpath)
        self.dictpath = dictpath

    def topic_distribution(self, doc):

        test_doc = list(jieba.cut(doc, HMM=True))

        dictionary = Dictionary.load(self.dictpath)

        doc_bow = dictionary.doc2bow(test_doc)

        doc_lda = self.model[doc_bow]

        return doc_lda

    def get_sim(self, n, doc1, doc2):
        """
        :param n: 聚类数量
        :param doc1:
        :param doc2:
        :return:
        """
        doc_lda1 = self.topic_distribution(doc1)
        doc_lda2 = self.topic_distribution(doc2)
        list_doc1 = get_listdoc(n, doc_lda1)
        list_doc2 = get_listdoc(n, doc_lda2)
        try:
            sim = np.dot(list_doc1, list_doc2) / (np.linalg.norm(list_doc1) * np.linalg.norm(list_doc2))
        except ValueError:
            sim = 0.01

        sim = float(sim)
        return sim

    def get_tag(self, doc):
        doc_lda = self.topic_distribution(doc)
        loc_list = [i[1] for i in doc_lda]
        maxidx = loc_list.index(max(loc_list))
        tag = doc_lda[maxidx][0]
        return tag


def ViewSim(model):
    se = Search()
    sevid = Search()
    docs = se.search(keyword="1", proj='idx')
    viewid = []
    ldaSim = dict()
    for line in docs:
        if 'content' in line.keys() and len(line['content']):
            viewid.append(str(line['viewid']))
    for vid in viewid:
        ldaSim.setdefault(vid, dict())
        vid_content = ""
        for res in sevid.search(vid):
            vid_content = res['content']
        for results in se.search('1'):
            vidj = str(results['viewid'])
            if vidj == vid or vidj not in viewid:
                continue
            vidj_content = results['content']
            sim = model.get_sim(8, vid_content, vidj_content)
            ldaSim[vid].setdefault(vidj, 0.0)
            ldaSim[vid][vidj] = sim
        print(vid)

    with open(os.path.join(ModelPath, "ldaSim.json"), 'w', encoding='utf8') as jf:
        json.dump(ldaSim, jf)
        print("success save ldaSim dict ......")


if __name__ == '__main__':
    modelname = 'lda.model'
    lda = LDA_Result(modelpath=modelname)
    ViewSim(lda)

