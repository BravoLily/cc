# coding=utf-8
import time

from src.sourcedata.mongo_conn import conn_url

collection = conn_url(urlname="url_rank")
collection_cold = conn_url(urlname="url_cold")


def rank_insert(userid, rank):
    for viewid, score in rank.items():
        dic = dict()
        dic['userid'] = userid
        dic['viewid'] = int(viewid)
        dic['score'] = score
        dic['time'] = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
        collection.insert(dic)


def cold_del():
    collection_cold.drop()


def cold_insert(rank):
    for viewid, score in rank.items():
        dic = dict()
        dic['viewid'] = int(viewid)
        dic['score'] = score
        dic['time'] = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
        collection_cold.insert(dic)


def rank_update(userid, viewid, score):
    try:
        collection.update({"userid": userid, "viewid": int(viewid)}, {'$set': {'score': score}})
    except Exception:
        pass


def rank_find(userid):
    rank = dict()
    try:
        data = collection.find({"userid": userid})
        for d in data:
            rank[d['viewid']] = d['score']
        return rank
    except Exception:
        return None


def score_find(userid):
    flag = False
    if collection.find_one({"userid": userid}):
        flag = True
    # print('是否通过浏览记录推荐过: ', flag)
    return flag


