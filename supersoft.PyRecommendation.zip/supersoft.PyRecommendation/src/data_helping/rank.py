# coding=utf-8
import math

from src.data_helping.log_helpping import ViewLog


class Recommend:

    def __init__(self, train, sim_martix, test=None):
        self.train = train    # {userid: {viewid: score}, ……}
        self.test = test
        self.sim_martix = sim_martix
        self.vl = ViewLog()

    def recommend(self, user, train=None, k=40, nitem=50):
        """

        :param user: 用户id
        :param train: 训练数据
        :param k: 最相似个数
        :param nitem: 推荐个数
        :return: 推荐字典 {id: score,}
        """

        train = train or self.train
        rank = dict()
        ru = train.get(user, {})
        viewId, _ = self.vl.get_viewId(user)

        viewId = sorted(viewId, key=lambda x: int(x), reverse=True)

        for i in viewId:
            pi = ru[i]
            try:
                for j, wj in sorted(self.sim_martix[i].items(), key=lambda x: x[1], reverse=True)[0:k]:
                    if j in viewId:
                        continue
                    rank.setdefault(j, 0)
                    rank[j] += pi * wj
            except KeyError:
                continue
        rank = dict(sorted(rank.items(), key=lambda x: x[1], reverse=True)[0:nitem])
        return rank

    def recallAndPrecision(self, train=None, test=None, k=40, nitem=50):
        """
        准确率和召回率
        :param train:
        :param test:
        :param k:
        :param nitem:
        :return: recall, precision
        """
        train = train or self.train
        test = test or self.test
        hit = 0  # 准确数
        recall = 0  # 召回率
        precision = 0  # 精度
        vl = ViewLog()
        for user in test.keys():
            viewid, _ = vl.get_viewId(user)
            # tu = test.get(user, {})
            rank = self.recommend(user, train=train, k=k, nitem=nitem)
            for item, _ in rank.items():
                if item in viewid:
                    hit += 1
            recall += len(viewid)
            precision += len(rank)
        return hit/(recall * 1.0), hit/(precision * 1.0)

    def coverage(self, train=None, test=None, k=8, nitem=50):
        """
        覆盖率
        :param train:
        :param test:
        :param k:
        :param nitem:
        :return:
        """
        train = train or self.train
        test = test or self.test
        recommend_items = set()
        all_items = set()
        for user in test.keys():
            for item in test[user].keys():
                all_items.add(item)
            rank = self.recommend(user, train, k=k, nitem=nitem)
            for item, _ in rank.items():
                recommend_items.add(item)
        return len(recommend_items) / (len(all_items) * 1.0)

    def popularity(self, train=None, test=None, k=8, nitem=50):

        train = train or self.train
        test = test or self.test
        item_popularity = dict()
        for user, items in train.items():
            for item in items.keys():
                item_popularity.setdefault(item, 0)
                item_popularity[item] += 1
        ret = 0
        n = 0
        for user in test.keys():
            rank = self.recommend(user, train, k=k, nitem=nitem)
            for item, _ in rank.items():
                try:
                    ret += math.log(1 + item_popularity[item])
                    n += 1
                except KeyError:
                    continue
        return ret / (n * 1.0)
