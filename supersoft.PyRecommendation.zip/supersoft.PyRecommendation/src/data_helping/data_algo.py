# coding=utf-8
def getrange(value, ran, sc):

    score = sc[-1]
    for idx, i in enumerate(ran):
        if value <= i:
            score = sc[idx]
            break
    return score
