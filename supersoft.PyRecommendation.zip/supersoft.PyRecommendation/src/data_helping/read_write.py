# coding=utf-8
import json
import os

from src.setting.log import setlog
from src.setting.settings import ModelPath

lg = setlog()


def write_json(name, data, path=ModelPath):
    wfile = os.path.join(path, name)
    with open(wfile, 'w', encoding='utf8') as sj:
        json.dump(data, sj)

        lg.info("success save %s dict" % name)


def read_json(name, path=ModelPath):
    rfile = os.path.join(path, name)
    with open(rfile, 'r', encoding='utf8') as rf:
        rdata = json.load(rf)
    return rdata
