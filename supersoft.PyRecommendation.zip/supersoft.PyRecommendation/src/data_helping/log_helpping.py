# coding=utf-8
import re

from src.sourcedata.mongo_conn import conn_url


class ViewLog:
    def __init__(self, urlname="url_log"):
        self.col = conn_url(urlname)

    def get_userId(self):
        """
        获取所有用户无重复id
        :return: 用户id list
        """
        nstr = ""
        weblog = self.col.find({"Userid": {"$ne": nstr, '$exists': True}, "Url": {'$regex': "financialplanner/view/details"}})
        Userid = []

        for item in weblog:
            try:
                Userid.append(item['Userid'])
            except KeyError:
                continue

        Userid = list(set(Userid))

        return Userid

    def get_viewCount(self, *userid):
        """
        获取用户每篇文章阅读次数
        :param userid:
        :return:
        """
        if userid:
            weblog = self.col.find({"Userid": userid[0], "Url": {'$regex': "financialplanner/view/details"}})
        else:
            weblog = self.col.find({"Url": {'$regex': "financialplanner/view/details"}})
        viewCount = {}
        for item in weblog:
            m = re.findall(r'(\w*[0-9]+)\w*', item['Url'])
            vid = m[1]
            if vid in viewCount.keys():
                viewCount[vid] += 1
            else:
                viewCount[vid] = 1

        return viewCount

    def get_viewTime(self, *userid):
        """
        获取用户每篇文章阅读时间（停留时间）
        :param userid:
        :return:
        """
        if userid:
            weblog = self.col.find({"Userid": userid[0], "Url": {'$regex': "financialplanner/view/details"}})
        else:
            weblog = self.col.find({"Url": {'$regex': "financialplanner/view/details"}})

        viewTime = {}
        if weblog:
            for item in weblog:
                m = re.findall(r'(\w*[0-9]+)\w*', item['Url'])
                vid = m[1]
                if vid in viewTime.keys():
                    viewTime[vid] += item['StandTime']
                else:
                    viewTime[vid] = item['StandTime']

        return viewTime

    def get_startTime(self, Userid):
        """
        获取用户每篇文章最近阅读时间
        :param Userid:
        :return:
        """
        weblog = self.col.find({"Userid": Userid, "Url": {'$regex': "financialplanner/view/details"}})
        viewStartTime = {}
        for item in weblog:
            m = re.findall(r'(\w*[0-9]+)\w*', item['Url'])
            vid = m[1]
            if vid in viewStartTime.keys():
                if item['StartTime'] > viewStartTime[vid]:
                    viewStartTime[vid] = item['StartTime']
                else:
                    continue
            else:
                viewStartTime[vid] = item['StartTime']
        return viewStartTime

    def get_viewId(self, *userid):
        """
        获取（每个用户）所有浏览文章无重复id/有重复id
        :param userid:
        :return: vid, vvid
        """
        if userid:
            weblog = self.col.find({"Userid": userid[0], "Url": {'$regex': "financialplanner/view/details"}})
        else:
            weblog = self.col.find({"Url": {'$regex': "financialplanner/view/details"}})
        vvid = []
        for item in weblog:
            try:
                m = re.findall(r'(\w*[0-9]+)\w*', item['Url'])
                vvid.append(m[1])
            except KeyError:
                continue
        vid = list(set(vvid))
        return vid, vvid
