import os

import sys
from pyspark import SparkContext

from src.data_helping.mongo_helping import cold_del, cold_insert
from src.offline.coldrank import coldboot
from src.offline.lda_cluster import get_dict, lda_cluster, get_sim, get_tag
from src.offline.preference import get_user_prefer, item_sim
from src.offline.search_engine import create_search
from src.setting.log import setlog
from src.setting.settings import filename, ModelPath
from src.sourcedata.search import Search

"""
脚本功能： offline_boot

提交命令：
spark-submit --py-files dist/recommendation-0.1.0-py3.6.egg offline_boot.py argv1 argv2 argv3

其他同boot

"""

lg = setlog()
# 判断spark 环境
spark_name = os.environ.get('SPARK_HOME', None)
if not spark_name:
    raise ValueError('spark环境错误')

try:
    sql = sys.argv[2].split(':')
    sql_dbname = sql[3]
except IndexError:
    lg.error("PARAMETER 2 ERROR")
    sys.exit(1)


sc = SparkContext()

# seacher engine
lg.info("seacher engine")
indexpath = filename["indexpath"]
indexname = filename["indexname"]

# 不用判断文件是否存在。不存在就生成，存在就更新
create_search(indexpath, indexname, sql_dbname)

# coldrank
lg.info("coldrank")
cold_del()
lg.info("success delete old coldrank ......")
rankk = coldboot()

lg.info("success caculate coldrank ......")

cold_insert(rankk)

se = Search()


# lda
lg.info("lda")
ldasimname = filename['ldasimname']
tagToViewfile = filename['tagToViewfile']
viewToTagfile = filename['viewToTagfile']
ldamodel = filename['ldamodel']
ldadict = filename['ldadict']
modelfile = os.path.join(ModelPath, ldamodel)
dictfile = os.path.join(ModelPath, ldadict)
docs1 = se.search('1', proj='idx')
dictionary, train, viewID = get_dict(docs1, dictfile)
n_topic = 6
doc_topic = lda_cluster(n_topic, dictionary, train, modelfile)
get_sim(n_topic, viewID, doc_topic, ldasimname)
get_tag(viewID, doc_topic, tagToViewfile, viewToTagfile)

# word2vec
#lg.info("word2vec")
#size = 256
#doc2vecmodelname = filename['doc2vecmodelname']
#doc2vecsimname = filename['doc2vecsimname']
#docs2 = se.search('1', proj='idx')
#doc2vec(docs=docs2, savename=doc2vecmodelname, simname=doc2vecsimname, size=size)

# preference
trainname = filename['trainname']
testname = filename['testname']
train, _ = get_user_prefer(train_file=trainname, test_file=testname)
preferencesimname = filename['preferencesimname']
item_sim(train, simname=preferencesimname)

sc.stop()
