# coding=utf-8
import os
import re
import sys

from src.data_helping.mongo_helping import cold_del, cold_insert, score_find, rank_insert
from src.data_helping.rank import Recommend
from src.data_helping.read_write import read_json
from src.data_helping.uprank import uprank
from src.offline.coldrank import coldboot
from src.offline.lda_cluster import get_dict, lda_cluster, get_sim, get_tag
from src.offline.preference import get_user_prefer, item_sim
from src.offline.search_engine import create_search
from src.setting.log import setlog
from src.setting.settings import ModelPath, filename
from src.sourcedata.mongo_conn import conn_url
from src.sourcedata.search import Search

"""
打包命令
cd $path
python3 supersoft.PyRecommendation/src/setting/setup.py bdist_egg

spark-submit --py-files eggfile bootfile arvg1 arvg2 arvg3 arvg4 arvg5 arvg6 arvg7 arvg8 arvg9
 
 arvg1: kafka配置
        host:kafka-port:topic
        eg: 192.168.1.225:9092:Statistic
         
 arvg2: sqlserver配置
        sqlserver_host:username:password:dbname
        DESKTOP-PSPOMTB\SQL2014:sa:123:cazuresnsdb
        
 arvg3: mongodb
        mongodb连接 训练数据  WebLogger 
        mongodb://ycfadmin:123@192.168.1.225:27017/log.WebLogger_58ycf.com.bak
 
 argv4：weblogger表名
        WebLogger_58ycf.com.bak
        
 arvg5: mongodb
        mongodb连接 冷启动表 cold_recommendation 
        mongodb://ycfadmin:123@192.168.1.225:27017/statictis.cold_recommendation

 argv6：冷启动表 表名
        cold_recommendation
        
 arvg7: mongodb
        mongodb连接 推荐表 view_recommendation 
        mongodb://ycfadmin:123@192.168.1.225:27017/statictis.view_recommendation
        
 argv8：推荐表 表名
        view_recommendation
        
 arvg9: modelpath
        训练模型存储位置
        $path/supersoft.PyRecommendation/data/model
        
 
eg: 
spark-submit --py-files /home/lili/dist/recommendation-0.1.0-py3.6.egg \
/home/lili/supersoft.PyRecommendation/src/service/boot.py \
192.168.1.235:9092:Statistic \
192.168.1.225:sa:123:cazuresnsdb \
mongodb://ycfadmin:123@192.168.1.225:27017/log.WebLogger_58ycf.com.bak \
WebLogger_58ycf.com.bak \
mongodb://ycfadmin:123@192.168.1.225:27017/statictis.cold_recommendation \
cold_recommendation \
mongodb://ycfadmin:123@192.168.1.225:27017/statictis.view_recommendation \
view_recommendation \
/home/lili/supersoft.PyRecommendation/data/model
"""


"""
推荐流程：

1. 用户第一次登陆：冷启动coldboot，不作处理

2. 用户非第一次登陆（有历史log）
    2.1 mongodb中有该用户数据
        2.1.1 本次未浏览文章： 不再计算，直接推荐
        2.1.2 本次浏览文章(3) ：在线计算 uprank
    2.2 mongodb中无该用户数据 ：正常推荐, recommend(),并将数据写入
"""

lg = setlog()

lg.removeHandler(lg.handlers)

# 判断spark环境
spark_name = os.environ.get('SPARK_HOME', None)
if not spark_name:
    lg.error('spark environment wrong')
    raise ValueError('spark environment wrong')

try:
    from pyspark import SparkContext
    from pyspark import SparkConf
    from pyspark.streaming import StreamingContext
    from pyspark.streaming.kafka import KafkaUtils

    lg.debug("Successfully imported Spark Modules")

except ImportError as e:
    lg.error(e)
    sys.exit(1)


conf = SparkConf()
conf.set("spark.driver.maxResultSize", "0")
conf.set("spark.driver.memory", "2g")


# 判断索引文件是否存在
sql = sys.argv[2].split(':')
if not os.path.exists(os.path.join(ModelPath, filename['indexpath'])):
    lg.debug('on creating index file')
    create_search(filename['indexpath'], filename['indexname'], sql[3])
lg.debug('index file exist')


# 判断冷启动表是否存在
col = conn_url("url_cold")
s = col.find_one()
if not s:
    lg.debug('on creating cold-start sheet')
    cold_del()
    rankk = coldboot()
    cold_insert(rankk)
    lg.debug("insert cold rank")
lg.debug('cold-start sheet exist')

# 判断模型文件是否存在
se = Search()
if not os.path.exists(os.path.join(ModelPath, filename['ldasimname'])):
    lg.debug('on creating model file 1')
    docs1 = se.search('1', proj='idx')
    dictionary, train, viewID = get_dict(docs1, os.path.join(ModelPath, filename['ldadict']))
    doc_topic = lda_cluster(6, dictionary, train, os.path.join(ModelPath, filename['ldamodel']))
    get_sim(6, viewID, doc_topic, filename['ldasimname'])
    get_tag(viewID, doc_topic, filename['tagToViewfile'], filename['viewToTagfile'])
# if not os.path.exists(os.path.join(ModelPath, filename['doc2vecsimname'])):
#     lg.debug('on creating model file 2')
#     docs2 = se.search('1', proj='idx')
#     doc2vec(docs=docs2, savename=filename['doc2vecmodelname'], simname=filename['doc2vecsimname'], size=256)
if not os.path.exists(os.path.join(ModelPath, filename['preferencesimname'])):
    lg.debug('on creating model file 3')
    train, _ = get_user_prefer(train_file=filename['trainname'], test_file=filename['testname'])
    item_sim(train, simname=filename['preferencesimname'])
lg.debug('model file exist')

try:
    train = read_json(name=filename['trainname'])
    itemsim = read_json(name=filename['preferencesimname'])
except IOError as e:
    lg.error(e)
    sys.exit(1)

ibcitem = Recommend(train, itemsim)


def result(rdd):
    """
    ClientId:Domain:Userid:FirstVisit:Uid:PageTa:hyid:Ip:Title: \
    AjaxType:Referrer:Url:AppVision:StartTime:EndTime:StandTime:Appid
    :return:
    """

    data = rdd.collect()

    lg.info(data)

    urlfilter = "financialplanner/view/details"

    userlist = set()
    first = set()
    newview = dict()
    for i in data:
        m = i.split(':')
        try:
            Userid = m[2]
            FirstVisit = m[3]
            Url = m[12]
        except IndexError:
            continue

        userlist.add(Userid)

        if FirstVisit == 'true':
            first.add(Userid)

        newview.setdefault(Userid, list())
        if urlfilter in Url:
            ur = re.findall(r'(\w*[0-9]+)\w*', Url)
            newview[Userid].append(ur[1])

    for uid in userlist:
        lg.info('用户: '+uid)
        if uid in first:  # (1)
            lg.info('First Login')

        else:  # (2)
            if score_find(uid):  # (2.1)
                if newview[uid]:  # (2.1.2)
                    lg.info('uprank')
                    rank = uprank(uid, newview[uid], itemsim, k=40, nitem=200)
                    rank_insert(uid, rank)
                else:
                    lg.info("No Reading This Turn")

            else:  # (2.2)
                lg.info('recommend')
                rank = ibcitem.recommend(user=uid, k=20, nitem=200)
                lg.info('end')
                if rank:
                    rank_insert(uid, rank)
                else:
                    lg.info('No Recommend')


def start():
    sc = SparkContext(conf=conf)
    ssc = StreamingContext(sc, 10)

    try:
        # 192.168.1.235:9092:Statistic
        ka = sys.argv[1].split(':')
        brokers = ka[0]+':'+ka[1]
        topic = ka[2]

    except IndexError:
        lg.error("PARAMETER 1 ERROR")
        sys.exit(1)

    kafkastream = KafkaUtils.createDirectStream(ssc, [topic], {"metadata.broker.list": brokers})

    lines = kafkastream.map(lambda x: x[1])

    lines.foreachRDD(result)

    ssc.start()
    ssc.awaitTermination()


if __name__ == '__main__':

    start()
