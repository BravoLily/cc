# coding=utf-8
import logging
import os
import re
from collections import namedtuple

import jieba
from gensim.models import Doc2Vec

from src.data_helping.read_write import write_json
from src.setting.log import setlog
from src.setting.settings import ModelPath

"""
脚本功能： 1. 文本向量化
          2. 计算相似度
    
执行级别： 2 （需要先执行search_engine将数据索引化）


附加参数：暂无。

保存文件：
    doc2vec.model
    
保存路径：
    默认：model文件夹下
    
"""
lg = setlog()
jieba.load_userdict(os.path.join(ModelPath, "word.txt"))


analyzedDocument = namedtuple('AnalyzedDocument', 'words tags')


def seg(line):
    seg_list = jieba.cut(line, HMM=True)
    seged_list = []
    for s in seg_list:
        seged_list.append(s)
    return seged_list


def cleaning(data):
    """
    文本忽略标点及英文字符，仅提取中文字符
    """
    words = re.findall(r"[\u4e00-\u9fa5]+", data)
    return ''.join(words)


idlist = set()


class Document:
    def __init__(self, docs):
        self.docs = docs

    def __iter__(self):

        for result in self.docs:
            try:
                vid = str(result['viewid'])
                line = cleaning(result['content'])
                content = seg(line)
                doc = analyzedDocument(content, [vid])
                idlist.add(vid)
                yield doc
            except KeyError:
                continue


def doc2vec(docs, savename, simname, size=100):
    """
    # PV-DM w/concatenation - window=5 (both sides) approximates paper's 10-word total window size
    Doc2Vec(sentences,dm=1, dm_concat=1, size=100, window=2, hs=0, min_count=2, workers=cores)
    # PV-DBOW
    Doc2Vec(sentences,dm=0, size=100, hs=0, min_count=2, workers=cores)
    # PV-DM w/average
    Doc2Vec(sentences,dm=1, dm_mean=1, size=100, window=2, hs=0, min_count=2, workers=cores)
    """
    model = Doc2Vec(Document(docs), dm=0, size=size, hs=0, min_count=3, workers=4)
    # model = Doc2Vec(Document(), dm=1, dm_concat=1, size=100, window=5, hs=0, min_count=3, workers=4)
    # model = Doc2Vec(Document(), dm=1, dm_mean=1, size=100, window=5, hs=0, min_count=3, workers=4)

    model.save(os.path.join(ModelPath, savename))

    lg.info("successed save {0} {1}".format(savename, '.'*6))

    numid = len(idlist)
    doc2vecSim = dict()

    for i in range(numid-1):
        doc2vecSim.setdefault(i, dict())
        for j in range(i+1, numid):
            doc2vecSim.setdefault(j, dict())
            try:
                sim = model.docvecs.similarity(i, j)
            except Exception:
                continue

            doc2vecSim[i].setdefault(j, 0)
            doc2vecSim[i][j] = sim

            doc2vecSim[j].setdefault(i, 0)
            doc2vecSim[j][i] = sim
    write_json(name=simname, data=doc2vecSim)

