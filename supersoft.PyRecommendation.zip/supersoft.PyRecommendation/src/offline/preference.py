# coding=utf-8
import math
import random
from collections import defaultdict, Counter

from src.data_helping.data_algo import getrange
from src.data_helping.log_helpping import ViewLog
from src.data_helping.read_write import write_json
from src.setting.log import setlog
from src.setting.settings import ModelPath

"""
脚本功能： 计算用户偏好，将用户偏好保存成文件
    
执行级别： 2 

保存文件：
    train_file.json
    test_file.json
    
保存路径：
    默认：model文件夹下
    
"""

# tagToViewName = 'tagToView.json'
# viewToTagName = 'viewToTag.json'
#
# tagToView = read_json(name=tagToViewName, path=ModelPath)
# viewToTag = read_json(name=viewToTagName, path=ModelPath)

lg = setlog()

def getsum(dict):
    valuesum = 0
    for value in dict.values():
        valuesum += value
    return valuesum


def get_user_prefer(testret=0.3, train_file='train_file.json', test_file='test_file.json'):

    train = defaultdict(dict)
    test = defaultdict(dict)

    vl = ViewLog()
    userId = vl.get_userId()

    usernum = len(userId)
    lg.info(" %d users in training" % usernum)

    for userid in userId:

        lg.info(userid)
        # print(usernum, userid)
        # usernum -= 1

        viewId, vviewId = vl.get_viewId(userid)

        viewStart = vl.get_startTime(userid)

        listvid = sorted(viewStart.items(), key=lambda x: x[1], reverse=True)

        cnt = Counter(vviewId)

        for viewid in viewId:

            vcount = getrange(cnt[viewid], [1, 3, 5, 10, 30, 60], [1.0, 1.03, 1.06, 1.09, 1.12, 1.15, 1.18])

            viewstart = viewStart[viewid]
            starttimepos = listvid.index((viewid, viewstart))

            poscount = getrange(starttimepos, [5, 15, 50, 100], [0.82, 0.80, 0.78, 0.75, 0.7])

            score = 0.7 * vcount + 0.3 * poscount
            train[userid][viewid] = score

    write_json(name=train_file, data=train, path=ModelPath)

    numuser = len(userId)
    numtest = int(numuser * testret)
    testuser = random.sample(userId, numtest)

    # 分割训练集
    for user in testuser:
        test[user] = train[user]

    write_json(name=test_file, data=test, path=ModelPath)

    return train, test


# def get_user_tagprefer():
#     vl = ViewLog()
#     userId = vl.get_userId()
#     usernum = len(userId)
#     print("训练数据中包含 %d 用户" % usernum)
#
#     for userid in userId:
#         viewId, vviewId = vl.get_viewId(userid)
#         Tag = list()
#         for vid in vviewId:
#             tag = viewToTag[vid]
#             Tag.append(tag)
#         count = Counter(Tag)


def item_sim(train, simname):
    train = train
    itemSim = dict()
    item_user_count = dict()
    count = dict()
    for user, item in train.items():
        for i in item.keys():
            item_user_count.setdefault(i, 0)
            item_user_count[i] += 1
            for j in item.keys():
                if i == j:
                    continue
                count.setdefault(i, {})
                count[i].setdefault(j, 0)
                count[i][j] += 1
    for i, related_items in count.items():
        itemSim.setdefault(i, dict())
        for j, cuv in related_items.items():
            itemSim[i].setdefault(j, 0)

            itemSim[i][j] = cuv / math.sqrt(item_user_count[i] * item_user_count[j] * 1.0)

    write_json(name=simname, data=itemSim)


if __name__ == '__main__':

    trainname = 'train_file.json'
    testname = 'test_file.json'
    train, _ = get_user_prefer(train_file=trainname, test_file=testname)

    simname = 'itemsim.json'
    item_sim(train, simname=simname)

