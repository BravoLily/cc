# coding=utf-8
import datetime
from collections import Counter

from src.data_helping.data_algo import getrange
from src.data_helping.log_helpping import ViewLog
from src.sourcedata.search import Search


def coldboot():
    vl = ViewLog()
    _, vvid = vl.get_viewId()

    cnt = Counter(vvid)
    # print(cnt)
    # cnt1 = sorted(cnt.items(), key=lambda x: x[1], reverse=True)
    se = Search()
    data = se.search(keyword='1', proj='idx')

    date = dict()
    for i in data:
        date[str(i['viewid'])] = i['createdate']
    date1 = dict(sorted(date.items(), key=lambda x: x[1], reverse=True))

    rank = dict()

    for vid, t in date1.items():
        subt = datetime.datetime.today() - t
        scoredate = 1 - subt.days // 5 * 0.01
        # print(scoredate)
        scorecnt = getrange(cnt[vid], [10, 50, 150], [1.1, 1.15, 1.2, 1.25])
        score = 0.68 * scorecnt + 0.15 * scoredate
        rank[vid] = score

    rank = dict(sorted(rank.items(), key=lambda x: x[1], reverse=True))

    return rank
