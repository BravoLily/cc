# coding=utf-8
import os
import re

import jieba

import warnings

from src.data_helping.lda_algo import get_listdoc, cacul_sim
from src.data_helping.read_write import write_json
from src.setting.log import setlog
from src.setting.settings import ModelPath

warnings.filterwarnings(action='ignore', category=UserWarning, module='gensim')

from gensim import models
from gensim.corpora import Dictionary
from gensim.models import LdaModel
from pyspark import SparkConf




jieba.load_userdict(os.path.join(ModelPath, 'word.txt'))

"""
脚本功能： 1. 对观点数据进行聚类
          2. 计算文章间的相似度并保存文件 
          3. 将文章id和类别标签进行保存
          
执行级别： 2 （需要先执行search_engine将数据索引化）

提交命令：
spark-submit --py-files 
F:\supersoft.recommendation\supersoft.recommendation.zip 
F:\supersoft.recommendation\lda_cluster.py 

保存文件：
    tagToView.json
    viewToTag.json
    lda.model（及相关文件）
    lda.dict
    
保存路径：
    默认：model文件夹下
    
"""
lg = setlog()
spark_name = os.environ.get('SPARK_HOME', None)
if not spark_name:
    raise ValueError('spark环境错误')

conf = SparkConf()
conf.set("spark.app.name", "recommdation")
conf.set("spark.driver.maxResultSize", "0")
conf.set("spark.driver.memory", "2g")
conf.set("spark.executor.memory", "2g")


def cleaning(data):
    """
    文本忽略标点及英文字符，仅提取中文字符
    """
    words = re.findall(r"[\u4e00-\u9fa5]+", data)
    return ' '.join(words)


def readstop():
    """
    加载停用词
    """
    stopfile = os.path.join(ModelPath, 'stopwords.txt')
    stopwords = [line.strip() for line in open(stopfile, 'r', encoding='utf-8').readlines()]
    return stopwords


def get_dict(docs, dictfile):
    """
    lda字典
    :param docs: search检索文章数据
    :param dictfile:
    :return:
    """
    train = []
    stopwords = readstop()
    viewID = []

    for line in docs:
        try:
            viewid = line['viewid']
            viewID.append(viewid)
            line1 = cleaning(line['content'])
            sline = list(jieba.cut(line1, HMM=True))
            train.append([w for w in sline if w not in stopwords])
        except KeyError:
            continue

    dictionary = Dictionary(train)
    dictionary.filter_extremes(no_below=5, no_above=0.5)
    dictionary.save(dictfile)

    lg.info("success save corpus dict to %s ......" % dictfile)

    return dictionary, train, viewID


def cacul_tag(doc_lda):
    """
    获取文档主题tag
    :param doc_lda:
    :return:
    """
    loc_list = [i[1] for i in doc_lda]
    maxidx = loc_list.index(max(loc_list))
    tag = doc_lda[maxidx][0]
    return str(tag)


def lda_cluster(n, dictionary, train, modelfile):

    corpus = [dictionary.doc2bow(text) for text in train]  # 每个文本对应的稀疏向量
    tfidf = models.TfidfModel(corpus)

    corpus_tfidf = tfidf[corpus]

    lda = LdaModel(corpus=corpus_tfidf, id2word=dictionary, num_topics=n, iterations=200)

    doc_topic = [a for a in lda[corpus_tfidf]]

    lda.save(modelfile)

    lg.info("successed save {0} {1}".format(modelfile, '.'*6))

    return doc_topic


def get_sim(n, viewID, doc_topic, simname):
    """
    获取并保存相似度
    :param viewID:
    :param doc_topic:
    :return:
    """
    numdoc = len(doc_topic)

    ldaSim = dict()

    for i in range(numdoc-1):

        vid1 = viewID[i]
        dt1 = doc_topic[i]
        list_doc1 = get_listdoc(n, dt1)

        ldaSim.setdefault(vid1, dict())

        for j in range(i+1, numdoc):
            vid2 = viewID[j]
            dt2 = doc_topic[j]
            list_doc2 = get_listdoc(n, dt2)

            ldaSim.setdefault(vid2, dict())

            try:
                sim = cacul_sim(list_doc1, list_doc2)
            except Exception:
                continue

            ldaSim[vid1].setdefault(vid2, 0.0)
            ldaSim[vid1][vid2] = sim

            ldaSim[vid2].setdefault(vid1, 0.0)
            ldaSim[vid2][vid1] = sim

    write_json(name=simname, data=ldaSim)


def get_tag(viewID, doc_topic, tagToViewfileName, viewToTagName):

    # 标签数据
    viewToTag = {}

    for idx, dt in enumerate(doc_topic):
        tag = cacul_tag(dt)
        vid = viewID[idx]
        viewToTag[str(vid)] = tag

    write_json(name=viewToTagName, data=viewToTag)

    tagToView = dict()

    for idx, dt in enumerate(doc_topic):
        tag = cacul_tag(dt)
        tagToView.setdefault(tag, [])
        vid = viewID[idx]
        tagToView[tag].append(str(vid))

    write_json(name=tagToViewfileName, data=tagToView)

