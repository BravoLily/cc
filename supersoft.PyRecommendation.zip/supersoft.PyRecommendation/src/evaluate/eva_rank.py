# coding=utf-8
import queue
import sys
import threading
import time

import matplotlib.pyplot as plt

from src.data_helping.rank import Recommend
from src.data_helping.read_write import read_json
from src.setting.log import setlog

lg = setlog()
q1 = queue.Queue()
q2 = queue.Queue()
q3 = queue.Queue()
q1x = queue.Queue()

try:
    train1 = read_json(name='train_file1.json')
    # train1 = {key: value for key, value in train1.items() if key in usertrain}
    test1 = read_json(name='test_file1.json')
    # test1 = {key: value for key, value in test1.items() if key in usertest}

    train2 = read_json(name='train_file2.json')
    # train2 = {key: value for key, value in train2.items() if key in usertrain}
    test2 = read_json(name='test_file2.json')
    # test2 = {key: value for key, value in test2.items() if key in usertest}

    train3 = read_json(name='train_file3.json')
    # train3 = {key: value for key, value in train3.items() if key in usertrain}
    test3 = read_json(name='test_file3.json')
    # test3 = {key: value for key, value in test3.items() if key in usertest}

    itemsim1 = read_json(name='itemsim1.json')
    itemsim2 = read_json(name='itemsim2.json')
    itemsim3 = read_json(name='itemsim3.json')
    ldasim = read_json(name='ldasim.json')

    ibc1 = Recommend(train1, [itemsim1], test1)
    ibc2 = Recommend(train2, [itemsim2], test2)
    ibc3 = Recommend(train3, [itemsim3], test3)
    ibc1x = Recommend(train1, [itemsim1, ldasim], test1)

except IOError as e:
    lg.error(e)
    sys.exit(1)


def loop(k, ibc, que):
    """
    :return:
    """
    lg.info('thread %s is running...' % threading.current_thread().name)
    recall, precision = ibc.recallAndPrecision(k=k, nitem=200)
    lg.info('end %s recall&precision ' % threading.current_thread().name)
    # coverage = ibc.coverage(k=k)
    # print('end %s coverage ' % threading.current_thread().name)
    popularity = ibc.popularity(k=k)
    lg.info('end %s popularity ' % threading.current_thread().name)
    que.put((k, recall, precision, popularity))
    # que.put((k, recall, precision))

    lg.info('thread %s ended.' % threading.current_thread().name)


def take_first(elem):
    return elem[0]


if __name__ == '__main__':

    tstart = time.time()
    print('thread %s is running...' % threading.current_thread().name)

    listibc = [ibc1, ibc2, ibc3, ibc1x]
    listque = [q1, q2, q3, q1x]

    threads = []
    for i in [20, 25, 30, 35, 40]:
        for ibc, que in zip(listibc, listque):
            t = threading.Thread(target=loop, args=(i, ibc, que), name='LoopThread' + str(i) + str(ibc))
            threads.append(t)

    for t in threads:
        t.start()
    for t in threads:
        t.join()

    print('thread %s ended.' % threading.current_thread().name)

    tend = time.time()

    print("time: ", (tend - tstart))

    n = len(listibc)
    results = []
    for i in range(0, n):
        results.append([])

    for i, que in enumerate(listque):
        while not que.empty():
            results[i].append(que.get())
    for i in range(0, n):
        results[i].sort(key=take_first)

    print(results[0])

    xyq = []
    for res in results:
        xy = [[], [], [], [], []]
        print("%3s%20s%20s%20s%20s" % ('K', "recall", 'precision', 'coverage', 'popularity'))
        for item in res:
            xy[0].append(item[0])
            xy[1].append(item[1])
            xy[2].append(item[2])
            # xy[3].append(item[3])
            # xy[4].append(item[4])
            # print("%3d%19.3f%%%19.3f%%%20.3f" % (item[0], item[1] * 100, item[2] * 100, item[3]))
            print("%3d%19.3f%%%19.3f" % (item[0], item[1] * 100, item[2] * 100))
        xyq.append(xy)

    plt.rcParams['font.sans-serif'] = ['SimHei']
    plt.rcParams['axes.unicode_minus'] = False

    plt.figure()
    plt.xlabel('K')
    plt.ylabel('recall')
    plt.plot(xyq[0][0], xyq[0][1], 'g', label='itemrecall')
    plt.plot(xyq[1][0], xyq[1][1], 'r', label='ldarecall')
    plt.plot(xyq[2][0], xyq[2][1], 'c', label='word2vecrecall')
    plt.plot(xyq[3][0], xyq[3][1], 'b', label='q12recall')
    # plt.plot(xyq[4][0], xyq[4][1], 'm', label='q123recall')
    # plt.plot(xyq[5][0], xyq[5][1], 'y', label='q13recall')
    plt.legend(loc='lower right')
    plt.show()

    plt.figure()
    plt.xlabel('K')
    plt.ylabel('precision')
    plt.plot(xyq[0][0], xyq[0][2], 'g', label='itemprecision')
    plt.plot(xyq[1][0], xyq[1][2], 'r', label='ldaprecision')
    plt.plot(xyq[2][0], xyq[2][2], 'c', label='word2vecprecision')
    plt.plot(xyq[3][0], xyq[3][2], 'b', label='q12precision')
    # plt.plot(xyq[4][0], xyq[4][2], 'm', label='q123precision')
    # plt.plot(xyq[5][0], xyq[5][2], 'y', label='q13precision')
    plt.legend(loc='lower right')
    plt.show()

    plt.figure()
    plt.xlabel('K')
    plt.ylabel('popularity')
    plt.plot(xyq[0][0], xyq[0][3], 'g', label='itempopularity')
    plt.plot(xyq[1][0], xyq[1][3], 'r', label='ldapopularity')
    plt.plot(xyq[2][0], xyq[2][3], 'c', label='word2vecpopularity')
    plt.plot(xyq[3][0], xyq[3][3], 'b', label='q12popularity')
    # plt.plot(xyq[4][0], xyq[4][4], 'm', label='q123popularity')
    # plt.plot(xyq[5][0], xyq[5][4], 'y', label='q13popularity')
    plt.legend(loc='lower right')
    plt.show()

