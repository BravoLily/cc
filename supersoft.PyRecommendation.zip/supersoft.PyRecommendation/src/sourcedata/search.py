# coding=utf-8
from whoosh.index import open_dir
from whoosh.qparser import QueryParser

from src.setting.settings import ModelPath


class Search:
    def __init__(self, indexpath=ModelPath+"/indexpath", indexname='indexname'):
        """

        :param indexpath: 索引路径
        :param indexname: 文件名字

        """
        self.indexpath = indexpath
        self.indexname = indexname

    def search(self, keyword, proj='viewid'):
        """

        :param keyword: 检索关键字
        :param proj:  [viewid, title, content,createdate, idx];idx='1'，全量检索
        :return:
        """
        index = open_dir(self.indexpath, indexname=self.indexname)

        with index.searcher() as searcher:
            parser = QueryParser(proj, index.schema)
            myquery = parser.parse(keyword)
            results = searcher.search(myquery, limit=None)

            try:
                for res in results:
                    yield dict(res)
            except TypeError:
                return None


# UNITTEST
if __name__ == '__main__':
    s = Search()
    m = s.search('1359', proj='viewid')
    for i in m:
        print(i)

    alldata = s.search('1', proj='idx')
    for i in alldata:
        # print(i)
        print(i['viewid'])

    """
    print(i) 报下面这个错误是因为print()函数本身的问题，不能完全打印所有的unicode字符,获取数据上并无影响
    UnicodeEncodeError: 'gbk' codec can't encode character '\u261e' in position 22: illegal multibyte sequence
    """
