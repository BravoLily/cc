# coding=utf-8
import pymssql
import sys

print("sqlserver parameter: ", sys.argv[2])

try:
    sql = sys.argv[2].split(':')
    sql_host = sql[0]
    sql_username = sql[1]
    sql_password = sql[2]
    sqlserver_settings = {'sql_host': sql_host, 'sql_username': sql_username, 'sql_password': sql_password}

    sql_dbname = sql[3]
except IndexError:
    print("PARAMETER 2 ERROR")
    sys.exit(1)


class ConnectMySQL:
    def __init__(self,
                 host=sqlserver_settings['sql_host'],
                 user=sqlserver_settings['sql_username'],
                 password=sqlserver_settings['sql_password']):
        self.host = host
        self.user = user
        self.password = password
        self.db = sql_dbname

    def __GetConnect(self):
        if not self.db:
            raise(NameError, "没有设置数据库信息")
        self.conn = pymssql.connect(
            host=self.host,
            user=self.user,
            password=self.password,
            database=self.db)
        cur = self.conn.cursor()
        if not cur:
            raise(NameError, "连接数据库失败")
        else:
            return cur

    def ExecQuery(self, sql):
        cur = self.__GetConnect()
        cur.execute(sql)
        reslist = cur.fetchall()

        self.conn.close()
        return reslist

    def ExecNonQuery(self, sql):
        cur = self.__GetConnect()
        cur.execute(sql)
        self.conn.commit()
        self.conn.close()


# UNITTEST
if __name__ == '__main__':

    sql = "SELECT [ViewId],[Title],[Remark],[CreateDate] FROM [cazuresnsdb].[dbo].[T_View]"
    ms = ConnectMySQL()
    res = ms.ExecQuery(sql)

    for row in res:
        print(row[0])
        # print(row)

    """
    print(row) 报下面这个错误是因为print()函数本身的问题，不能完全打印所有的unicode字符,获取数据上并无影响
    UnicodeEncodeError: 'gbk' codec can't encode character '\u261e' in position 22: illegal multibyte sequence
    """
