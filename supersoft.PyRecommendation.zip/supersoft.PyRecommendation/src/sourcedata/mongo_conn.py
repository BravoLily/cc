# coding=utf-8
import re
import sys

import pymongo

url_log = sys.argv[3]
colname_log = sys.argv[4]
url_cold = sys.argv[5]
colname_cold = sys.argv[6]
url_rank = sys.argv[7]
colname_rank = sys.argv[8]

print("url_log parameter: ", url_log)
print("url_cold parameter: ", url_cold)
print("url_rank parameter: ", url_rank)


def conn_url(urlname):
    if urlname == "url_log":
        url = url_log
        colname = colname_log
    elif urlname == "url_cold":
        url = url_cold
        colname = colname_cold
    elif urlname == "url_rank":
        url = url_rank
        colname = colname_rank
    else:
        print("urlname wrong")
        sys.exit(1)

    #  mongodb://ycfadmin:123@192.168.1.225:27017/log.WebLogger_58ycf.com
    url = url + '?authMechanism=SCRAM-SHA-1&authSource=admin'
    client = pymongo.MongoClient(url)

    s = url.split("/")
    s1 = s[-1].split(".")
    dbname = s1[0]

    # colname = re.findall(".*\/(.*)\?.*", url)
    # colname = colname[0].strip(dbname+'.')
    db = client[dbname]
    col = db[colname]

    return col
