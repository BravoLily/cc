#coding:utf-8
import logging


def setlog():

    logger = logging.getLogger('recommendation')
    logger.setLevel(logging.INFO)

    if not logger.handlers:
        # 输出到屏幕
        ch = logging.StreamHandler()
        ch.setLevel(logging.INFO)

        # # 输出到文件
        # fh = logging.FileHandler("recommendation.log", mode='a')
        # fh.setLevel(logging.INFO)

        # 设置日志格式
        fomatter = logging.Formatter('%(asctime)s -%(name)s-%(levelname)s-%(module)s:%(message)s')

        ch.setFormatter(fomatter)
        # fh.setFormatter(fomatter)

        logger.addHandler(ch)
        # logger.addHandler(fh)

    return logger
