#-*- coding:utf-8 -*-

from setuptools import setup, find_packages

setup(
    name="recommendation",
    version="0.1.0",
    packages=find_packages("supersoft.PyRecommendation", exclude=["*.scala", "*.scala.*", "*.java", "*.java.*"]),
    package_dir={"": "supersoft.PyRecommendation"},
    package_data={
            "": ["*.txt", "*.csv"],
        },
    zip_safe=False,

    description="egg recommendation demo.",
    # long_description="egg recommendation demo, haha.",

    license="GPL",
    keywords=("recommendation", "egg"),
    platforms="Independant",
    url="",
)
