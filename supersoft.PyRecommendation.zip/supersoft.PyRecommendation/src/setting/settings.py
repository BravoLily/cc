# coding=utf-8
import os
import string
import sys

from pyspark import SparkContext

PUNC = " ！？。＂＃＄％＆＇（）＊＋，－／：；＜＝＞＠［＼］＾＿｀｛｜｝～?????、〃《》「」『』【】〔〕〖〗?????〝〞????–—‘’?“”??…?﹏."
PUN = string.punctuation + PUNC

# ModelPath = os.path.abspath(sys.path[0] + os.path.sep + "../model")
# curPath = os.path.abspath(os.path.dirname(__file__))
# rootPath = os.path.split(curPath)[0]
# ModelPath = os.path.join(rootPath, 'model')
ModelPath = sys.argv[9]

filename = {
    'indexpath': "indexpath",
    'indexname': "indexname",
    'tagToViewfile': "tagToView.json",
    'viewToTagfile': "viewToTag.json",
    'ldasimname': 'ldasim.json',
    'ldamodel': 'lda.model',
    'ldadict': 'lda.dict',
    'doc2vecmodelname': 'doc2vec.model',
    'doc2vecsimname': 'doc2vecSim.json',
    'trainname': 'train_file.json',
    'testname': 'test_file.json',
    'preferencesimname': 'itemsim.json'}
