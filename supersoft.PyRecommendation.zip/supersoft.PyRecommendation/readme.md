## 安装依赖：
	pip install jieba
	pip install pymongo
	pip install pymssql
	pip install whoosh
	pip install gensim
	pip install py4j
	安装超时报错： pip --default-timeout=100 install XXX
	    
## 打包命令
    cd $path (代码所在主路径)
    python3 supersoft.PyRecommendation/src/setting/setup.py bdist_egg

## 提交命令：
    
    spark-submit --py-files eggfile bootfile arvg1 arvg2 arvg3 arvg4 arvg5 arvg6 arvg7 arvg8 arvg9
 
    arvg1: kafka配置
        host:kafka-port:topic
        eg: 192.168.1.225:9092:Statistic
         
    arvg2: sqlserver配置
        sqlserver_host:username:password:dbname
        DESKTOP-PSPOMTB\SQL2014:sa:123:cazuresnsdb
        
    arvg3: mongodb
        mongodb连接 训练数据  WebLogger 
        mongodb://ycfadmin:123@192.168.1.225:27017/log.WebLogger_58ycf.com.bak
    
    argv4：weblogger表名
        WebLogger_58ycf.com.bak
        
    arvg5: mongodb
        mongodb连接 冷启动表 cold_recommendation 
        mongodb://ycfadmin:123@192.168.1.225:27017/statictis.cold_recommendation
    
    argv6：冷启动表 表名
        cold_recommendation
        
    arvg7: mongodb
        mongodb连接 推荐表 view_recommendation 
        mongodb://ycfadmin:123@192.168.1.225:27017/statictis.view_recommendation
        
    argv8：推荐表 表名
        view_recommendation
        
    arvg9: modelpath
        训练模型存储位置
        $path/supersoft.PyRecommendation/data/model
        
    
    eg: 
    spark-submit --py-files /home/lili/recommendation/dist/recommendation-0.1.0-py3.6.egg \
    /home/lili/recommendation/supersoft.PyRecommendation/src/service/boot.py \
    192.168.1.235:9092:Statistic \
    192.168.1.225:sa:123:cazuresnsdb \
    mongodb://ycfadmin:123@192.168.1.225:27017/log.WebLogger_58ycf.com.bak \
    WebLogger_58ycf.com.bak \
    mongodb://ycfadmin:123@192.168.1.225:27017/statictis.cold_recommendation \
    cold_recommendation \
    mongodb://ycfadmin:123@192.168.1.225:27017/statictis.view_recommendation \
    view_recommendation \
    /home/lili/recommendation/supersoft.PyRecommendation/data/model

## 离线训练提交命令

    同上,将boot.py改成offline_boot.py
    spark-submit --py-files eggfile offline_bootfile arvg1 arvg2 arvg3 arvg4 arvg5 arvg6 arvg7 arvg8 arvg9
    
执行boot.py,若模型不存在，则训练模型。若模型存在，则直接读取模型
执行offline_boot.py,将重新训练并保存模型。
    
## 存在问题
    jar包不兼容，只能在 0.8版本（spark-streaming-kafka-0-8-assembly_2.11-2.2.1.jar）kafka 下运行，在其他版本下无法获取数据