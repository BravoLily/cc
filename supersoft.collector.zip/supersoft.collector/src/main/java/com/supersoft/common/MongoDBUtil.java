package com.supersoft.common;

import com.mongodb.MongoClient;
import com.mongodb.MongoClientOptions;
import com.mongodb.MongoClientURI;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;
import com.mongodb.client.MongoCollection;

import java.util.Date;

import org.bson.Document;
import org.bson.conversions.Bson;

public class MongoDBUtil {
	public static void Remove(String uri, Date date) {
		MongoClientURI URI = new MongoClientURI(uri, MongoClientOptions.builder().cursorFinalizerEnabled(false));
		MongoClient mongoClient = new MongoClient(URI);
		MongoDatabase database = mongoClient.getDatabase(URI.getDatabase());
		MongoCollection<Document> collection = database.getCollection(URI.getCollection());
		Bson filter = Filters.lt("StartTime", date);
		collection.deleteMany(filter);
		mongoClient.close();
	}
}
