package com.supersoft.collector.qt

import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.Dataset

import java.sql.Timestamp

import com.supersoft.common._

object Merchant {

  case class Info(
    id:         String,
    users:      String,
    cust_id:    String,
    store_name: String,
    //    store_shortname:             String,
    mer_type:       String,
    biz_type:       String,
    mer_law_person: String,
    //    pay_channel:          String,
    //    tech_contact:         String,
    //    tech_tel_no:          String,
    //    tech_email:           String,
    biz_contact:       String,
    biz_tel_no:        String,
    biz_email:         String,
    serv_contact:      String,
    serv_tel_no:       String,
    serv_email:        String,
    mer_addr:          String,
    biz_range:         String,
    mer_opn_bank_code: String,
    //    bank_stl_ac_no:       String,
    //    rf_comm_flg:    String,
    //    rf_rec_fee_flg: String,
    city: String,
    //    post_code:            String,
    //    law_person_type:      String,
    //    law_person_cret_type: String,
    //    law_person_cret_no:   String,
    //    long_term_sign:       String,
    //    cert_begin_date:      Timestamp,
    //    cert_end_date:        Timestamp,
    web_address: String,
    //    web_address_abbr:     String,
    contract_str_date: Timestamp,
    contract_end_date: Timestamp,
    contractor:        String,
    //    contract_biz_no:      String,
    //    contract_biz_name:    String,
    //    tech_mob_no:          String,
    biz_mob_no:  String,
    serv_mob_no: String,
    //        margin:               String,
    //    froz_stl_sign:        String,
    //    cret_masterity_days:  String,
    //    tax_registration_no:  String,
    //    organization_no:      String,
    //    cps_sign:             String,
    //    reg_capital:          String,
    compay_email:  String,
    compay_tel_no: String,
    compay_fax:    String,
    //    cycle_days:           String,
    //    code_type_id:         String,
    //    cert:                        String,
    //    company_brief:               String,
    risk_level:     String,
    bussiness_type: String,
    mer_status:     String,
    create_time:    Timestamp,
    create_user:    String,
    //    business_licence_pic:        String,
    //    tax_registration_pic:        String,
    //    organization_pic:            String,
    //    opening_licenses_pic:        String,
    //    cert_pic_front:              String,
    //    cert_pic_back:               String,
    //    contract_pic:                String,
    icp_no: String,
    //    settle_fee_code:   String,
    //    withdraw_fee_code: String,
    //    urgent_fee_code:   String,
    province:     String,
    check_user:   String,
    check_time:   Timestamp,
    check_status: String,
    //    check_info:                  String,
    //    risk_desc:                   String,
    region: String,
    //    attention_line:              String,
    //    attention_line_tel:          String,
    //    attention_line_email:        String,
    //    business_licence_no:         String,
    //    business_licence_begin_date: Timestamp,
    //    business_licence_end_date:   Timestamp,
    icp_cert_no: String,
    //    merchant_logo_pic:           String,
    //    bank_stl_ac_no_type:      String,
    //    issuer:                   String,
    //    settlement_way:           String,
    interface_ip:      String,
    pay_way_supported: String,
    parent_id:         String,
    //    agent_goal_discount_rate: String,
    //    charge_way:               String,
    //    pre_storage_fee:          String,
    register_from:       String,
    user_interflow_flag: String)

  def load(spark: SparkSession, url: String, user: String, pwd: String): Dataset[Info] = {
    val table = "(SELECT ID,CAST(NVL(b.USERS,'0') as varchar2(16)) USERS,CUST_ID,STORE_NAME,MER_TYPE,BIZ_TYPE,MER_LAW_PERSON,BIZ_CONTACT,BIZ_TEL_NO,BIZ_EMAIL,SERV_CONTACT,SERV_TEL_NO,SERV_EMAIL,MER_ADDR,BIZ_RANGE,MER_OPN_BANK_CODE,CITY,WEB_ADDRESS,CONTRACT_STR_DATE,CONTRACT_END_DATE,CONTRACTOR,BIZ_MOB_NO,SERV_MOB_NO,COMPAY_EMAIL,COMPAY_TEL_NO,COMPAY_FAX,RISK_LEVEL,BUSSINESS_TYPE,MER_STATUS,CREATE_TIME,CREATE_USER,ICP_NO,PROVINCE,CHECK_USER,CHECK_TIME,CHECK_STATUS,REGION,ICP_CERT_NO,INTERFACE_IP,PAY_WAY_SUPPORTED,PARENT_ID,REGISTER_FROM,USER_INTERFLOW_FLAG FROM SHARE_PAY_MERCHANT left join (SELECT MERCHANT_ID,COUNT(MERCHANT_ID) USERS FROM SHARE_PAY_TRAN_USER GROUP BY MERCHANT_ID) b on b.MERCHANT_ID=CUST_ID) a"
    val df = jdbcOpts.load(spark, url, user, pwd, table)
    //    val table = "(SELECT ID,CUST_ID,STORE_NAME,MER_TYPE,BIZ_TYPE,MER_LAW_PERSON,BIZ_CONTACT,BIZ_TEL_NO,BIZ_EMAIL,SERV_CONTACT,SERV_TEL_NO,SERV_EMAIL,MER_ADDR,BIZ_RANGE,MER_OPN_BANK_CODE,CITY,WEB_ADDRESS,CONTRACT_STR_DATE,CONTRACT_END_DATE,CONTRACTOR,BIZ_MOB_NO,SERV_MOB_NO,COMPAY_EMAIL,COMPAY_TEL_NO,COMPAY_FAX,RISK_LEVEL,BUSSINESS_TYPE,MER_STATUS,CREATE_TIME,CREATE_USER,ICP_NO,PROVINCE,CHECK_USER,CHECK_TIME,CHECK_STATUS,REGION,ICP_CERT_NO,INTERFACE_IP,PAY_WAY_SUPPORTED,PARENT_ID,REGISTER_FROM,USER_INTERFLOW_FLAG,ROW_NUMBER() OVER (ORDER BY ID) RNO FROM SHARE_PAY_MERCHANT) a"
    //    val df = jdbcUtils.load(spark, url, user, pwd, table, "RNO", numPartitions = 10)

    import spark.implicits._
    val ds = df. /*drop("RNO").*/ as[Info]
        ds.show()
    println(df.count)
    println(df.rdd.partitions.size)
    ds
  }

  def save(spark: SparkSession, url: String, user: String, pwd: String) {
    val ds = load(spark, url, user, pwd)

    import com.mongodb.spark._
    MongoSpark.save(ds.write.option("collection", "merchant").mode("overwrite"))
  }
}