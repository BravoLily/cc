package com.supersoft.collector.qt.service

import org.apache.log4j.{ Level, Logger }
import org.apache.spark.sql.SparkSession
import scopt.OptionParser

import java.util.concurrent.{ Executors, TimeUnit }

import com.supersoft.common._
import com.supersoft.collector.qt.{ Merchant, User, Order }

object Boot {
  case class Params(
    dburl:  String = null,
    user:   String = null,
    pwd:    String = null,
    output: String = null)

  def main(args: Array[String]): Unit = {
    val defaultParams = Params()

    val parser = new OptionParser[Params]("LogCollector") {
      head("QianTongDataCollector: collecting transaction data save to mongodb.")
      opt[String]("user")
        .text(s"oracle user, default: ${defaultParams.user}")
        .action((x, c) => c.copy(user = x))
      opt[String]("pwd")
        .text(s"oracle password, default: ${defaultParams.pwd}")
        .action((x, c) => c.copy(pwd = x))
      arg[String]("<dburl>")
        .required()
        .text("dburl")
        .action((x, c) => c.copy(dburl = x))
      arg[String]("<output>")
        .required()
        .text("output")
        .action((x, c) => c.copy(output = x))
      note(
        """
          |For example, the following command runs this app on a synthetic dataset:
          |
          | bin/spark-submit --class com.supersoft.collector.qt.service.Boot \
          |  /data/supersoft.collector.jar \
          |  --user xxx \
          |  --pwd xxx \
          |  182.92.76.110:1521:orcl \
          |  mongodb://hadoopUser:123@192.168.1.225:27017/qt
        """.stripMargin)
    }

    parser.parse(args, defaultParams) match {
      case Some(params) => run(params)
      case _            => sys.exit(1)
    }
  }

  def run(params: Params): Unit = {
//    val runnable = new Runnable {
//      override def run(): Unit = {

//        if (TimeOpts.hours != 3) {
//          println(TimeOpts.hours)
//          return
//        }

        val spark = SparkSession
          .builder()
          //          .master("local[*]")
          .appName("QianTong")
          .config("spark.mongodb.output.uri", params.output)
          //      .config("spark.some.config.option", "some-value")
          .getOrCreate()

        Logger.getRootLogger.setLevel(Level.WARN)

        var beg = System.currentTimeMillis()
        System.out.println("开始收集商戶数据……")
        Merchant.save(spark, params.dburl, params.user, params.pwd);
        System.out.println("商戶数据收集完毕 " + (System.currentTimeMillis() - beg))

        System.out.println("开始收集用戶数据……")
        User.save(spark, params.dburl, params.user, params.pwd);
        System.out.println("用戶数据收集完毕 " + (System.currentTimeMillis() - beg))

        System.out.println("开始收集交易数据……")
        Order.save(spark, params.dburl, params.user, params.pwd, params.output + ".order");
        System.out.println("交易数据收集完毕 " + (System.currentTimeMillis() - beg))
        
        spark.close()
//      }
//    }
//
//    val service = Executors.newSingleThreadScheduledExecutor()
//    service.scheduleAtFixedRate(runnable, 0, 1, TimeUnit.HOURS)
  }
}