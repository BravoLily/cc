package com.supersoft.collector.log

import org.apache.spark.sql.{ SQLContext, SaveMode }
import org.apache.spark.SparkContext
import org.apache.spark.streaming.StreamingContext
import org.apache.spark.streaming.Duration
import org.apache.spark.rdd.RDD
import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.io.{ LongWritable, Text, IntWritable }
import org.apache.hadoop.mapred.TextOutputFormat
import org.bson.{ BasicBSONObject, BsonObjectId }

import com.supersoft.common._
import com.supersoft.collector

object LogOnlineProcessor {
  def save(
    sc:           SparkContext,
    ssc:          StreamingContext,
    brokers:      String,
    topic:        String,
    groupid:      String,
    path:         String,
    weboutputuri: String,
    appoutputuri: String): Unit = {
    //    outputuri match {
    //      case null => sc.getConf.get("mongo.output.uri")
    //    }

    val sqlContext = new SQLContext(sc)
    val stream = KafakaOpts.directStream(ssc, brokers, topic, groupid)
    stream.foreachRDD { rdd =>
      val kvRDD = rdd.map(x => (x.key, x.value))
      kvRDD.foreach(println)
      /**
       * web日志
       */
//      val ycfWebPath = s"${path}${collector.ycf_web_pt}" + TimeOpts.calDate()
//      val cmWebPath = s"${path}${collector.cm_web_pt}" + TimeOpts.calDate()
//      val xjbWebPath = s"${path}${collector.xjb_web_pt}" + TimeOpts.calDate()

      // 网站访问日志
      val webRdd = kvRDD.filter(x => x._1 == "web" || x._1 == "").map(x => (x._1, x._2.split("::")))
      import sqlContext.implicits._
      // 云财富网站访问日志
      val ycfWebRdd = webRdd.filter(x => x._2(1).contains(collector.ycfDomain))
//      if (!ycfWebRdd.isEmpty)
//        ycfWebRdd.map(x => x._2.mkString("::")).toDF().write.mode(SaveMode.Append).text(ycfWebPath)

      // TODO:mongo异步或移除
      val ycfWebRDD = getWebRDD(ycfWebRdd)
      // 持久化云财富网站访问日志
      MongoDBOpts.saveAsHadoop(ycfWebRDD, s"${weboutputuri}_${collector.ycfDomain}")

      // 财猫网站访问日志
      val cmWebRdd = webRdd.filter(x => x._2(1).contains(collector.cmDomain))
//      if (!cmWebRdd.isEmpty)
//        cmWebRdd.map(x => x._2.mkString("::")).toDF().write.mode(SaveMode.Append).text(cmWebPath)

      val cmWebRDD = getWebRDD(cmWebRdd)
      // 持久化财猫网站访问日志
      MongoDBOpts.saveAsHadoop(cmWebRDD, s"${weboutputuri}_${collector.cmDomain}")

      // 新经板网站访问日志
      val xjbWebRdd = webRdd.filter(x => x._2(1).contains(collector.xjbDomain))
//      if (!xjbWebRdd.isEmpty)
//        xjbWebRdd.map(x => x._2.mkString("::")).toDF().write.mode(SaveMode.Append).text(xjbWebPath)

      val xjbWebRDD = getWebRDD(xjbWebRdd)
      // 持久化新经板网站访问日志
      MongoDBOpts.saveAsHadoop(xjbWebRDD, s"${weboutputuri}_${collector.xjbDomain}")

      /**
       * app日志
       */
      val ycfAppPath = s"${path}${collector.ycf_app_pt}" + TimeOpts.calDate()
      val cmAppPath = s"${path}${collector.cm_app_pt}" + TimeOpts.calDate()
      val xjbAppPath = s"${path}${collector.xjb_app_pt}" + TimeOpts.calDate()

      // app访问日志
      val appRdd = kvRDD.filter(x => x._1 == "app").map(x => (x._1, x._2.split("::")))

      // 云财富金服app访问日志
      val ycfAppRdd = appRdd.filter(x => x._2(2).contains(collector.ycfDomain))
//      if (!ycfAppRdd.isEmpty)
//        ycfAppRdd.map(x => x._2.mkString("::")).toDF().write.mode(SaveMode.Append).text(ycfAppPath)
      val ycfAppRDD = getAppRDD(ycfAppRdd)

      // 持久化云财富金服app访问日志
      MongoDBOpts.saveAsHadoop(ycfAppRDD, s"${appoutputuri}_${collector.ycfDomain}")

      // 云财富理财师app访问日志
      val ycfFPAppRdd = appRdd.filter(x => x._2(2).contains(collector.ycfFPDomain))
//      if (!ycfFPAppRdd.isEmpty)
//        ycfFPAppRdd.map(x => x._2.mkString("::")).toDF().write.mode(SaveMode.Append).text(ycfAppPath)
      val ycfFPAppRDD = getAppRDD(ycfFPAppRdd)

      // 持久化云财富理财师app访问日志
      MongoDBOpts.saveAsHadoop(ycfFPAppRDD, s"${appoutputuri}_${collector.ycfDomain}")

      // 财猫app访问日志
      val cmAppRdd = appRdd.filter(x => x._2(2).contains(collector.cmDomain))
//      if (!cmAppRdd.isEmpty)
//        cmAppRdd.map(x => x._2.mkString("::")).toDF().write.mode(SaveMode.Append).text(cmAppPath)
      val cmAppRDD = getAppRDD(cmAppRdd)

      // 持久化财猫App访问日志
      MongoDBOpts.saveAsHadoop(cmAppRDD, s"${appoutputuri}_${collector.cmDomain}")

      // 新经板app访问日志
      val xjbAppRdd = appRdd.filter(x => x._2(2).contains(collector.xjbDomain))
//      if (!xjbAppRdd.isEmpty)
//        xjbAppRdd.map(x => x._2.mkString("::")).toDF().write.mode(SaveMode.Append).text(xjbAppPath)
      val xjbAppRDD = getAppRDD(xjbAppRdd)

      // 持久化新经板App访问日志
      MongoDBOpts.saveAsHadoop(xjbAppRDD, s"${appoutputuri}_${collector.xjbDomain}")

      KafakaOpts.commitAsync(stream, rdd)
    }

    //    stream.print()
    //    val stream2 = stream.map(x => (x.key, x.value))
    //    // 保存web日志
    //    stream2.filter(x => x._1 == "web" || x._1 == "").map(x => {
    //      println(x)
    //      val fileds = x._2.split("::")
    //      //ClientId:Domain:Userid:FirstVisit:Uid:PageTag:hyid:Ip:Title:AjaxType:Referrer:Url:AppVision:StartTime:EndTime:StandTime:Appid
    //
    //      val query = new BasicBSONObject()
    //      query.append("PageTag", fileds(5).toLong).append("AjaxType", "")
    //      //      println("query:" + query.toString)
    //
    //      val setObj = new BasicBSONObject()
    //        .append("ClientId", fileds(0))
    //        .append("Domain", fileds(1))
    //        .append("Uid", fileds(4))
    //        .append("Userid", fileds(2))
    //        .append("FirstVisit", fileds(3).toBoolean)
    //        .append("hyid", fileds(6).toLong)
    //        .append("Url", fileds(11))
    //        .append("Ip", fileds(7))
    //        .append("Title", fileds(8))
    //        .append("AjaxType", fileds(9))
    //        .append("Referrer", fileds(10))
    //        .append("AppVision", fileds(12))
    //        .append("StartTime", TimeOpts.toDate(fileds(13)))
    //        .append("EndTime", TimeOpts.toDate(fileds(14)))
    //        .append("StandTime", fileds(15).toInt)
    //        .append("Appid", fileds(16))
    //
    //      val update = new BasicBSONObject()
    //      update.append("$set", setObj)
    //      //      println("update:" + update.toString)
    //
    //      //      val bson = new BasicBSONObject()
    //      //      bson.put("_id", objectId)
    //      //      bson.put("ClientId", fileds(0))
    //      //      bson.put("Domain", fileds(1))
    //      //      bson.put("Userid", fileds(2))
    //      //      bson.put("FirstVisit", fileds(3))
    //      //      bson.put("Uid", fileds(4))
    //      //      bson.put("PageTag", fileds(5))
    //      //      bson.put("hyid", fileds(6))
    //      //      bson.put("Ip", fileds(7))
    //      //      bson.put("Title", fileds(8))
    //      //      bson.put("AjaxType", fileds(9))
    //      //      bson.put("Referrer", fileds(10))
    //      //      bson.put("Url", fileds(11))
    //      //      bson.put("AppVision", fileds(12))
    //      //      bson.put("StartTime", fileds(13))
    //      //      bson.put("EndTime", fileds(14))
    //      //      bson.put("StandTime", fileds(15))
    //
    //      (query, update)
    //    }).foreachRDD(rdd => {
    //      //      println("web rdd:" + rdd.count)
    //      MongoDBOpts.save(rdd, weboutputuri)
    //    })
    //
    //    // 保存app日志
    //    stream2.filter(x => x._1 == "app").map(x => {
    //      println(x)
    //      val fileds = x._2.split("::")
    //
    //      val objectId = new BsonObjectId()
    //      val query = new BasicBSONObject()
    //      query.append("_id", objectId.getValue)
    //      //      println("query:" + query.toString)
    //
    //      val setObj = new BasicBSONObject()
    //        .append("ClientId", fileds(0))
    //        .append("Platform", fileds(1))
    //        .append("Domain", fileds(2))
    //        .append("Model", fileds(3))
    //        .append("SysVer", fileds(4))
    //        .append("Ip", fileds(5))
    //        .append("ActiveTag", fileds(6))
    //        .append("AppVer", fileds(7))
    //        .append("Province", fileds(8))
    //        .append("City", fileds(9))
    //        .append("Region", fileds(10))
    //        .append("Location", fileds(11))
    //        .append("Longitude", fileds(12).toDouble)
    //        .append("Latitude", fileds(13).toDouble)
    //        .append("StartTime", TimeOpts.toDate(fileds(14)))
    //        .append("hyid", fileds(15).toLong)
    //        .append("url", fileds(16))
    //
    //      val update = new BasicBSONObject()
    //      update.append("$set", setObj)
    //      //      println("update:" + update.toString)
    //
    //      (query, update)
    //    }).foreachRDD(rdd => {
    //      //      println("app rdd:" + rdd.count)
    //      MongoDBOpts.save(rdd, appoutputuri)
    //    })
  }

  /**
   * 解析网站访问日志
   */
  def getWebRDD(kvRDD: RDD[(String, Array[String])]): RDD[(BasicBSONObject, BasicBSONObject)] = {
    kvRDD.map(x => {
      println(x._1 + " " + x._2.mkString("::"))
      val fileds = x._2
      //ClientId:Domain:Userid:FirstVisit:Uid:PageTag:hyid:Ip:Title:AjaxType:Referrer:Url:AppVision:StartTime:EndTime:StandTime:Appid

      val query = new BasicBSONObject()
      query.append("PageTag", fileds(5).toLong).append("AjaxType", "")
      //      println("query:" + query.toString)

      val setObj = new BasicBSONObject()
        .append("ClientId", fileds(0))
        .append("Domain", fileds(1))
        .append("Uid", fileds(4))
        .append("Userid", fileds(2))
        .append("FirstVisit", fileds(3).toBoolean)
        .append("hyid", fileds(6).toLong)
        .append("Url", fileds(11))
        .append("Ip", fileds(7))
        .append("Title", fileds(8))
        .append("AjaxType", fileds(9))
        .append("Referrer", fileds(10))
        .append("AppVision", fileds(12))
        .append("StartTime", TimeOpts.toDate(fileds(13)))
        .append("EndTime", TimeOpts.toDate(fileds(14)))
        .append("StandTime", fileds(15).toInt)
        .append("Appid", fileds(16))

      val update = new BasicBSONObject()
      update.append("$set", setObj)
      //      println("update:" + update.toString)

      (query, update)
    })
  }

  /**
   * 解析App访问日志
   */
  def getAppRDD(kvRDD: RDD[(String, Array[String])]): RDD[(BasicBSONObject, BasicBSONObject)] = {
    kvRDD.map(x => {
      println(x._1 + " " + x._2.mkString("::"))
      val fileds = x._2

      val objectId = new BsonObjectId()
      val query = new BasicBSONObject()
      query.append("_id", objectId.getValue)
      //      println("query:" + query.toString)

      val setObj = new BasicBSONObject()
        .append("ClientId", fileds(0))
        .append("Platform", fileds(1))
        .append("Domain", fileds(2))
        .append("Model", fileds(3))
        .append("SysVer", fileds(4))
        .append("Ip", fileds(5))
        .append("ActiveTag", fileds(6))
        .append("AppVer", fileds(7))
        .append("Province", fileds(8))
        .append("City", fileds(9))
        .append("Region", fileds(10))
        .append("Location", fileds(11))
        .append("Longitude", fileds(12).toDouble)
        .append("Latitude", fileds(13).toDouble)
        .append("StartTime", TimeOpts.toDate(fileds(14)))
        .append("hyid", fileds(15).toLong)
        .append("url", fileds(16))

      val update = new BasicBSONObject()
      update.append("$set", setObj)
      //      println("update:" + update.toString)

      (query, update)
    })
  }
}