package com.supersoft.collector.log.bak.service

import org.apache.log4j.{ Level, Logger }
import org.apache.spark.{ SparkConf, SparkContext }
import org.apache.spark.sql.SparkSession

import scopt.OptionParser

import com.supersoft.common._
import com.supersoft.collector.log.LogOfflineProcessor

object Boot {
  case class Params(
    weboutput: String = null,
    appoutput: String = null)

  def main(args: Array[String]) {
    val defaultParams = Params()

    val parser = new OptionParser[Params]("LogBak") {
      head("LogBak: 备份日志")
      arg[String]("<weboutput>")
        .required()
        .text("weboutput")
        .action((x, c) => c.copy(weboutput = x))
      arg[String]("<appoutput>")
        .required()
        .text("appoutput")
        .action((x, c) => c.copy(appoutput = x))
      note(
        """
          |For example, the following command runs this app on a synthetic dataset:
          |
          | bin/spark-submit --class com.supersoft.collector.log.bak.service.Boot \
          |  /data/supersoft.collector.jar \
          |  mongodb://hadoopUser:123@192.168.1.225:27017/log.WebLogger \
          |  mongodb://hadoopUser:123@192.168.1.225:27017/log.AppLogger
        """.stripMargin)
    }

    parser.parse(args, defaultParams) match {
      case Some(params) => run(params)
      case _            => sys.exit(1)
    }
  }

  def run(params: Params): Unit = {
    println(params)
    val ss = SparkSession.builder()
//            .master("local[*]")
      .appName("LogBak")
      .getOrCreate()

    Logger.getRootLogger.setLevel(Level.WARN)

    try {
      val sc = ss.sparkContext
      val date = TimeOpts.today

      LogOfflineProcessor.bak(sc, params.weboutput, params.appoutput, date)
      
    } catch {
      case e: Exception =>
        LogOpts.save(e)
    } finally {
      ss.close()
      sys.exit(1)
    }
  }
}