package com.supersoft.collector.qt

import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.Dataset

import java.sql.Timestamp

import com.supersoft.common._

object User {

  case class Info(
    id:              String,
    credential_type: String,
    credential_no:   String,
    card_no:         String,
    cvv2:            String,
    valid_period:    String,
    bank_id:         String,
    status:          String,
    name:            String,
    mobile_no:       String,
    create_time:     Timestamp,
    merchant_id:     String,
    payer_id:        String,
    bind_id:         String)

  def load(spark: SparkSession, url: String, user: String, pwd: String): Dataset[Info] = {
    val table = "(SELECT ID,CREDENTIAL_TYPE,CREDENTIAL_NO,CARD_NO,CVV2,VALID_PERIOD,BANK_ID,STATUS,NAME,MOBILE_NO,CREATE_TIME,MERCHANT_ID,PAYER_ID,BIND_ID FROM SHARE_PAY_TRAN_USER) a"
    val df = jdbcOpts.load(spark, url, user, pwd, table)
    //    val table = "(SELECT ID,CREDENTIAL_TYPE,CREDENTIAL_NO,CARD_NO,CVV2,VALID_PERIOD,BANK_ID,STATUS,NAME,MOBILE_NO,CREATE_TIME,MERCHANT_ID,PAYER_ID,BIND_ID,ROW_NUMBER() OVER (ORDER BY ID) RNO FROM SHARE_PAY_TRAN_USER) a"
    //    val df = jdbcUtils.load(spark, url, user, pwd, table, "RNO", numPartitions = 10)

    import spark.implicits._
    val ds = df. /*drop("RNO").*/ as[Info]
    //    ds.show()
    println(df.count)
    println(df.rdd.partitions.size)
    ds
  }

  def save(spark: SparkSession, url: String, user: String, pwd: String) {
    val ds = load(spark, url, user, pwd)

    import com.mongodb.spark._
    MongoSpark.save(ds.write.option("collection", "tran_user").mode("overwrite"))
  }
}