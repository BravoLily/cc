package com.supersoft.collector.log

import org.apache.spark.SparkContext

import java.util.Date

import com.supersoft.common._
import com.supersoft.collector

object LogOfflineProcessor {
  def save(sc: SparkContext, inputUri: String, outputUri: String, date: Date): Boolean = {
    val logsRDD = MongoDBOpts.loadAsSpark(sc, inputUri).filter(doc => doc.getDate("StartTime").before(date))
    val count = logsRDD.count
    if (count > 0) {
      println(s"date:$date,count:$count")

      MongoDBOpts.saveAsSpark(logsRDD, outputUri)
      return true
    }
    return false
  }

  def bak(sc: SparkContext, webUri: String, appUri: String, date: Date) {
    val bak = "bak"
    val ycfWebUri = s"${webUri}_${collector.ycfDomain}"
    val ycfWebBakUri = s"${ycfWebUri}.${bak}"
    if (save(sc, ycfWebUri, ycfWebBakUri, date))
      MongoDBUtil.Remove(ycfWebUri, date)

    val cmWebUri = s"${webUri}_${collector.cmDomain}"
    val cmWebBakUri = s"${cmWebUri}.${bak}"
    if (save(sc, cmWebUri, cmWebBakUri, date))
      MongoDBUtil.Remove(cmWebUri, date)

    val xjbWebUri = s"${webUri}_${collector.xjbDomain}"
    val xjbWebBakUri = s"${xjbWebUri}.${bak}"
    if (save(sc, xjbWebUri, xjbWebBakUri, date))
      MongoDBUtil.Remove(xjbWebUri, date)

    val ycfAppUri = s"${appUri}_${collector.ycfDomain}"
    val ycfAppBakUri = s"${ycfAppUri}.${bak}"
    if (save(sc, ycfAppUri, ycfAppBakUri, date))
      MongoDBUtil.Remove(ycfAppUri, date)

    val cmAppUri = s"${appUri}_${collector.cmDomain}"
    val cmAppBakUri = s"${cmAppUri}.${bak}"
    if (save(sc, cmAppUri, cmAppBakUri, date))
      MongoDBUtil.Remove(cmAppUri, date)

    val xjbAppUri = s"${appUri}_${collector.xjbDomain}"
    val xjbAppBakUri = s"${xjbAppUri}.${bak}"
    if (save(sc, xjbAppUri, xjbAppBakUri, date))
      MongoDBUtil.Remove(xjbAppUri, date)
  }
}