package com.supersoft.collector.log.service

import org.apache.log4j.{ Level, Logger }
import org.apache.spark.{ SparkConf, SparkContext }
import org.apache.spark.sql.SparkSession
import org.apache.spark.streaming.{ StreamingContext, Durations }

import scopt.OptionParser

import com.supersoft.collector.log.LogOnlineProcessor

/**
 * 实时持久化访问日志
 */
object Boot {
  case class Params(
    batchDuration: Int    = 5,
    brokers:       String = null,
    topic:         String = null,
    groupid:       String = null,
    checkpoint:    String = null,
    path:          String = null,
    weboutput:     String = null,
    appoutput:     String = null)

  def main(args: Array[String]) {
    val defaultParams = Params()

    val parser = new OptionParser[Params]("LogCollector") {
      head("LogCollector: collecting kafaka stream save to mongodb.")
      opt[Int]("batchDuration")
        .text(s"number of batchDuration, default: ${defaultParams.batchDuration}")
        .action((x, c) => c.copy(batchDuration = x))
      arg[String]("<brokers>")
        .required()
        .text("brokers")
        .action((x, c) => c.copy(brokers = x))
      arg[String]("<topic>")
        .required()
        .text("topic")
        .action((x, c) => c.copy(topic = x))
      arg[String]("<groupid>")
        .required()
        .text("groupid")
        .action((x, c) => c.copy(groupid = x))
      arg[String]("<checkpoint>")
        .required()
        .text("checkpoint")
        .action((x, c) => c.copy(checkpoint = x))
      arg[String]("<path>")
        .required()
        .text("path")
        .action((x, c) => c.copy(path = x))
      arg[String]("<weboutput>")
        .required()
        .text("weboutput")
        .action((x, c) => c.copy(weboutput = x))
      arg[String]("<appoutput>")
        .required()
        .text("appoutput")
        .action((x, c) => c.copy(appoutput = x))
      note(
        """
          |For example, the following command runs this app on a synthetic dataset:
          |
          | bin/spark-submit --class com.supersoft.collector.log.service.Boot \
          |  /data/supersoft.collector.jar \
          |  --batchDuration 5 \
          |  192.168.1.225:9092 \
          |  Statistic \
          |  log_group_id_for_each_stream \
          |  hdfs://localhost:9000/data/check/log \
          |  hdfs://localhost:9000/log/ \
          |  mongodb://hadoopUser:123@192.168.1.225:27017/log.WebLogger \
          |  mongodb://hadoopUser:123@192.168.1.225:27017/log.AppLogger
        """.stripMargin)
    }

    parser.parse(args, defaultParams) match {
      case Some(params) => run(params)
      case _            => sys.exit(1)
    }

    //    if(args.length < 2) {
    //      System.err.println("Usage: LogCollector <master> <hostname> <port> <input> <output> <file> <iter>")
    //      System.exit(1)
    //    }
    //
    //    run()
  }

  def run(params: Params): Unit = {
    println(params)
    //    val conf = new SparkConf()
    //      .setAppName("LogCollector")
    ////      .setMaster("local[*]")
    //      .set("mongo.output.uri", params.weboutput)
    //      .set("spark.streaming.stopGracefullyOnShutdown", "true")
    //    val sc = new SparkContext(conf)
    val sparkSession = SparkSession.builder()
//      .master("local[*]")
      .appName("LogCollector")
      .getOrCreate()
    val sc = sparkSession.sparkContext

    Logger.getRootLogger.setLevel(Level.WARN)

    val batchDuration = Durations.seconds(params.batchDuration)
    val ssc = new StreamingContext(sc, batchDuration)

    ssc.checkpoint(params.checkpoint)

    LogOnlineProcessor.save(sc, ssc, params.brokers, params.topic, params.groupid, params.path, params.weboutput, params.appoutput)

    // 监听启动
    ssc.start()
    ssc.awaitTermination()

    //    sys.addShutdownHook({
    //      ssc.stop(true, true)
    //    })
  }
}