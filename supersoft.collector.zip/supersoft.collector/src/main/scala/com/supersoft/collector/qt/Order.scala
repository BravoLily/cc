package com.supersoft.collector.qt

import org.apache.spark.sql.SparkSession
import org.apache.spark.rdd.RDD
import org.bson.BasicBSONObject

import java.sql.Timestamp

import com.supersoft.collector._
import com.supersoft.common._

object Order {

  case class Info(
    payordno:       String,
    actdat:         Timestamp,
    cleardat:       Timestamp,
    ordstatus:      String,
    prdordtype:     String,
    paytype:        String,
    multype:        String,
    bankcod:        String,
    paybnkcod:      String,
    bankstldate:    Timestamp,
    bankjrnno:      String,
    accamt:         String,
    mulamt:         String,
    txccy:          String,
    txamt:          String,
    bankpayacno:    String,
    bankpayusernm:  String,
    merno:          String,
    bankerror:      String,
    backerror:      String,
    prdordno:       String,
    cust_id:        String,
    payret:         String,
    prdname:        String,
    merremark:      String,
    bustyp:         String,
    bnkmerno:       String,
    createtime:     Timestamp,
    trantyp:        String,
    termtyp:        String,
    credno:         String,
    payacno:        String,
    filed2:         String,
    pay_channel:    String,
    bank_card_type: String)

  def load(spark: SparkSession, url: String, user: String, pwd: String, path: String): RDD[Info] = {

    val docs = MongoDBOpts.loadAsSpark(spark.sparkContext, path)
      .sortBy(doc => doc.getDate("createtime"), false)
      .take(1)

    var start: String = before
    val end = TimeOpts.date(TimeOpts.today)
    if (docs.length > 0) {
      start = TimeOpts.date(TimeOpts.addDate(docs(0).getDate("createtime"), 1))
    }
    println(start)

    val table = s"(SELECT PAYORDNO,ACTDAT,CLEARDAT,ORDSTATUS,PRDORDTYPE,PAYTYPE,TXCCY,TXAMT,BANKPAYACNO,BANKPAYUSERNM,MERNO,CREATETIME,MULTYPE,BANKCOD,PAYBNKCOD,BANKSTLDATE,BANKJRNNO,ACCAMT,MULAMT,BANKERROR,BACKERROR,PRDORDNO,CUST_ID,PAYRET,PRDNAME,MERREMARK,BNKDAT,BNKJNL,BUSTYP,BNKMERNO,TRACENUMBER,TRACETIME,CBATNO,SREFNO,TERMNO,TRANTYP,TERMTYP,CREDNO,VERSIONNO,PAYACNO,FILED1,FILED2,FILED3,FILED4,FILED5,PAY_CHANNEL,BANK_CARD_TYPE,NOTIFY_MER_FLAG,NOTIFY_MER_TIME,CHANNEL_SEARCH_FLAG,CHANNEL_SEARCH_TIME,AGENT_FEE,AGENT_STL_BATCH_NO,CHANNEL_FEE FROM SHARE_PAY_ORDER WHERE CREATETIME>=to_date('$start','YYYY/MM/DD') AND CREATETIME<to_date('$end','YYYY/MM/DD')) a"
    val df = jdbcOpts.load(spark, url, user, pwd, table)
    //    val table = s"(SELECT PAYORDNO,ACTDAT,CLEARDAT,ORDSTATUS,PRDORDTYPE,PAYTYPE,TXCCY,TXAMT,BANKPAYACNO,BANKPAYUSERNM,MERNO,CREATETIME,MULTYPE,BANKCOD,PAYBNKCOD,BANKSTLDATE,BANKJRNNO,ACCAMT,MULAMT,BANKERROR,BACKERROR,PRDORDNO,CUST_ID,PAYRET,PRDNAME,MERREMARK,BNKDAT,BNKJNL,BUSTYP,BNKMERNO,TRACENUMBER,TRACETIME,CBATNO,SREFNO,TERMNO,TRANTYP,TERMTYP,CREDNO,VERSIONNO,PAYACNO,FILED1,FILED2,FILED3,FILED4,FILED5,PAY_CHANNEL,BANK_CARD_TYPE,NOTIFY_MER_FLAG,NOTIFY_MER_TIME,CHANNEL_SEARCH_FLAG,CHANNEL_SEARCH_TIME,AGENT_FEE,AGENT_STL_BATCH_NO,CHANNEL_FEE,ROW_NUMBER() OVER (ORDER BY PAYORDNO) RNO FROM SHARE_PAY_ORDER WHERE CREATETIME>=to_date('$start','YYYY/MM/DD') AND CREATETIME<to_date('$end','YYYY/MM/DD')) a"
    //    val df = jdbcUtils.load(spark, url, user, pwd, table, "RNO", numPartitions = 10)
    println(table)
    //    df.show()
    println(df.count)
    println(df.rdd.partitions.size)

    import spark.implicits._
    val ds = df. /*drop("RNO").*/ as[Info]
    //    ds.show()
    ds.rdd
  }

  def save(spark: SparkSession, url: String, user: String, pwd: String, path: String) {
    val rdd = load(spark, url, user, pwd, path)
      .map(o => {
        val bson = new BasicBSONObject()
        bson.put("payordno", o.payordno)
        bson.put("actdat", o.actdat)
        bson.put("cleardat", o.cleardat)
        bson.put("ordstatus", o.ordstatus)
        bson.put("prdordtype", o.prdordtype)
        bson.put("paytype", o.paytype)
        bson.put("txccy", o.txccy)
        bson.put("txamt", o.txamt)
        bson.put("bankpayacno", o.bankpayacno)
        bson.put("bankpayusernm", o.bankpayusernm)
        bson.put("merno", o.merno)
        bson.put("createtime", o.createtime)
        bson.put("multype", o.multype)
        bson.put("bankcod", o.bankcod)
        bson.put("paybnkcod", o.paybnkcod)
        bson.put("bankstldate", o.bankstldate)
        bson.put("bankjrnno", o.bankjrnno)
        bson.put("accamt", o.accamt)
        bson.put("mulamt", o.mulamt)
        bson.put("bankerror", o.bankerror)
        bson.put("backerror", o.backerror)
        bson.put("prdordno", o.prdordno)
        bson.put("cust_id", o.cust_id)
        bson.put("payret", o.payret)
        bson.put("prdname", o.prdname)
        bson.put("merremark", o.merremark)
        bson.put("bustyp", o.bustyp)
        bson.put("bnkmerno", o.bnkmerno)
        bson.put("trantyp", o.trantyp)
        bson.put("termtyp", o.termtyp)
        bson.put("credno", o.credno)
        bson.put("payacno", o.payacno)
        bson.put("filed2", o.filed2)
        bson.put("pay_channel", o.pay_channel)
        bson.put("bank_card_type", o.bank_card_type)

        bson
      })

    MongoDBOpts.saveAsHadoop(rdd, path)
  }
}