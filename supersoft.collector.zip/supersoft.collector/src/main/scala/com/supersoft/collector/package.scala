package com.supersoft

package object collector {
  val before = "2014/1/1"
  val ycfDomain = "58ycf.com"
//  val ycfDomain = "192.168.1.225"
  val ycfFPDomain = "mp.58ycf.com"
  val cmDomain = "58cm.com"
  val xjbDomain = "xinjingban.com"
  val web_pt = "web/"
  val app_pt = "app/"
  val ycf_web_pt = s"${web_pt}${ycfDomain}/"
  val cm_web_pt = s"${web_pt}${cmDomain}/"
  val xjb_web_pt = s"${web_pt}${xjbDomain}/"
  val ycf_app_pt = s"${app_pt}${ycfDomain}/"
  val cm_app_pt = s"${app_pt}${cmDomain}/"
  val xjb_app_pt = s"${app_pt}${xjbDomain}/"
}