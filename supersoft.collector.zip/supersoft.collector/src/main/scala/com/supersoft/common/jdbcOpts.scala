package com.supersoft.common

import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.DataFrame

object jdbcOpts {
  /*
   *
   */
  def load(spark: SparkSession, url: String, user: String, pwd: String, dbtable: String, columnName: String = "*", lowerBound: Long = 1, upperBound: Long = 100000, numPartitions: Int = 1): DataFrame = {
    //    spark.read
    //      .format("jdbc")
    //      .option("driver", "oracle.jdbc.OracleDriver")
    //      .option("url", "jdbc:oracle:thin:@" + url)
    //      .option("dbtable", dbtable)
    //      .option("user", user)
    //      .option("password", pwd)
    //      .option("fetchSize", 10000)
    //      .load()

    val props = new java.util.Properties
    props.setProperty("driver", "oracle.jdbc.OracleDriver")
    props.setProperty("user", user)
    props.setProperty("password", pwd)
    props.setProperty("fetchSize", "10000")
    spark.read.jdbc("jdbc:oracle:thin:@" + url, dbtable, columnName, lowerBound, upperBound, numPartitions, props)
    //    spark.read.jdbc("jdbc:oracle:thin:@" + url, dbtable, props)
  }
}