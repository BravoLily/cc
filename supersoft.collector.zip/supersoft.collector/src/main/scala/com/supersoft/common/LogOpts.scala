package com.supersoft.common

import org.apache.log4j.Logger
import org.apache.log4j.PropertyConfigurator

class LogOpts {
}

object LogOpts {
  private val logger = Logger.getLogger(classOf[LogOpts])

  def save(e: Exception): Unit = {
    val fileUrl = this.getClass.getClassLoader.getResourceAsStream("log4j.properties")
    PropertyConfigurator.configure(fileUrl)
    var st = ""
    e.getStackTrace.foreach {
      x => st += (x.toString + "\n")
    }
    val output_log = e.getMessage + st + "*****************************************************************"
    logger.error(output_log)
  }
}