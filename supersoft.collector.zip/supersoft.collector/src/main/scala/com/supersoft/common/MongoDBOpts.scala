package com.supersoft.common

import org.apache.spark.SparkContext
import org.apache.spark.rdd.RDD
import com.mongodb.hadoop.{ MongoInputFormat, MongoOutputFormat }
import com.mongodb.hadoop.io.MongoUpdateWritable
import com.mongodb.spark._
import com.mongodb.spark.config._
import org.apache.hadoop.conf.Configuration
import org.bson.{ BSONObject, BasicBSONObject, Document }
import com.mongodb.hadoop.MongoInputFormat
import com.mongodb.hadoop.MongoOutputFormat
import org.apache.spark.sql.DataFrame

object MongoDBOpts {

  def loadAsSpark(sc: SparkContext, inputuri: String): RDD[Document] = {
    val readConfig = ReadConfig(Map("uri" -> inputuri))
    val mongoRDD = MongoSpark.load(sc, readConfig)
    //    sc.loadFromMongoDB(readConfig)
    mongoRDD
  }

  def saveAsSpark(rdd: RDD[Document], outputUri: String): Unit = {
    val writeVectorConfig = WriteConfig(Map("spark.mongodb.output.uri" -> outputUri))
    MongoSpark.save(rdd, writeVectorConfig)
  }

  def loadAsHadoop(sc: SparkContext): RDD[(Object, BSONObject)] = {
    val inputuri = sc.getConf.get("mongo.input.uri")
    loadAsHadoop(sc, inputuri)
  }

  def loadAsHadoop(sc: SparkContext, inputuri: String): RDD[(Object, BSONObject)] = {
    val mongoConfig = new Configuration()
    mongoConfig.set("mongo.input.uri", inputuri)

    val rdd = sc.newAPIHadoopRDD(
      mongoConfig, // Configuration
      classOf[MongoInputFormat], // InputFormat
      classOf[Object], // Key type
      classOf[BSONObject]) // Value type

    rdd
  }

  def saveAsHadoop(rdd: RDD[(BasicBSONObject, BasicBSONObject)], outputuri: String, upsert: Boolean = true,
                   multiUpdate: Boolean = false, replace: Boolean = false): Unit = {
    //    if (rdd.isEmpty)
    //      return

    val outputConfig = new Configuration()
    outputConfig.set("mongo.output.uri", outputuri)

    saveAsHadoop(rdd, outputConfig, upsert, multiUpdate, replace)
  }

  def saveAsHadoop(rdd: RDD[(BasicBSONObject, BasicBSONObject)], outputConfig: Configuration, upsert: Boolean,
                   multiUpdate: Boolean, replace: Boolean): Unit = {
    //    if (rdd.isEmpty)
    //      return

    rdd.map(o =>
      ((null, new BasicBSONObject()),
        new MongoUpdateWritable(
          o._1, // Query
          o._2, // Update operation
          upsert, // Upsert
          multiUpdate, // Update multiple documents
          replace // replace
        ))).saveAsNewAPIHadoopFile(
      "file:///bogus", //"file:///this-is-completely-unused", //
      classOf[Object],
      classOf[MongoUpdateWritable],
      classOf[MongoOutputFormat[Object, MongoUpdateWritable]],
      outputConfig)
  }

  def saveAsHadoop(rdd: RDD[BasicBSONObject], outputuri: String): Unit = {
    //    if (rdd.isEmpty)
    //      return

    val outputConfig = new Configuration()
    outputConfig.set("mongo.output.uri", outputuri)

    rdd.map(x => (null, x)).saveAsNewAPIHadoopFile(
      "file:///bogus", //"file:///this-is-completely-unused", //
      classOf[Object],
      classOf[BSONObject],
      classOf[MongoOutputFormat[Object, BSONObject]],
      outputConfig)
  }
}