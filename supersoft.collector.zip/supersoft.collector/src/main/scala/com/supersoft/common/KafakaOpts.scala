package com.supersoft.common

import org.apache.spark.streaming.StreamingContext
import org.apache.spark.streaming.kafka010.{ KafkaUtils, OffsetRange, LocationStrategies, ConsumerStrategies, HasOffsetRanges, CanCommitOffsets }
import org.apache.spark.streaming.dstream.{ DStream, InputDStream }
import org.apache.spark.annotation.Experimental
import org.apache.spark.rdd.RDD
import org.apache.kafka.clients.consumer.ConsumerRecord
import org.apache.kafka.common.serialization.StringDeserializer

object KafakaOpts {
  @Experimental
  def directStream(ssc: StreamingContext, brokers: String, topic: String, groupid: String): InputDStream[ConsumerRecord[String, String]] = {
    val kafkaParams = Map[String, Object](
      "bootstrap.servers" -> brokers,
      "key.deserializer" -> classOf[StringDeserializer],
      "value.deserializer" -> classOf[StringDeserializer],
      "group.id" -> groupid,
      "auto.offset.reset" -> "latest",
//      "partition.assignment.strategy" -> "org.apache.kafka.clients.consumer.RangeAssignor",
      "enable.auto.commit" -> (false: java.lang.Boolean))
    val topics = Array(topic)
    //    println(kafkaParams)
    KafkaUtils.createDirectStream[String, String](ssc, LocationStrategies.PreferConsistent, ConsumerStrategies.Subscribe[String, String](topics, kafkaParams))
  }

  /**
   * 异步提交offset
   */
  def commitAsync(stream: InputDStream[ConsumerRecord[String, String]], rdd: RDD[ConsumerRecord[String, String]]) {
    val offsetRanges = rdd.asInstanceOf[HasOffsetRanges].offsetRanges

    // some time later, after outputs have completed
    stream.asInstanceOf[CanCommitOffsets].commitAsync(offsetRanges)
  }
}