package com.supersoft.common

import java.text.SimpleDateFormat
import java.util.{ Calendar, Date }
import java.time.LocalTime

object TimeOpts {

  def now(): Date = {
    val now = new Date
    format(now, "yyyy/MM/dd HH:mm:ss")
  }

  def hours(): Int = {
    LocalTime.now().getHour
  }

  def today(): Date = {
    val now = new Date
    format(now, "yyyy/MM/dd")
  }

  def addDate(dt: Date, day: Int): Date = {
    val c = Calendar.getInstance();
    c.setTime(dt);
    c.add(Calendar.DATE, day);
    format(c.getTime, "yyyy/MM/dd")
  }

  def date(dt: Date): String = {
    val sdf = new SimpleDateFormat("yyyy/MM/dd")
    sdf.format(dt)
  }

  def calDate(format: String = "yyyy-MM-dd"): String = {
    val calendar = Calendar.getInstance()
//    calendar.add(Calendar.DATE, -1)
    val date_format = new SimpleDateFormat(format)
    date_format.format(calendar.getTime)
  }

  def calDate(date_s: String, d_bias: Int): String = {
    val sdf = new SimpleDateFormat("yyyy/MM/dd")

    val c = Calendar.getInstance()
    val date = sdf.parse(date_s)
    c.setTime(date)

    val d = c.get(Calendar.DATE)
    c.set(Calendar.DATE, d + d_bias)

    sdf.format(c.getTime)
  }

  def toDate(date_s: String): Date = {
    val format = if (date_s.indexOf(".") > 0) "yyyy-MM-dd HH:mm:ss.SSS" else "yyyy/MM/dd HH:mm:ss"
    val sdf = new SimpleDateFormat(format)
    sdf.parse(date_s)
  }

  def format(dt: Date, format: String = "yyyy/MM/dd HH:mm:ss"): Date = {
    val sdf = new SimpleDateFormat(format)
    val date_s = sdf.format(dt)
    sdf.parse(date_s)
  }

  def isFreeTime(): Boolean = {
    val now = LocalTime.now()
    val hour = now.getHour
    val minute = now.getMinute

    hour == 0 && (minute >= 30 || minute <= 59)
  }

  def isRunCycle(): Boolean = {
    val now = LocalTime.now()
    val hour = now.getHour
    val minute = now.getMinute

    hour % 3 == 0 && minute == 5
  }

  def before(): Date = {
    val c = Calendar.getInstance
    c.add(Calendar.MONTH, -6)
    c.getTime
  }

}