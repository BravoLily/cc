import traceback

import pymongo
import sys

from src.setting import mongodb


class ConnectMongo:
    def __init__(self,
                 mongo_host=mongodb['mongo_host'],
                 mongo_port=mongodb['mongo_port'],
                 username=mongodb['username'],
                 password=mongodb['password'],
                 db="KnowledgeBase"):
        self.mongo_host = mongo_host
        self.mongo_port = mongo_port
        self.username = username
        self.password = password
        self.database = db
        try:
            self.client = pymongo.MongoClient(host=self.mongo_host, port=self.mongo_port)
            self.db_auth = self.client.admin
            self.connected = self.db_auth.authenticate(self.username, self.password)

            self.db = self.client[self.database]

        except Exception:
            print(traceback.format_exc())
            print('Connect Statics Database Fail.')
            # sys.exit(1)

if __name__ == '__main__':
    mongodb_uri="mongodb://ycfadmin:123@192.168.1.225:27017/log.WebLogger?authSource=admin"
    client = pymongo.MongoClient(mongodb_uri)
    db=client.get_database()
    cname=[x for x in db.collection_names() if db.name+'.'+x in mongodb_uri][0]
    print(db.get_collection(cname).find_one())
    print("==========")
