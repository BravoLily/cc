import win32serviceutil
import win32service
import win32event
import sys, os


class SmallestPythonService(win32serviceutil.ServiceFramework):
    _svc_name_ = "PythonServiceQa"
    _svc_display_name_ = "The Qa process Python Service"
    def __init__(self, args):
        win32serviceutil.ServiceFramework.__init__(self, args)
        # Create an event which we will use to wait on.
        # The "service stop" request will set this event.
        self.hWaitStop = win32event.CreateEvent(None, 0, 0, None)

    def SvcStop(self):
        # Before we do anything, tell the SCM we are starting the stop process.
        self.ReportServiceStatus(win32service.SERVICE_STOP_PENDING)
        # And set my event.
        win32event.SetEvent(self.hWaitStop)

    def SvcDoRun(self):
        import logging
        curPath = os.path.abspath(os.path.dirname(__file__))
        rootPath = os.path.split(curPath)[0]
        logging.basicConfig(level=logging.DEBUG,
                            format='%(asctime)s %(filename)s[line:%(lineno)d] %(levelname)s %(message)s',
                            datefmt='%a, %d %b %Y %H:%M:%S',
                            filename=rootPath+'\qa.log',
                            filemode='a')
        sys.path.append(os.path.split(rootPath)[0])
        from src.online.boot import app,wsgi,webserver
        app.logger.info("server is runing.......")
        app.config['JSON_AS_ASCII'] = False
        app.config.update(RESTFUL_JSON=dict(ensure_ascii=False))
        server = wsgi.WSGIServer((webserver['host'], webserver['port']), app)
        server.serve_forever()

        win32event.WaitForSingleObject(self.hWaitStop, win32event.INFINITE)

if __name__=='__main__':
    win32serviceutil.HandleCommandLine(SmallestPythonService)