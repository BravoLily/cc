import random
import string

import jieba

from bson import ObjectId
from gensim.models import Word2Vec

from src.mongo_conn import ConnectMongo
from src.online.result_info import ResultInfo
from src.setting import wordmodel_file

punc = " ！？｡＂＃＄％＆＇（）＊＋，－／：；" \
       "＜＝＞＠［＼］＾＿｀｛｜｝～｟｠｢｣､、〃" \
       "《》「」『』【】〔〕〖〗〘〙〚〛" \
       "〜〝〞〟〰〾〿–—‘’‛“”„‟…‧﹏."
PUN = string.punctuation + punc

wordmodel = Word2Vec.load(wordmodel_file)
conn = ConnectMongo(db="KnowledgeBase")


def seg(line):
    """
    :param line: 需要分词的句子
    :return:
    """
    trantab = str.maketrans(line, line, PUN)
    line = line.translate(trantab)
    jieba.add_word('云财富')
    seg_list = jieba.cut(line, HMM=True)
    seged_list = []
    for s in seg_list:
        if s in wordmodel.wv.vocab.keys():
            seged_list.append(s)
    return seged_list


def q_sim(focusid, text, size):
    words = seg(text)

    if not words:
        return 0, get_std_answer("安全回答")

    collection = conn.db['qa_question']
    res = []

    for item in collection.find({"AnswerIdx": {'$exists': True}, 'QFocus': {'$in': focusid}}):
        question = seg(item["Question"])
        if item['AnswerIdx'] and len(item['AnswerIdx']) and len(question):
            score = wordmodel.wv.n_similarity(words, question)

            answernum = len(item["AnswerIdx"])

            # 答案不止一个
            if answernum > 1:

                # 选出正确的答案
                rightlist = []
                for i in item["AnswerIdx"]:
                    if i["Rela"] == 1:
                        rightlist.append(i)

                # 当有正确答案时候，随机选择一个正确答案存入
                rightnum = len(rightlist)

                if rightnum == 1:
                    res.append(ResultInfo(
                        item["_id"],
                        rightlist[0]["aid"],
                        score, item["Question"],
                        1))
                elif rightnum > 1:
                    r = random.randint(0, rightnum - 1)
                    res.append(ResultInfo(
                        item["_id"],
                        rightlist[r]["aid"],
                        score, item["Question"],
                        rightnum))

            # 答案只有一个
            else:
                # 唯一的一个答案正确的时候，存入res
                if item["AnswerIdx"][0]["Rela"] == 1:
                    res.append(ResultInfo(
                        item["_id"],
                        item["AnswerIdx"][0]["aid"],
                        score, item["Question"],
                        1))

    res.sort(key=lambda x: x.score, reverse=True)

    if res[0].score < 0.5:
        return 0, get_std_answer("安全回答")

    # 匹配度高的时候，返回一个答案
    elif res[0].score > 0.9:
        return 1, res[0]

    else:
        return 2, res[0:size]


def get_sayHi_question():

    collection = conn.db['qa_question']
    res = []
    std_question1 = collection.find_one({"scene": "打招呼问题1"})
    std_question2 = collection.find_one({"scene": "打招呼问题2"})
    res.append(ResultInfo(std_question1["_id"],
                          std_question1["AnswerIdx"][0]["aid"],
                          1,
                          std_question1["Question"],
                          0))
    res.append(ResultInfo(std_question2["_id"],
                          std_question2["AnswerIdx"][0]["aid"],
                          1,
                          std_question2["Question"],
                          0))
    return 1, res


def get_std_answer(scene):
    collection = conn.db['qa_std_answer']
    stdanswer = collection.find_one({'scene': scene})

    return stdanswer['std_answer']


def get_a(aid):
    collection_answer = conn.db['qa_answer']
    answer = collection_answer.find_one({'_id': aid})

    return answer['Answer']


def get_focus(name):
    focus_col = conn.db['qa_focus']
    count = focus_col.count()

    nameList = []
    focus = None

    for item in focus_col.find():
        nameList.append(item['Name'])

    if name is None:
        focusid = [x for x in range(count)]

    elif isinstance(name, int) and name in range(count):
        focusid = [name]

    elif isinstance(name, str) and name in nameList:
        focuscol = focus_col.find_one({'Name': name})
        focus = focuscol['Focus']
        focusid = [focus]

    else:
        raise ValueError("Error: Focus wrong.")

    return focusid, focus


if __name__ == '__main__':

    sayHi = get_std_answer("打招呼1")
    print(sayHi)
    sayHi = get_std_answer("打招呼2")
    print(sayHi)


    # tag, sayHi_question = get_sayHi_question()
    # for i in sayHi_question:
    #     print(i.qid, i.aid)
    #
    # focusInput = None
    # foucusid, focus = get_focus(focusInput)
    #
    queationInput = "B股"
    t, ress = q_sim([0, 1], queationInput, 10)

    print("t", t)
    if t == 1:
        print(ress.aid)
    elif t == 2:
        for i in ress:
            print(i.aid)

