

class ResultInfo(object):
    def __init__(self, qid, aid, score, text, ensure):
        self.qid = qid
        self.aid = aid
        self.score = score
        self.text = text
        self.ensure = ensure  # 正确答案的个数

