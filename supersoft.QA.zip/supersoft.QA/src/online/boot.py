# -*- coding: utf-8 -*-
import sys, os

import importlib,sys
importlib.reload(sys)

import time
import traceback
curPath = os.path.abspath(os.path.dirname(__file__))
rootPath = os.path.split(curPath)[0]
sys.path.append(os.path.split(rootPath)[0])

from bson import ObjectId
from gevent import monkey, wsgi
import datetime
monkey.patch_all()
from flask import Flask, request, jsonify, make_response

from src.online.qa_predict_sim import q_sim, get_a, wordmodel,get_focus,get_sayHi_question,get_std_answer
from src.mongo_conn import ConnectMongo
from src.setting import webserver
import logging
logging.basicConfig(level=logging.DEBUG,
                    format='%(asctime)s %(filename)s[line:%(lineno)d] %(levelname)s %(message)s',
                    datefmt='%a, %d %b %Y %H:%M:%S',
                    filename=rootPath+'\qa.log',
                    filemode='a')

if sys.executable.endswith("pythonw.exe"):
    sys.stdout = open(os.devnull, "w");
    sys.stderr = open(os.path.join(os.getenv("TEMP"), "stderr-"+os.path.basename(sys.argv[0])), "w")




# class Logger(object):
#     def __init__(self, filename='default.log', stream=sys.stdout):
#         self.terminal = stream
#         self.log = open(filename, 'a')
# 
#     def write(self, message):
#         self.terminal.write(message)
#         self.log.write(message)
# 
#     def flush(self):
#         pass
# 
# sys.stdout = Logger("qa.log", sys.stdout)
# sys.stderr = Logger("qa.log", sys.stderr)

app = Flask(__name__)


# 返回可能的问答对

def return_ques_ans():
    return_dict = {"code": 200,
                   "mes": "success",
                   "data": [
                       {"ques": "", "ans": ""},
                       {"ques": "", "ans": ""},
                       {"ques": "", "ans": ""}
                   ]
                   }
    jsonify(return_dict)
    return "json"


# 返回唯一的答案
def return_unique_ans():
    jsonify({"code": 200, "mes": "success", "data": {"ans": ""}})
    return "json"


# 返回预设答案
def return_preset_ans():
    list = []
    jsonify({"code": 202, "mes": "success", "data": {"ans": list[1]}})
    return "json"


# 安全回答
def return_safe_ans():
    list = []
    jsonify({"code": 400, "mes": "success", "data": {"ans": list[1]}})
    return "json"


@app.route("/word/<string:question>/<int:limit>/<string:cls>")
def index(question, limit, cls):
    focusname = cls
    text = question
    size = limit
    res = q_sim( focusname, text, wordmodel, size)
    result = get_a( res)
    ff = "|".join('%s' % id for id in result)
    return ff


# http://127.0.0.1:11111/autoans?question=云财富的产品购买了之后，什么时候获得收益？&limit=5&cls=理财
@app.route('/autoans', methods=['get', 'post'])
def autoans():

    time_stamp_s1 = datetime.datetime.now()

    queationInput = request.values.get('questionParent', type=str)  # 用户输入的原始问提
    limit = request.values.get('limit', type=int)
    focusInput = request.values.get('focusinput', type=int)
    sessionID = request.values.get('sessionid', type=str)
    queationInputc = request.values.get('questionChild', type=str) #找出的相似问提

    logging.info("=======input args:",str(request.values))

    time_stamp_s2 = datetime.datetime.now()
    logging.info("=======parse args cost time:",(time_stamp_s2-time_stamp_s1).microseconds//1000)

    if not sessionID:
        time_stamp_s3 = datetime.datetime.now()
        logging.info("=======total cost time:",(time_stamp_s3-time_stamp_s1).microseconds//1000)
        return jsonify({"code": 500, "msg": "sessionid is empty"})
    if queationInputc and not queationInput:
        time_stamp_s3 = datetime.datetime.now()
        logging.info("=======total cost time:",(time_stamp_s3-time_stamp_s1).microseconds//1000)
        return jsonify({"code": 500, "msg": "child question has not parent"})

    foucusid, focus = get_focus(focusInput)
    time_stamp_s3 = datetime.datetime.now()
    logging.info("=======fench focus cost time:",(time_stamp_s3-time_stamp_s2).microseconds//1000)
    focus_save=focus
    if not focus: focus=""
    sayHi1=get_std_answer("打招呼1")
    sayHi2=get_std_answer("打招呼2")
    sayHi=sayHi1+"[br]"+sayHi2
    try:
        # if not queationInput:
        #     sayHi = get_std_answer("打招呼")
        #     logging.info(sayHi)
        #     result_dict={"qid":None,
        #                  "aid":None,
        #                  "qtext":None,
        #                  "scoce":None,
        #                  "focus":None,
        #                  "ans":sayHi,
        #                  "count":None
        #                  }
        #     return jsonify({"code": 200,"queationInput":None, "msg": "success", "data": [result_dict],"type":3})

        if not queationInput:
            tag, sayHi_question = get_sayHi_question()

            ques_ans=[]
            for i in sayHi_question:
                logging.info(i.text, i.score)
                answer=get_a(i.aid)
                result_dict={"qid":str(i.qid),
                             "aid":str(i.aid),
                             "qtext":str(i.text),
                             "scoce":i.score,
                             "focus":focus,
                             "ans":answer,
                             "count":i.ensure
                             }
                ques_ans.append(result_dict)

            time_stamp_s4 = datetime.datetime.now()
            logging.info("=======fench say hi cost time:",(time_stamp_s4-time_stamp_s3).microseconds//1000,"===type:",3)

            # return jsonify({"code": 200,"queationInput":None, "msg": "success", "data": ques_ans,"type":3})
            return jsonify({"code": 200,"queationInput":sayHi, "msg": "success", "data": ques_ans,"type":3})



        #用户选定相似的问题
        if queationInputc:
            t, ress = q_sim( foucusid, queationInputc, 1)
        else:
            if not limit: limit=5
            t, ress = q_sim( foucusid, queationInput, limit)

        time_stamp_s4 = datetime.datetime.now()
        logging.info("=======fench sim_question cost time:",(time_stamp_s4-time_stamp_s3).microseconds//1000)

        if t == 0:
            answer = ress
            logging.info(answer)
            if queationInput != sayHi:
                save_question(queationInput, focus_save, None, None, None, sessionID, 0)
            # result_dict={"qid":None,
            #              "aid":None,
            #              "qtext":None,
            #              "scoce":None,
            #              "focus":focus,
            #              "ans":answer,
            #              "count":None
            #              }
            result_dict={"qid":"",
                         "aid":"",
                         "qtext":"",
                         "scoce":0.0,
                         "focus":focus,
                         "ans":answer,
                         "count":0
                         }
            time_stamp_s5 = datetime.datetime.now()
            logging.info("=======save question cost time:",(time_stamp_s5-time_stamp_s4).microseconds//1000,"===type:",t)
            logging.info("=======total cost time:",(time_stamp_s5-time_stamp_s1).microseconds//1000)

            return jsonify({"code": 200,"queationInput":queationInput, "msg": "success", "data": [result_dict],"type":t})
        elif t == 1:
            answer=get_a(ress.aid)
            result_dict={"qid":str(ress.qid),
                         "aid":str(ress.aid),
                         "qtext":str(ress.text),
                         "scoce":ress.score,
                         "focus":focus,
                         "ans":answer,
                         "count":ress.ensure
                         }
            if queationInput != sayHi:
                save_question(queationInput, focus_save, answer, ress.aid, None, sessionID, 1)

            time_stamp_s5 = datetime.datetime.now()
            logging.info("=======save question cost time:",(time_stamp_s5-time_stamp_s4).microseconds//1000,"===type:",t)
            logging.info("=======total cost time:",(time_stamp_s5-time_stamp_s1).microseconds//1000)

            return jsonify({"code": 200, "queationInput":queationInput,"msg": "success", "data": [result_dict],"type":t})
        else:

            if len(ress)==1:
                answer=get_a(ress[0].aid)
                result_dict={"qid":str(ress[0].qid),
                             "aid":str(ress[0].aid),
                             "qtext":str(ress[0].text),
                             "scoce":ress[0].score,
                             "focus":focus,
                             "ans":answer,
                             "count":ress[0].ensure
                             }
                if queationInput != sayHi:
                    save_question(queationInput, focus_save, answer, ress[0].aid, None, sessionID, 1)

                time_stamp_s5 = datetime.datetime.now()
                logging.info("=======save question cost time:",(time_stamp_s5-time_stamp_s4).microseconds//1000,"===type:",4)
                logging.info("=======total cost time:",(time_stamp_s5-time_stamp_s1).microseconds//1000)

                return jsonify({"code": 200, "queationInput":queationInput,"msg": "success", "data": [result_dict],"type":4})
            else:
                ques_ans=[]
                for i in ress:
                    logging.info(i.text, i.score)
                    answer=get_a(i.aid)
                    result_dict={"qid":str(i.qid),
                                 "aid":str(i.aid),
                                 "qtext":str(i.text),
                                 "scoce":i.score,
                                 "focus":focus,
                                 "ans":answer,
                                 "count":i.ensure
                                 }
                    ques_ans.append(result_dict)

                    time_stamp_s5 = datetime.datetime.now()
                    logging.info("=======save question cost time:",(time_stamp_s5-time_stamp_s4).microseconds//1000,"===type:",t)
                    logging.info("=======total cost time:",(time_stamp_s5-time_stamp_s1).microseconds//1000)

                return jsonify({"code": 200, "queationInput":queationInput,"msg": "success", "data": ques_ans,"type":t})

    except Exception as e:
        logging.info ('traceback.format_exc():\n%s' % traceback.format_exc())

        return jsonify({"code": 500, "msg": str(e)})
        # abort(500)


    # python_to_json = json.dumps(result,ensure_ascii=False)

# http://127.0.0.1:11111/autoansid?aid=xxxxxxxxxxxxxxxxxx？&sessionid=xxxxxxxxxxx&focus=xxxxxxxx&question=xxxxxxxx
@app.route('/autoansid', methods=['get', 'post'])
def autoansid():
    queationInput = request.values.get('question', type=str)
    aid = request.values.get('aid', type=str)
    focus = request.values.get('focus', type=str)
    sessionID = request.values.get('sessionid', type=str)

    try:
        answer=get_a(ObjectId(aid))
        result_dict={"aid":aid,
                     "ans":answer
                     }

        save_question(queationInput, focus, answer, ObjectId(aid), None, sessionID, 1)

        return jsonify({"code": 200, "queationInput":queationInput,"msg": "success", "data": result_dict,"type":3})
    except Exception as e:
        return jsonify({"code": 500, "msg": str(e)})

@app.route('/', methods=['get', 'post'])
def welcome():
    return "welcome to ai world"


@app.errorhandler(404)
def not_found(error):
    return make_response(jsonify({"code": 404, "msg": "error"}), 404)

@app.errorhandler(500)
def not_found(error):
    return make_response(jsonify({"code": 500, "msg": "参数有误"}), 500)




def save_question(
        queationInput,
        qfocusInput,
        answerReturn,
        answerID,
        relaInput,
        sessionID,
        status):
    conHistory = ConnectMongo(db="HistoryBase")
    colHistory = conHistory.db['qa_history']
    ansdic = {"answerID": answerID, "Answer": answerReturn, "Rela": relaInput}
    dic = {"Question": queationInput,
           "QFocus": qfocusInput,
           "AnswerIdx": [ansdic],
           "sessionID": sessionID,
           "status": status,
           "Time": time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
           }
    colHistory.insert(dic)
    conHistory.client.close()




if __name__ == "__main__":
    app.logger.info("server is runing.......")
    app.config['JSON_AS_ASCII'] = False
    app.config.update(RESTFUL_JSON=dict(ensure_ascii=False))

    server = wsgi.WSGIServer((webserver['host'], webserver['port']), app)

    server.serve_forever()

