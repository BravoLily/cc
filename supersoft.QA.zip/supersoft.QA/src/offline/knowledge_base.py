import string

import jieba
import pymssql

from src.mongo_conn import ConnectMongo
from src.sql_conn import ConnectMySQL

punc = " ！？｡＂＃＄％＆＇（）＊＋，－／：；" \
       "＜＝＞＠［＼］＾＿｀｛｜｝～｟｠｢｣､、〃" \
       "《》「」『』【】〔〕〖〗〘〙〚〛" \
       "〜〝〞〟〰〾〿–—‘’‛“”„‟…‧﹏."
PUN = string.punctuation + punc


def seg(line):
    trantab = str.maketrans(line, line, PUN)
    line = line.translate(trantab)
    seg_list = jieba.cut(line, HMM=True)
    seged_list = []
    for s in seg_list:
        seged_list.append(s)
    return seged_list


# 数据迁移过程中，虽然问题和答案涉及许多重复代码
# 但考虑到数据内容可能会改变，为了修改方便，先不进行重构


def q_to_mongo(db_sql, conn_mongo):

    col_question = conn_mongo.db['qa_question']

    qsql = "SELECT [ID],[Remark],[AnswerCount] FROM [cazuresnsdb].[dbo].[T_Question]"

    ms = ConnectMySQL(db=db_sql)
    qres = ms.ExecQuery(qsql)
    for row in qres:
        qdic = {"QID": row[0], "Question": row[1], "AnswerCount": row[2]}
        col_question.insert(qdic)


def a_to_mongo(db_sql, conn_mongo):
    """
    :return:
    """
    col_answer = conn_mongo.db['qa_answer']

    asql = "SELECT [AnswerId],[Answer],[QuestionId] FROM [cazuresnsdb].[dbo].[T_Answer]"

    ms = ConnectMySQL(db=db_sql)
    ares = ms.ExecQuery(asql)
    for row in ares:
        adic = {"AID": row[0], "Answer": row[1], "Relation": [{"QId": row[2], "Rela": 1}]}
        col_answer.insert(adic)


def insert_focus(conn):
    """
    不知道之后这个focus数据从哪儿来
    :param conn:
    :param col:
    :return:
    """
    col_question = conn.db['qa_question']
    # col_answer = conn.db['qa_answer']
    col_focus = conn.db['qa_focus']
    focus = col_focus.find_one({}, {'_id': 0})
    for k in focus:
        col_question.update_many(
            {'QFocus': {'$exists': False},
             'Question': {'$regex': ".*" + k + ".*"}},
            {'$set': {"QFocus": focus[k]}})


def look_null_data(conn, col, filt):
    """
    查找空值，有问题的
    :param conn:
    :param colqa:
    :return:
    """
    col_qa = conn.db[col]
    for item in col_qa.find(filt):
        print(item)
        str1 = input("请问是否删除 Y/N： ")
        if str1.lower() == 'y':
            col_qa.remove({"_id": item["_id"]})


def del_repeat_data(conn, colqa):
    """
    删除重复数据
    :param conn:
    :param colqa:
    :return:
    """
    col_qa = conn.db[colqa]
    for i in col_qa.distinct('Question'):
        num = col_qa.count({"Question": i})
        for j in range(1, num):
            col_qa.remove({"Question": i}, 0)


def insert_answercount(conn_mongo, db_sql):
    col_question = conn_mongo.db['qa_question']

    qsql = "SELECT [ID],[AnswerCount] FROM [cazuresnsdb].[dbo].[T_Question]"

    ms = ConnectMySQL(db=db_sql)
    qres = ms.ExecQuery(qsql)
    for row in qres:
        col_question.update({'QId': row[0]}, {'$set': {"AnswerCount": row[1]}})


if __name__ == '__main__':
    conn_mongo = ConnectMongo("KnowledgeBase")
    db_sql = "cazuresnsdb"
    insert_answercount(conn_mongo, db_sql)