import logging
import string
import warnings

import jieba
import os

warnings.filterwarnings(action='ignore', category=UserWarning, module='gensim')
from gensim.models import Word2Vec

from src.mongo_conn import ConnectMongo
from src.offline.data_helper import seg
from src.setting import modelpath

logging.basicConfig(format='%(asctime)s : %(levelname)s : %(message)s', level=logging.INFO)

PUNC = " ！？。＂＃＄％＆＇（）＊＋，－／：" \
       "；＜＝＞＠［＼］＾＿｀｛｜｝～｟｠｢｣､、" \
       "〃《》「」『』【】〔〕〖〗〘〙〚〛〜" \
       "〝〞〟〰〾〿–—‘’‛“”„‟…‧﹏."
PUN = string.punctuation + PUNC

conn1 = ConnectMongo(db="KnowledgeBase")
conn2 = ConnectMongo(db="log")


def focus(conn, col):
    """
    建focus表
    :param conn:
    :param col:
    :return:
    """
    db_collection = conn.db[col]
    focuslist = ['理财', '基金', '信托', '保险', '债券', '股票', '平台', '理财师', '其他']
    for i, key in enumerate(focuslist):
        dic = {"Focus": i, "Name": key}
        db_collection.insert(dic)


def add_focus(conn, col, focus):
    """
    添加focus数据
    :param conn:
    :param col:
    :param focus:
    :return:
    """
    db_collection = conn.db[col]
    cnt = db_collection.find().count()
    dic = {"Focus": cnt, "Name": focus}
    db_collection.insert(dic)


class Sentences:
    """
    使用qa_question和qa_answer表里的数据
    """
    def __iter__(self):
        print('start training')
        col = conn2.db['temp']
        for item in col.find(no_cursor_timeout=True):
            text = seg(item["text"].replace('\n', '').replace('\r', '').replace("\r\n", ""))
            yield text


def word2vec(size):
    model = Word2Vec(Sentences(),
                     sg=1,
                     size=size,
                     window=5,
                     min_count=5,
                     workers=4)
    mpath = modelpath["model"]
    model.save(os.path.join(mpath, 'wordvec.model'))
    print("save end")


if __name__ == '__main__':

    pt = modelpath["model"]
    print(os.path.join(pt, 'model'))

    conn1 = ConnectMongo(db="KnowledgeBase")
    conn2 = ConnectMongo(db="log")

    word2vec(100)
    # all_data(conn1, conn2)

    conn1.client.close()
    conn2.client.close()