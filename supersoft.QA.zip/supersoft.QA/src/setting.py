import os

mongodb = {
    'mongo_host': '192.168.1.225',
    'mongo_port': 27017,
    'username': "ycfadmin",
    'password': "123",
}

sqlserver = {
    'sql_host': 'DESKTOP-PSPOMTB\SQL2014',
    'username': 'sa',
    'password': "123",
}

webserver = {
    'host': '192.168.1.199',
    'port': 11111,
}


curPath = os.path.abspath(os.path.dirname(__file__))
rootPath = os.path.split(curPath)[0]



basedir = rootPath+'\\'
modelpath = {
    'model': os.path.join(basedir, 'data\model'),
    'prediction': os.path.join(basedir, 'data\prediction'),
    'log': os.path.join(basedir, 'data\log')
}

wordmodel_file = os.path.join(modelpath['model'], 'wordvec.model')

