#!/bin/bash
if [ $# == 1 ] ; then
echo "开始安装python3的运行环境....."
yum -y install zlib-devel bzip2-devel openssl-devel ncurses-devel sqlite-devel readline-devel tk-devel gdbm-devel db4-devel libpcap-devel xz-devel libffi-devel python-devel wget gcc make
echo "开始下载python3的安装包....."
wget https://www.python.org/ftp/python/3.6.0/Python-3.6.0.tgz 
tar zxvf Python-3.6.0.tgz  
cd Python-3.6.0
./configure -prefix=/etc/python/python3.6 
make && make install
ln -s /etc/python/python3.6/bin/python3.6 /usr/bin/python3
ln -s /etc/python/python3.6/bin/pip3.6 /usr/bin/pip3
pip3 install requests
echo "开始clone智能问答的脚本程序"
yum -y install git
git clone http://shangyongqiang@118.31.130.57/scm/git/supersoft.QA
echo "开始下载并安装智能问答的依赖包....."
cd supersoft.QA/smartqa/src/online/
pip3 install --index-url http://pypi.douban.com/simple -r requirements.txt --trusted-host pypi.douban.com
fi 
##################################################################################

#重启和启动脚本
if [ $# != 7 ] ; then 
echo "USAGE: $1 MONGODB_IP" 
echo "USAGE: $2 MONGODB_PORT"
echo "USAGE: $3 MONGODB_USER"
echo "USAGE: $4 MONGODB_PWD"
echo "USAGE: $5 SERVER_IP"
echo "USAGE: $6 SERVER_PORT"
echo "USAGE: $7 WORK_DIR"
echo " e.g.: $0 192.168.1.225 27017 ycfadmin 123 192.168.1.199 11111 /home/soft/supersoft.QA" 
exit 1; 
fi 

mongodb_ip=$1
mongodb_port=$2
mongodb_user=$3
mongodb_pwd=$4
server_ip=$5
server_port=$6
work_dir=$7
echo "切换到项目目录中$7"
cd $work_dir
#kill commend
kill -9 `ps -ef | grep boot.py |grep -v grep| awk '{print$2}'`

#restart commend
echo "拉取远程的最新代码覆盖本地"
git fetch --all  
git reset --hard origin/master 
git pull


echo "修改线上的定义配置"
sed -i "s/192.168.1.225/$mongodb_ip/g"  smartqa/src/setting.py
sed -i "s/27017/$mongodb_port/g"  smartqa/src/setting.py
sed -i "s/ycfadmin/$mongodb_user/g"  smartqa/src/setting.py
sed -i "s/123/$mongodb_pwd/g"  smartqa/src/setting.py
sed -i "s/\\\/\\//g"  smartqa/src/setting.py

sed -i "s/192.168.1.199/$server_ip/g"  smartqa/src/setting.py
sed -i "s/11111/$server_port/g"  smartqa/src/setting.py

echo "开始后台启动接口....."
cd $work_dir/smartqa/src/online/ && nohup python3 boot.py > qa.log 2>&1 &
echo "开始监控日志......"
tailf smartqa/src/online/qa.log


